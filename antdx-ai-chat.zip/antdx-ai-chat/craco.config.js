module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // 只在生产环境应用优化
      if (process.env.NODE_ENV === 'production') {
        // 1. 移除生产环境的 source map
        webpackConfig.devtool = false;

        // 2. 优化代码分割
        webpackConfig.optimization = {
          ...webpackConfig.optimization,
          splitChunks: {
            chunks: 'all',
            cacheGroups: {
              // 将 React 相关库打包到单独的 chunk
              react: {
                test: /[\\/]node_modules[\\/](react|react-dom)[\\/]/,
                name: 'react',
                priority: 20,
              },
              // 将 Ant Design 相关库打包到单独的 chunk
              antd: {
                test: /[\\/]node_modules[\\/](antd|@ant-design|rc-|@babel|antd-style)[\\/]/,
                name: 'antd',
                priority: 15,
              },
              // 将图表库打包到单独的 chunk
              charts: {
                test: /[\\/]node_modules[\\/](echarts|@antv|echarts-for-react)[\\/]/,
                name: 'charts',
                priority: 10,
              },
              // 将其他第三方库打包到单独的 chunk
              vendors: {
                test: /[\\/]node_modules[\\/]/,
                name: 'vendors',
                priority: 5,
                minChunks: 2,
              },
            },
          },
          // 启用压缩
          minimize: true,
        };
      }

      return webpackConfig;
    },
  },
};
