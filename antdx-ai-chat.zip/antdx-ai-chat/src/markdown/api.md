<!--
 * @Author       : Chang xd
 * @Date         : 2026-02-10 14:06:58
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-02-10 14:31:40
 * @Description  : 
-->

# LangGraph Agent API 接口文档

**通用说明**
- 认证方式：`Authorization: Bearer <access_token>`（登录后获取）
- `user_id` 格式：`sc_数字`（如 `sc_1`、`sc_2`）
- 返回结构通常包含 `code`/`data`/`message`
- 时间字段为 ISO 字符串

---

## 认证相关

### POST /auth/login
**说明**：登录，返回 token

**请求体**
```json
{
	"username": "string",
	"password": "string"
}
```

**响应**
```json
{
	"code": 200,
	"data": {
		"access_token": "string",
		"token_type": "bearer",
		"user_id": "sc_1",
		"username": "admin",
		"role": "admin"
	}
}
```

### GET /auth/me
**说明**：获取当前用户信息

**需要认证**：是

**响应**
```json
{
	"code": 200,
	"data": {
		"user_id": "sc_1",
		"username": "admin",
		"is_superuser": true,
		"role": "admin"
	}
}
```

---

## 用户管理（仅管理员）

### GET /api/users
**说明**：查询用户列表

**需要认证**：是（管理员）

**响应**
```json
{
	"code": 200,
	"data": {
		"users": [
			{
				"id": "sc_1",
				"username": "admin",
				"is_superuser": true,
				"status": "active",
				"created_at": "2026-02-10T00:00:00+00:00",
				"updated_at": "2026-02-10T00:00:00+00:00"
			}
		]
	}
}
```

### POST /api/users
**说明**：新增用户（自动分配 `sc_n`）

**需要认证**：是（管理员）

**请求体**
```json
{
	"username": "string",
	"password": "string",
	"is_superuser": false
}
```

**响应**
```json
{
	"code": 200,
	"data": {
		"user_id": "sc_3"
	}
}
```

### DELETE /api/users/{user_id}
**说明**：删除用户

**需要认证**：是（管理员）

**响应**
```json
{
	"code": 200,
	"message": "deleted"
}
```

---

## 系统/基础

### GET /health
**说明**：健康检查，前端暂时不调用

**响应**
```json
{
	"status": "ok",
	"mode": "deep",
	"max_history_messages": 100
}
```

### POST /reset
**说明**：清空某个会话在内存中的缓存，已经写好的接口，无需理会

**需要认证**：是

**请求体**
```json
{
	"thread_id": "user_session_1"
}
```

**响应**
```json
{
	"ok": true,
	"message": "user_id=sc_1 "
}
```

### GET /time
**说明**：返回时间列表，已经写好的接口，无需理会

**响应**
```json
{
	"code": 200,
	"type": "time",
	"data": { "time": ["2023", "2024", "2025"] }
}
```

### GET /place
**说明**：返回地点列表，已经写好的接口，无需理会

**响应**
```json
{
	"code": 200,
	"type": "place",
	"data": { "place": ["上城区"] }
}
```

---

## 对话相关（主智能体）

### POST /chat
**说明**：单次对话（非流式），但是暂时不使用，使用流式接口

**需要认证**：是

**请求体**
```json
{
	"message": "string",
	"thread_id": "user_session_1",
	"stream_report_tokens": true
}
```

**响应**
```json
{
	"answer": "string",
	"steps": 5
}
```

### POST /chat_stream_tokens
**说明**：流式对话（SSE），thread_id暂时使用目前的thread_id，后续也不会更改

**需要认证**：是

**请求体**
```json
{
	"message": "string",
	"thread_id": "user_session_1",
	"stream_report_tokens": true
}
```

**响应**：`text/event-stream`

事件类型示例：
- `title`：首次对话标题
- `token`：模型输出 token
- `deepthought`：工具/深度思考内容
- `done`：结束信号
- `error`：异常信息（含 traceback）

---

## 会话历史

### GET /api/conversations
**说明**：获取会话列表，已经写好的接口，无需理会

**需要认证**：是

**响应**
```json
{
	"code": 200,
	"message": "success",
	"data": {
		"conversations": [
			{
				"key": "sc_1:user_session_1",
				"label": "新对话",
				"group": "today",
				"createdAt": "2026-02-10T00:00:00+00:00",
				"updatedAt": "2026-02-10T00:00:00+00:00"
			}
		]
	}
}
```

**group 取值**：`today`、`yesterday`、`last_7_days`、`older`

### GET /api/conversations/{conversation_key}/messages
**说明**：获取指定会话的消息列表，已经写好的接口，无需理会

**需要认证**：是

**响应**
```json
{
	"code": 200,
	"message": "success",
	"data": {
		"conversationKey": "sc_1:user_session_1",
		"messages": [
			{
				"id": "1",
				"message": {
					"role": "user",
					"content": "你好"
				},
				"status": "success",
				"timestamp": "2026-02-10T00:00:00+00:00"
			}
		]
	}
}
```

---

## BI/简化智能体

### GET /rechatbi
**说明**：返回固定图表数据，已经写好的接口，无需理会

**响应**
```json
{
	"code": 200,
	"data": {
		"STATIC_BI_ITEMS": [
			{
				"chartMarkdown": "string",
				"explanationMarkdown": "string"
			}
		]
	}
}
```

### POST /simple_chat_stream
**说明**：简化智能体流式对话，暂时不用

**请求体**
```json
{
	"message": "string",
	"thread_id": "simple_session_1"
}
```

**响应**：`text/event-stream`

### POST /simple_reset
**说明**：重置简化智能体，暂时不用

**响应**
```json
{
	"ok": true,
	"message": "简化版智能体已重置，当前会话上下文已清空"
}
```
