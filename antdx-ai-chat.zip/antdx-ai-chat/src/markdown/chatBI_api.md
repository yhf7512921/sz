新增三个接口：

初始化chatbi图表，获取chatbi图表数据
/rechatbi
需要在进入chatbi图表中调用，获取chatbi图表数据

chatbi对话接口
/simple_chat_stream
需要在chatbi页面下，通过sender组件发送消息，获取对话内容

重置chatbi对话后端记录接口
/simple_reset
在切入chatbi页面时调用，同时前端会话管理也应该去除chatbi相关的会话记录