<!--
 * @Author       : Chang xd
 * @Date         : 2026-01-15 12:37:37
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-01-15 12:40:22
 * @Description  : 
-->
# 获取对话列表接口
接口路径 : GET /api/conversations

## 返回示例
{
  "code": 200,
  "message": "success",
  "data": {
    "conversations": [
      {
        "key": "conv-20240115-001",
        "label": "新对话1",
        "group": "today",
        "createdAt": "2024-01-15T10:30:00Z",
        "updatedAt": "2024-01-15T10:35:00Z"
      },
      {
        "key": "conv-20240115-002",
        "label": "新对话2",
        "group": "today",
        "createdAt": "2024-01-15T11:20:00Z",
        "updatedAt": "2024-01-15T11:25:00Z"
      },
      {
        "key": "conv-20240114-001",
        "label": "道路病害咨询",
        "group": "yesterday",
        "createdAt": "2024-01-14T15:00:00Z",
        "updatedAt": "2024-01-14T15:30:00Z"
      }
    ]
  }
}

## 接口说明
interface ConversationItem {
  key: string;              // 唯一标识符，必需
  label: string;            // 对话标题，必需
  group?: string;           // 分组信息（如 'today', 'yesterday'），可选
  createdAt?: string;       // 创建时间（ISO 8601格式），可选
  updatedAt?: string;       // 更新时间（ISO 8601格式），可选
}

---------------------------------------------------------------------------

# 获取特定对话的消息内容接口
接口路径 : GET /api/conversations/{conversationKey}/messages


## 返回示例
{
  "code": 200,
  "message": "success",
  "data": {
    "conversationKey": "conv-20240115-001",
    "messages": [
      {
        "id": "msg-001",
        "message": {
          "role": "user",
          "content": "请问2024年检测的之江路发现了多少处病害？"
        },
        "status": "success",
        "timestamp": "2024-01-15T10:30:00Z"
      },
      {
        "id": "msg-002",
        "message": {
          "role": "assistant",
          "content": "根据2024年之江路道路检测报告，共发现15处病害，其中脱空病害8处，空洞病害5处，疏松病害2处。"
        },
        "status": "success",
        "timestamp": "2024-01-15T10:30:05Z",
        "extraInfo": {
          "feedback": "default"
        }
      },
      {
        "id": "msg-003",
        "message": {
          "role": "user",
          "content": "请给出所有病害的详细信息"
        },
        "status": "success",
        "timestamp": "2024-01-15T10:32:00Z"
      },
      {
        "id": "msg-004",
        "message": {
          "role": "assistant",
          "content": "以下是所有病害的详细信息：\n\n1. 脱空病害（8处）：\n   - 位置：K0+200-K0+250\n   - 深度：0.5-1.2m\n   - 面积：15.6m²\n   ...\n\n2. 空洞病害（5处）：\n   ..."
        },
        "status": "success",
        "timestamp": "2024-01-15T10:32:10Z"
      }
    ]
  }
}

## 接口说明
interface MessageItem {
  id: string;               // 消息ID，必需
  message: {
    role: 'user' | 'assistant';  // 消息角色，必需
    content: string;       // 消息内容，必需
  };
  status: 'success' | 'updating' | 'loading' | 'error';  // 消息状态，必需
  timestamp?: string;       // 时间戳（ISO 8601格式），可选
  extraInfo?: {             // 额外信息，可选
    feedback?: 'default' | 'like' | 'dislike';
  };
}