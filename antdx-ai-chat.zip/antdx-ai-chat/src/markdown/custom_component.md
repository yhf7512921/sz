<!--
 * @Author       : Chang xd
 * @Date         : 2025-12-15 09:25:07
 * @LastEditors  : Chang xd
 * @LastEditTime : 2025-12-25 17:03:31
 * @Description  : 
-->

-----------------custom-component--------------------
/*
    自定义的仪表盘，如果需要，可更改数据，目前“severLoose”、“hollowing”、“loose”，“title”为后端返回数据。且展示位置固定。
 */

仅仅将以下markdown返回：

## 📊 销售仪表盘(仅作参考)
 <card-dashboard>
     {
       "region": "上城区道路病害",
       "severLoose": 10,
       "hollowing": 48,
       "loose": 19
     }
 </card-dashboard>
-----------------------------table---------------------------
/*
    自定义的订单管理系统表格，如果需要，可更改数据，“id”为必传，其他字段为可改。
    例如：前端表格约定第一列为customer属性，后端返回每行对象中就得包含customer属性。
 */

仅仅将以下markdown返回:
## 📋 订单管理系统
<custom-table>{
  "dataSource": [
    {"id":"ORD-12345","customer":"张三","product":"iPhone 15","amount":8999,"status":"completed","date":"2024-01-15","region":"北京"},
    {"id":"ORD-12346","customer":"李四","product":"MacBook Pro","amount":15999,"status":"processing","date":"2024-01-16","region":"上海"}
  ]
}</custom-table>

---------------------------chart-------------------------
/*
 type:line,pie,bar
'[]'中为图表数据，每个数据项为一个对象，对象中包含x轴数据和y轴数据。x轴数据键为name，y轴数据键为value。
axisXTitle为x轴标题，axisYTitle为y轴标题。
type为图表类型，可选值为line,pie,bar。     *必传*
 */
仅仅将以下markdown返回给我：


## 📈 年度销售额趋势图
<custom-chart 
  axisXTitle="年份" 
  axisYTitle="销售额(亿元)" 
  type="line">
  [{"name":2013,"value":59.3},{"name":2014,"value":64.4},{"name":2015,"value":68.9}]
</custom-chart>
_________________picture___________________







------------------index----------------------
仅仅将以下markdown返回给我：
<custom-index>
[{fileName:"filename1",filePiece:[{indexPath:"http://example.com/file1.pdf",indexContent:"content1",indexName:'第1页'},{indexPath:"http://example.com/file1.pdf",indexContent:"content1",indexName:'第2页'}] },
{fileName:"filename2",filePiece:[{indexPath:"http://example.com/file2.pdf",indexContent:"content1",indexName:'第1页'},{indexPath:"http://example.com/file2.pdf",indexContent:"content1",indexName:'第2页'}] },{.....}]
<custom-index>