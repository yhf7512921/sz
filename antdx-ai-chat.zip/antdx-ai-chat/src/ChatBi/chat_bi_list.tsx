/*
 * @Author       : Chang xd
 * @Date         : 2026-01-30
 * @Description  : ChatBI对话列表组件
 */
import React, { useMemo } from 'react';
import { createStyles } from 'antd-style';
import { Bubble } from '@ant-design/x';
import { Button } from 'antd';
import XMarkdown from '@ant-design/x-markdown';

const useStyle = createStyles(({ token, css }: any) => {
  return {
    listWrapper: css`
      flex: 1;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      padding: 16px 16px 0;
      min-height: 0;
    `,
    scrollArea: css`
      flex: 1;
      overflow-y: auto;
      padding-bottom: 12px;
      min-height: 0;
    `,
    emptyState: css`
      padding: 24px 12px 0;
    `,
    welcomeCard: css`
      background: #f3f4f6;
      border-radius: 16px;
      padding: 16px 18px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
      color: #111827;
    `,
    welcomeIcon: css`
      font-size: 22px;
      line-height: 1;
    `,
    welcomeTitle: css`
      font-size: 18px;
      font-weight: 600;
      margin: 0 0 6px 0;
    `,
    welcomeDesc: css`
      font-size: 13px;
      color: #4b5563;
      line-height: 1.5;
    `,
    welcomeSectionTitle: css`
      margin-top: 18px;
      font-size: 13px;
      color: #6b7280;
    `,
    promptList: css`
      margin-top: 16px;
      display: grid;
      grid-template-columns: 1fr;
      gap: 10px;
    `,
    promptButton: css`
      border-radius: 12px;
      font-size: 13px;
      height: auto;
      padding: 10px 12px;
      text-align: left;
      border: 1px solid #e5e7eb;
      background: #ffffff;
      color: #111827;
      white-space: normal;
      box-shadow: 0 1px 0 rgba(15, 23, 42, 0.04);
    `,
  };
});

export interface ChatBIListProps {
  messages: any[];
  className: string;
  xmarkdownComponents: any;
  onPromptSelect?: (prompt: string) => void;
}

const WELCOME_PROMPTS = [
  '对比 2024 与 2025 的重点指标变化',
  '生成上城区道路病害分布图，并给出结论',
  '按区域输出 TOP3 风险点位与治理建议',
  '做一份年度趋势解读，突出异常变化',
];

const ChatBIChatList: React.FC<ChatBIListProps> = ({
  messages,
  className,
  xmarkdownComponents,
  onPromptSelect,
}) => {
  const { styles } = useStyle();

  const listItems = useMemo(() => {
    return (messages || []).map((i: any, index: number) => ({
      ...i.message,
      key: i.id || `message-${index}`,
      status: i.status,
      loading: i.status === 'loading',
    }));
  }, [messages]);

  if (listItems.length === 0) {
    return (
      <div className={styles.listWrapper}>
        <div className={styles.emptyState}>
          <div className={styles.welcomeCard}>
            <div className={styles.welcomeIcon}>👋</div>
            <div>
              <div className={styles.welcomeTitle}>你好，我是 ChatBI</div>
              <div className={styles.welcomeDesc}>
                我会在左侧生成图表与结论。
              </div>
              <div className={styles.welcomeDesc}>
                你可以在下方输入问题开始分析，也可以先选一个示例提示。
              </div>
            </div>
          </div>
          {/* <div className={styles.welcomeSectionTitle}>我可以帮你：</div>
          <div className={styles.promptList}>
            {WELCOME_PROMPTS.map((prompt) => (
              <Button
                key={prompt}
                size="small"
                className={styles.promptButton}
                onClick={() => onPromptSelect?.(prompt)}
              >
                {prompt}
              </Button>
            ))}
          </div> */}
        </div>
      </div>
    );
  }

  return (
    <div className={styles.listWrapper}>
      <div className={styles.scrollArea}>
        <Bubble.List
          items={listItems}
          styles={{
            bubble: {
              maxWidth: '100%',
              textAlign: 'left',
              fontSize: '14px',
            },
            content: {
              textAlign: 'left',
              fontSize: '14px',
            },
          }}
          role={{
            assistant: {
              placement: 'start',
              contentRender: (content: any, { status }: any) => (
                <XMarkdown
                  paragraphTag="div"
                  components={xmarkdownComponents}
                  className={className}
                  streaming={{
                    hasNextChunk: status === 'updating',
                    enableAnimation: true,
                  }}
                  style={{
                    textAlign: 'left',
                    fontSize: '14px',
                  }}
                >
                  {content}
                </XMarkdown>
              ),
            },
            user: { placement: 'end' },
          }}
        />
      </div>
    </div>
  );
};

export default React.memo(ChatBIChatList);
