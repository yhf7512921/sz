/*
 * @Author       : Chang xd
 * @Date         : 2026-01-14 00:00:00
 * @Description  : ChatBI内容 - 商业BI图表展示页面
 */
import React, { useEffect, useMemo, useState } from 'react';
import { createStyles } from 'antd-style';
import XMarkdown from '@ant-design/x-markdown';

const useStyle = createStyles(({ token, css }: any) => {
  return {
    chatBIContent: css`
      flex: 1;
      overflow: visible;
      padding: 16px 20px;
      display: flex;
      flex-direction: column;
      gap: 18px;
      background: #fafafa;
      font-family: AlibabaPuHuiTi, ${token.fontFamily}, sans-serif;
      position: relative;
    `,
    chartGrid: css`
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      grid-auto-rows: minmax(220px, 1fr);
      gap: 18px;
      align-items: stretch;
      width: 100%;
      margin: 0 auto;
    `,
    chartScroll: css`
      flex: 1;
      overflow: visible;
      padding: 0;
      min-height: 0;
    `,
    chartItem: css`
      background: #ffffff;
      border-radius: 0;
      padding: 18px 20px;
      min-height: 395px;
      height: 20.6vw;
      border: 1px solid rgba(148, 163, 184, 0.2);
      box-shadow: 0 12px 24px rgba(15, 23, 42, 0.08);
      transition: all 0.3s ease;
      animation: fadeUp 0.5s ease both;
      position: relative;
      overflow: hidden;
      width: calc(100% - 40px);
      margin: 0 auto;
      &:hover {
        box-shadow: 0 16px 30px rgba(15, 23, 42, 0.14);
        transform: translateY(-4px);
      }
      @keyframes fadeUp {
        0% {
          opacity: 0;
          transform: translateY(12px);
        }
        100% {
          opacity: 1;
          transform: translateY(0);
        }
      }
    `,
    chartItemFocused: css`
      grid-column: 1 / -1;
      height: clamp(240px, 36vh, 400px);
      z-index: 1;
    `,
    chartItemHero: css`
      grid-column: 1 / -1;
    `,
    chartItemCollapsed: css`
      height: 160px;
      opacity: 0.7;
      transform: scale(0.98);
    `,
    explainTitle: css`
      font-size: 14px;
      font-weight: 600;
      color: #1f2937;
      margin-bottom: 10px;
    `,
    explainOverlay: css`
      position: absolute;
      inset: 0;
      padding: 18px 20px;
      background: #ffffff;
      color: #111827;
      display: flex;
      flex-direction: column;
      gap: 10px;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.2s ease, transform 0.2s ease;
      pointer-events: none;
    `,
    explainOverlayVisible: css`
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    `,
    explainOverlayTitle: css`
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 14px;
      font-weight: 600;
      color: #111827;
    `,
    explainToggle: css`
      position: absolute;
      top: 12px;
      right: 12px;
      border: none;
      background: rgba(17, 24, 39, 0.08);
      color: #111827;
      border-radius: 999px;
      padding: 6px 10px;
      font-size: 12px;
      cursor: pointer;
    `,
  };
});
interface ChatBIContentProps {
  messages: any[];
  items?: Array<{ chartMarkdown: string; explanationMarkdown: string }>;
  isLoading?: boolean;
  xmarkdownComponents: any;
  className: string;
}

const STATIC_BI_ITEMS = [
  {
    chartMarkdown: `## 病害分布图1
<custom-chart axisXTitle="病害类型" axisYTitle="占比(%)" type="pie">
  [{"name":"脱空","value":35},{"name":"裂缝","value":25},{"name":"沉陷","value":20},{"name":"其他","value":20}]
</custom-chart>`,
    explanationMarkdown: `**图表说明**
- 脱空占比最高，35%，需要重点关注和及时处理。
- 裂缝次之25%，主要由于路面老化导致。
- 沉陷占比相对接近20%，可能与地基沉降有关。
- 其他类型占比20%，需要定期维护和检查。`,
  },
  {
    chartMarkdown: `## 年度销售额趋势图1
<custom-chart axisXTitle="年份" axisYTitle="销售额(万元)" type="line">
  [{"name":2019,"value":120},{"name":2020,"value":150},{"name":2021,"value":180},{"name":2022,"value":210}]
</custom-chart>`,
    explanationMarkdown: `**图表说明**
- 销售额呈现稳定增长趋势，年均增长率约15%。
- 2021-2022年增长最快，可能与市场扩张有关。
- 预计未来仍将保持良好的增长态势。`,
  },
  {
    chartMarkdown: `## 员工年龄分布柱状图1
<custom-chart axisXTitle="年龄段" axisYTitle="人数(人)" type="bar">
  [{"name":"20-30","value":28},{"name":"30-40","value":42},{"name":"40-50","value":36},{"name":"50+","value":18}]
</custom-chart>`,
    explanationMarkdown: `**图表说明**
- 30-40岁员工最多，42人，为公司的核心力量。
- 40-50岁次之36人，经验丰富且技术娴熟。
- 20-30岁最少18人，说明公司需要加强年轻人才引进。`,
  },
];

const ChatBIContent: React.FC<ChatBIContentProps> = ({
  messages,
  items,
  isLoading = false,
  xmarkdownComponents,
  className,
}) => {
  const { styles } = useStyle();
  const [activeExplainIndex, setActiveExplainIndex] = useState<number | null>(null);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);

  const maxCharts = 3;
  const resolvedItems = items && items.length > 0 ? items : STATIC_BI_ITEMS;
  const visibleItems = useMemo(() => resolvedItems.slice(0, maxCharts), [resolvedItems]);
  const [order, setOrder] = useState(() => visibleItems.map((_, idx) => idx));

  useEffect(() => {
    setOrder(visibleItems.map((_, idx) => idx));
    setFocusedIndex(null);
    setActiveExplainIndex(null);
  }, [visibleItems]);

  return (
    <div className={styles.chatBIContent}>
      {isLoading ? (
        <div className={styles.chartScroll}>
          <div className={styles.chartGrid}>
            <div
              className={`${styles.chartItem} ${styles.chartItemHero}`}
            >
              <div style={{ height: '100%', background: '#f3f4f6', borderRadius: 0 }} />
            </div>
            <div className={styles.chartItem}>
              <div style={{ height: '100%', background: '#f3f4f6', borderRadius: 0 }} />
            </div>
            <div className={styles.chartItem}>
              <div style={{ height: '100%', background: '#f3f4f6', borderRadius: 0 }} />
            </div>
          </div>
        </div>
      ) : (
      <div className={styles.chartScroll}>
        <div className={styles.chartGrid}>
          {order.map((originalIndex, renderIndex) => {
            const item = visibleItems[originalIndex];
            if (!item) return null;
            const isFocused = focusedIndex === originalIndex;
            const isDimmed = focusedIndex !== null && !isFocused;
            const isHero = renderIndex === 0;
            return (
            <React.Fragment key={`static-${originalIndex}`}>
              <div
                className={`${styles.chartItem} ${
                  isFocused ? styles.chartItemFocused : ''
                } ${isDimmed ? styles.chartItemCollapsed : ''} ${
                  isHero ? styles.chartItemHero : ''
                }`}
              >
                <XMarkdown
                  paragraphTag="div"
                  components={xmarkdownComponents}
                  className={className}
                  streaming={{
                    hasNextChunk: false,
                    enableAnimation: false,
                  }}
                  style={{
                    textAlign: 'left',
                    fontSize: '15px',
                  }}
                >
                  {item.chartMarkdown}
                </XMarkdown>
                <button
                  type="button"
                  className={styles.explainToggle}
                  onClick={(event) => {
                    event.stopPropagation();
                    if (isHero) {
                      setActiveExplainIndex((prev) => (prev === originalIndex ? null : originalIndex));
                      return;
                    }
                    setFocusedIndex((prev) => (prev === originalIndex ? null : originalIndex));
                    setActiveExplainIndex(originalIndex);
                    setOrder((prev) => {
                      const next = prev.filter((id) => id !== originalIndex);
                      return [originalIndex, ...next];
                    });
                  }}
                >
                  {activeExplainIndex === originalIndex ? '收起解析' : '展开解析'}
                </button>
                <div
                  className={`${styles.explainOverlay} ${
                    activeExplainIndex === originalIndex || (isFocused && !isHero)
                      ? styles.explainOverlayVisible
                      : ''
                  }`}
                >
                  <div className={styles.explainOverlayTitle}>
                    <span>展开解析</span>
                    <button
                      type="button"
                      className={styles.explainToggle}
                      onClick={(event) => {
                        event.stopPropagation();
                        setActiveExplainIndex(null);
                        if (isHero) {
                          setFocusedIndex(null);
                        }
                      }}
                    >
                      收起解析
                    </button>
                  </div>
                  <XMarkdown
                    paragraphTag="div"
                    components={xmarkdownComponents}
                    className={className}
                    streaming={{
                      hasNextChunk: false,
                      enableAnimation: false,
                    }}
                    style={{
                      textAlign: 'left',
                      fontSize: '14px',
                      color: '#111827',
                    }}
                  >
                    {item.explanationMarkdown}
                  </XMarkdown>
                </div>
              </div>
            </React.Fragment>
          )})}
        </div>
      </div>
      )}
    </div>
  );
};

export default ChatBIContent;