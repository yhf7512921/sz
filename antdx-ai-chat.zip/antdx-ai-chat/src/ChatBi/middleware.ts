import type { XRequestOptions } from '@ant-design/x-sdk';
import type { SSEFields, XModelParams, XModelResponse } from '@ant-design/x-sdk';
import { useAuthStore } from '../stores';

type ThreadIdGetter = () => string;

const createChatBIMiddlewares = (getThreadId: ThreadIdGetter) => {
  const buildAuthHeaders = (headers?: Record<string, string>) => {
    const { token } = useAuthStore.getState();
    if (!token) return {};
    const hasAuthorization = !!headers?.Authorization || !!headers?.authorization;
    const hasTokenHeader = !!headers?.token;
    const authHeaders: Record<string, string> = {};
    if (!hasAuthorization) {
      authHeaders.Authorization = `Bearer ${token}`;
    }
    if (!hasTokenHeader) {
      authHeaders.token = token;
    }
    return authHeaders;
  };
  const middlewares: any = {
    onRequest: async (
      baseURL: RequestInfo | URL,
      options: XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>,
    ) => {
      if (options.method === 'POST' && options.body) {
        try {
          const originalBody = typeof options.body === 'string' ? JSON.parse(options.body) : options.body;

          let messageContent = originalBody.message;
          if (!messageContent && originalBody.messages) {
            const latestUserMessage = originalBody.messages.findLast((msg: any) => msg.role === 'user');
            messageContent = latestUserMessage?.content;
          }

          if (messageContent) {
            const transformedBody = {
              message: messageContent,
              thread_id: getThreadId(),
              messages: originalBody.messages || [{ role: 'user', content: messageContent }],
            };

            return [
              baseURL,
              {
                ...options,
                headers: {
                  ...(options.headers || {}),
                  ...buildAuthHeaders(options.headers as Record<string, string> | undefined),
                },
                body: JSON.stringify(transformedBody),
              },
            ] as [RequestInfo | URL, XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>];
          }
        } catch (error) {
          console.error('ChatBI 转换请求格式失败:', error);
        }
      }
      return [
        baseURL,
        {
          ...options,
          headers: {
            ...(options.headers || {}),
            ...buildAuthHeaders(options.headers as Record<string, string> | undefined),
          },
        },
      ] as [RequestInfo | URL, XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>];
    },
  };
  return middlewares;
};

export default createChatBIMiddlewares;
