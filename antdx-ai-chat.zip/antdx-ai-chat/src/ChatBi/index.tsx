/*
 * @Author       : Chang xd
 * @Date         : 2026-01-30
 * @Description  : ChatBI独立路由页面
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createStyles } from 'antd-style';
import { XProvider } from '@ant-design/x';
import { useNavigate } from 'react-router-dom';
import ChatBIContent from './chat_bi';
import ChatBIChatList from './chat_bi_list';
import CHAT_SENDER from './chat_sender';
import { useMarkdownTheme } from '../markdown/demo/_utils';
import locale from '../utils/locale';
import { API_CONFIG, forceLogout } from '../utils/api';
import { ROUTES } from '../routes/paths';
import DataChart from '../components/DataChart';
import CustomTable from '../components/Table';
import CardDashBoard from '../components/CardDashBoard';
import PictureView from '../components/PictureView';
import CollectionIndex from '../components/CollectionIndex';
import MarkdownToPdfDialog from '../components/MarkdownToPdfDialog';
import CustomThoughtChain from '../components/CustomThoughtChain';
import CustomFileCard from '../components/FileCard';
import createChatBIMiddlewares from './middleware';
import { useConversationStore } from '../stores';

const useStyle = createStyles(({ token, css }: any) => {
  return {
    layout: css`
      width: 100%;
      height: 100vh;
      display: flex;
      background: #fafafa;
      font-family: AlibabaPuHuiTi, ${token.fontFamily}, sans-serif;
    `,
    content: css`
      height: 100%;
      width: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: row;
      padding: 0;
      background: #ffffff;
      justify-content: space-between;
      transition: all 0.3s ease-in-out;
      gap: 0;
      @media (max-width: 1200px) {
        flex-direction: column;
      }
    `,
    leftPanel: css`
      flex: 1 1 auto;
      min-width: 0;
      background: #fafafa;
      border-right: 1px solid rgba(148, 163, 184, 0.2);
      overflow-y: auto;
      height: 100%;
      @media (max-width: 1200px) {
        border-right: 0;
        border-bottom: 1px solid rgba(148, 163, 184, 0.2);
      }
    `,
    rightPanel: css`
      width: 420px;
      max-width: 40%;
      min-width: 360px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      background: #ffffff;
      height: 100%;
      overflow: hidden;
      @media (max-width: 1200px) {
        width: 100%;
        max-width: 100%;
        min-width: 0;
      }
    `,
  };
});

const ChatBIPage: React.FC = () => {
  const { styles } = useStyle();
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState('');
  const [isDeepThinking, setIsDeepThinking] = useState(true);
  const [chatBIMessages, setChatBIMessages] = useState<any[]>([]);
  const [chartItems, setChartItems] = useState<any[] | null>(null);
  const [isChatBILoading, setIsChatBILoading] = useState(true);
  const [isBIRequesting, setIsBIRequesting] = useState(false);
  const [biAbortController, setBIAbortController] = useState<AbortController | null>(null);
  const chatBISessionIdRef = useRef(`chatbi_Id`);
  const { setIsNewConversation } = useConversationStore();
  const chatBIMiddlewares = useMemo(
    () => createChatBIMiddlewares(() => chatBISessionIdRef.current),
    [],
  );

  const [themeClassName] = useMarkdownTheme();
  const className = themeClassName;

  const xmarkdownComponents = useMemo(() => ({
    'custom-chain': CustomThoughtChain,
    'custom-chart': DataChart,
    'card-dashboard': CardDashBoard,
    'custom-table': CustomTable,
    'custom-picture': PictureView,
    'custom-index': CollectionIndex,
    'custom-pdfdialog': MarkdownToPdfDialog,
    'custom-filecard': CustomFileCard,
  }), []);

  const onSubmit = useCallback(async (val: string, deepThinking: boolean = false, _isChatBI?: boolean) => {
    if (!val) return;

    const controller = new AbortController();
    setBIAbortController(controller);
    setIsBIRequesting(true);

    const userMessage = {
      id: Date.now(),
      message: { role: 'user', content: val },
      status: 'success',
    };

    setChatBIMessages(prev => [...prev, userMessage]);

    const baseOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'glm-4.5-flash',
        stream: true,
        messages: [{ role: 'user', content: val }],
        thinking: deepThinking ? { type: 'enabled' } : { type: 'disabled' },
      }),
    };

    const [requestUrl, requestOptions] = await chatBIMiddlewares.onRequest(
      API_CONFIG.endpoints.chatbiStream,
      baseOptions as any,
    );

    fetch(requestUrl, {
      ...(requestOptions as RequestInit),
      signal: controller.signal,
    })
      .then(response => {
        if (response.status === 401) {
          forceLogout();
          setIsBIRequesting(false);
          setBIAbortController(null);
          return;
        }
        if (!response.ok || !response.body) {
          throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let assistantContent = '';

        const assistantId = Date.now() + 1;
        setChatBIMessages(prev => [
          ...prev,
          {
            id: assistantId,
            message: { role: 'assistant', content: '' },
            status: 'updating',
          },
        ]);

        const readStream = async () => {
          try {
            while (true) {
              const { done, value } = await reader!.read();
              if (done) break;

              const chunk = decoder.decode(value, { stream: true });
              assistantContent += chunk;

              setChatBIMessages(prev =>
                prev.map(msg =>
                  msg.id === assistantId
                    ? { ...msg, message: { ...msg.message, content: assistantContent } }
                    : msg
                )
              );
            }
          } catch (error) {
            if (error instanceof DOMException && error.name === 'AbortError') {
              console.log('Stream aborted');
            } else {
              console.error('Stream error:', error);
            }
          } finally {
            setIsBIRequesting(false);
            setBIAbortController(null);
            setChatBIMessages(prev =>
              prev.map(msg =>
                msg.id === assistantId
                  ? { ...msg, status: 'success' }
                  : msg
              )
            );
          }
        };

        readStream();
      })
      .catch(error => {
        console.error('ChatBI request error:', error);
        setIsBIRequesting(false);
        setBIAbortController(null);
      });
  }, []);

  useEffect(() => {
    let isMounted = true;

    const normalizeChartItems = (payload: any) => {
      const raw = payload?.data ?? payload;
      const list = Array.isArray(raw)
        ? raw
        : Array.isArray(raw?.STATIC_BI_ITEMS)
          ? raw.STATIC_BI_ITEMS
          : Array.isArray(raw?.items)
            ? raw.items
            : Array.isArray(raw?.charts)
              ? raw.charts
              : Array.isArray(raw?.list)
                ? raw.list
                : null;
      if (!Array.isArray(list)) return null;
      const mapped = list
        .map((item: any) => ({
          chartMarkdown: item?.chartMarkdown ?? item?.chart_markdown ?? item?.chart ?? '',
          explanationMarkdown: item?.explanationMarkdown ?? item?.explanation_markdown ?? item?.explanation ?? '',
        }))
        .filter((item: any) => Boolean(item.chartMarkdown));
      return mapped.length > 0 ? mapped : null;
    };

    const initChatBI = async () => {
      setIsChatBILoading(true);
      setChatBIMessages([]);
      chatBISessionIdRef.current = 'chatbi_Id';

      try {
        const resetResponse = await fetch(API_CONFIG.endpoints.chatbiReset, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        });
        if (resetResponse.status === 401) {
          forceLogout();
          return;
        }
      } catch (error) {
        console.error('ChatBI reset error:', error);
      }

      try {
        let response = await fetch(API_CONFIG.endpoints.chatbiInit, { method: 'GET' });
        if (response.status === 401) {
          forceLogout();
          return;
        }
        if (!response.ok) return;
        const data = await response.json();
        if (!data?.data) return;
        const items = normalizeChartItems(data);
        console.log('items', items);
        if (items && isMounted) {
          setChartItems(items);
        }
      } catch (error) {
        console.error('ChatBI init error:', error);
      } finally {
        if (isMounted) {
          setIsChatBILoading(false);
        }
      }
    };

    initChatBI();

    return () => {
      isMounted = false;
    };
  }, []);

  const abortBI = useCallback(() => {
    if (biAbortController) {
      biAbortController.abort();
      setBIAbortController(null);
      setIsBIRequesting(false);
    }
  }, [biAbortController]);

  const handleExitChatBI = useCallback(() => {
    if (biAbortController) {
      biAbortController.abort();
    }
    chatBISessionIdRef.current = `chatbi_Id`;
    setChatBIMessages([]);
    setIsNewConversation(true);
    navigate(ROUTES.home);
  }, [biAbortController, navigate, setIsNewConversation]);

  return (
    <XProvider locale={locale}>
      <div className={styles.layout}>
        <div className={styles.content}>
          <div className={styles.leftPanel}>
            <ChatBIContent
              messages={chatBIMessages}
              items={chartItems ?? undefined}
              isLoading={isChatBILoading}
              xmarkdownComponents={xmarkdownComponents}
              className={className}
            />
          </div>
          <div className={styles.rightPanel}>
            <ChatBIChatList
              messages={chatBIMessages}
              xmarkdownComponents={xmarkdownComponents}
              className={className}
              onPromptSelect={(prompt) => setInputValue(prompt)}
            />
            <CHAT_SENDER
              inputValue={inputValue}
              setInputValue={setInputValue}
              isRequesting={isBIRequesting}
              onSubmit={onSubmit}
              abort={abortBI}
              isDeepThinking={isDeepThinking}
              setIsDeepThinking={setIsDeepThinking}
              isChatBI={true}
              onExitChatBI={handleExitChatBI}
              placeholder="在下方输入问题，左侧将自动生成图表与分析"
            />
          </div>
        </div>
      </div>
    </XProvider>
  );
};

export default ChatBIPage;
