import React from 'react';
import ChatSender, { ChatSenderProps } from '../Freestanding/chat_sender';

type ChatBISenderProps = Omit<ChatSenderProps, 'showSkills'>;

const ChatBISender: React.FC<ChatBISenderProps> = (props) => {
  return <ChatSender {...props} showSkills={false} flatCorners={true} />;
};

export default ChatBISender;

