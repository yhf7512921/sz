﻿import type { XRequestOptions } from '@ant-design/x-sdk';
import type { SSEFields, XModelParams, XModelResponse } from '@ant-design/x-sdk';
import { message } from 'antd';
import { useConversationStore, useAuthStore } from '../stores';
import { forceLogout } from '../utils/api';

// 让所有'\n' 替换为 ’ ' 替换规则，以便在前端正确显示。
const replaceWarps = (content: string) => {
  return content.replace(/\n/g, ' ').replace(/\r/g, ' ');
}

const normalizeMarkdownContent = (content: string) => {
  const trimmed = content.trim();
  const hasWrapperQuotes =
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"));
  if (!hasWrapperQuotes) {
    return content.replace(/\\n/g, '\n');
  }
  const unwrapped = trimmed.slice(1, -1);
  if (unwrapped.includes('<custom-') || unwrapped.startsWith('##')) {
    return unwrapped.replace(/\\n/g, '\n');
  }
  return content.replace(/\\n/g, '\n');
};
/**
 * 创建聊天服务的中间件
 * 处理后端返回的SSE事件格式转换
 * @returns 包含请求和响应处理的中间件对象
 */
const createMiddlewares = () => {
  const buildAuthHeaders = (headers?: Record<string, string>) => {
    const { token } = useAuthStore.getState();
    if (!token) return {};
    const hasAuthorization = !!headers?.Authorization || !!headers?.authorization;
    const hasTokenHeader = !!headers?.token;
    const authHeaders: Record<string, string> = {};
    if (!hasAuthorization) {
      authHeaders.Authorization = `Bearer ${token}`;
    }
    if (!hasTokenHeader) {
      authHeaders.token = token;
    }
    return authHeaders;
  };
  const middlewares: any = {
    // onRequest中间件：转换请求格式
    onRequest: async (baseURL: RequestInfo | URL, options: XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>) => {
      // 只有POST请求才需要转换
      if (options.method === 'POST' && options.body) {
        try {
          // 解析原始请求体
          const originalBody = typeof options.body === 'string' ? JSON.parse(options.body) : options.body;

          // 直接使用当前输入的message，而不是从messages数组中获取
          let messageContent = originalBody.message;

          // 如果没有message字段，再尝试从messages数组中获取
          if (!messageContent && originalBody.messages) {
            const latestUserMessage = originalBody.messages.findLast((msg: any) => msg.role === 'user');
            messageContent = latestUserMessage?.content;
          }

          if (messageContent) {
            const { currentConversationId } = useConversationStore.getState();
            
            const transformedBody = {
              message: messageContent,
              thread_id: currentConversationId ,
              messages: originalBody.messages || [{ role: 'user', content: messageContent }],
            };

            return [
              baseURL,
              {
                ...options,
                headers: {
                  ...(options.headers || {}),
                  ...buildAuthHeaders(options.headers as Record<string, string> | undefined),
                },
                body: JSON.stringify(transformedBody),
              }
            ] as [RequestInfo | URL, XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>];
          }
        } catch (error) {
          console.error('转换请求格式失败:', error);
        }
      }
      // 如果不是POST请求或转换失败，返回原始参数
      return [
        baseURL,
        {
          ...options,
          headers: {
            ...(options.headers || {}),
            ...buildAuthHeaders(options.headers as Record<string, string> | undefined),
          },
        },
      ] as [RequestInfo | URL, XRequestOptions<XModelParams, Partial<Record<SSEFields, XModelResponse>>>];
    },
    // onResponse中间件：转换SSE响应格式
    onResponse: async (response: Response) => {
      if (response.status === 401) {
        message.error('登录已过期，请重新登录');
        forceLogout();
        return response;
      }
      // 只有当响应是SSE时才进行转换
      if (response.headers.get('content-type')?.includes('text/event-stream')) {
        // 用于跟踪深度思考流的状态
        let isInDeepthought = false;
        let isCustomChainOpen = false;

        const worker = new Worker(
          new URL('./StreamProcessor.worker.ts', import.meta.url),
          { type: 'module' },
        );
        let requestId = 0;
        const encoder = new TextEncoder();
        const pending = new Map<number, (payload: any) => void>();

        const postWorkerMessage = (type: string, data: any) => {
          requestId += 1;
          const id = requestId;
          return new Promise<any>((resolve) => {
            pending.set(id, resolve);
            worker.postMessage({ type, id, data });
          });
        };

        worker.onmessage = (event) => {
          const { id, type, data } = event.data || {};
          const resolve = pending.get(id);
          if (!resolve) return;
          pending.delete(id);
          resolve({ type, data });
        };

        const handleTitleUpdate = (titleContent: string) => {
          const { isNewConversation, currentConversationId, newLabelId, newLabel, setNewLabelId, setNewLabel, setIsNewConversation } = useConversationStore.getState();
          if (isNewConversation) {
            setNewLabelId(currentConversationId);
            setNewLabel(titleContent);
            setIsNewConversation(false);
          }
        };

        const transformStream = new TransformStream({
          async transform(chunk, controller) {
            const result = await postWorkerMessage('process', {
              chunk,
              isInDeepthought,
              isCustomChainOpen,
            });
            if (!result || result.type !== 'result') return;
            const payload = result.data || {};
            isInDeepthought = payload.isInDeepthought;
            isCustomChainOpen = payload.isCustomChainOpen;

            if (Array.isArray(payload.titleUpdates)) {
              payload.titleUpdates.forEach((title: string) => {
                if (title) {
                  handleTitleUpdate(title);
                }
              });
            }

            (payload.items || []).forEach((item: any) => {
              if (item.type === 'raw') {
                controller.enqueue(new Uint8Array(item.data));
              } else if (item.type === 'text') {
                controller.enqueue(encoder.encode(item.data));
              }
            });
          },
          async flush(controller) {
            const result = await postWorkerMessage('end', { isInDeepthought });
            if (result && result.type === 'end' && result.data) {
              controller.enqueue(encoder.encode(result.data));
            }
            worker.terminate();
          }
        });

        // 创建一个新的Response，使用转换后的流，并确保正确的SSE响应头
        const newResponse = new Response(
          response.body?.pipeThrough(transformStream),
          {
            ...response,
            headers: {
              ...response.headers,
              'Content-Type': 'text/event-stream',
              'Cache-Control': 'no-cache',
              'Connection': 'keep-alive',
            },
          }
        );
        return newResponse;
      }

      // 非SSE响应直接返回
      return response;
    }
  };
  return middlewares;
};

export default createMiddlewares;




