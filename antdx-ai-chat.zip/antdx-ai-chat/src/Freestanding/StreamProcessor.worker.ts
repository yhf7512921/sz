﻿/// <reference lib="webworker" />
/* eslint-disable no-restricted-globals */
// Web Worker for processing SSE streams (logic moved from middleware)

type ProcessItem =
  | { type: 'text'; data: string }
  | { type: 'raw'; data: ArrayBuffer };

type ProcessResult = {
  items: ProcessItem[];
  isInDeepthought: boolean;
  isCustomChainOpen: boolean;
  titleUpdates: string[];
};

// 替换所有换行符为空格，原来是逻辑处理或处理
const replaceWarps = (content: string) => {
  return content.replace(/\n/g, ' ').replace(/\r/g, ' ');
};

const normalizeMarkdownContent = (content: string) => {
  const trimmed = content.trim();
  const hasWrapperQuotes =
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"));
  if (!hasWrapperQuotes) {
    return content.replace(/\\n/g, '\n');
  }
  const unwrapped = trimmed.slice(1, -1);
  if (unwrapped.includes('<custom-') || unwrapped.startsWith('##')) {
    return unwrapped.replace(/\\n/g, '\n');
  }
  return content.replace(/\\n/g, '\n');
};

const processChunk = (
  chunk: Uint8Array,
  isInDeepthought: boolean,
  isCustomChainOpen: boolean,
): ProcessResult => {
  const items: ProcessItem[] = [];
  const titleUpdates: string[] = [];

  try {
    const chunkStr = new TextDecoder().decode(chunk);
    const dataLines = chunkStr.split(/\n\s*\n/);

    dataLines.forEach((line) => {
      if (!line.trim()) return;

      const lines = line.split('\n');

      const enqueueDeltaContent = (deltaContent: string) => {
        const extraData = {
          choices: [
            {
              delta: {
                content: deltaContent,
              },
            },
          ],
        };
        const extraLine = `data: ${JSON.stringify(extraData)}\n\n`;
        items.push({ type: 'text', data: extraLine });
      };

      lines.forEach((singleLine) => {
        if (!singleLine.trim()) return;

        if (singleLine.startsWith('data:')) {
          const dataStr = singleLine.substring(5).trim();
          if (!dataStr) return;

          try {
            const data = JSON.parse(dataStr);
            const content = normalizeMarkdownContent(String(data.content || ''));
            let transformedData: any;

            if (data.type === 'deepthought') {
              const processedContent = !isInDeepthought ? `<Think>${content}` : content;

              if (!isInDeepthought) {
                isInDeepthought = true;
              }

              transformedData = {
                choices: [
                  {
                    delta: {
                      content: replaceWarps(processedContent),
                    },
                  },
                ],
              };
            } else {
              const processedContent = isInDeepthought
                ? `</Think> \n  ${content}`
                : content;

              if (isInDeepthought) {
                isInDeepthought = false;
              }

              if (processedContent.includes('<custom-chain>')) {
                isCustomChainOpen = true;
              }
              if (processedContent.includes('</custom-chain>')) {
                isCustomChainOpen = false;
              }

              switch (data.type) {
                case 'title':
                  if (data.content) {
                    titleUpdates.push(data.content);
                  }
                  break;

                case 'token':
                  transformedData = {
                    choices: [
                      {
                        delta: {
                          content: processedContent,
                        },
                      },
                    ],
                  };
                  break;

                case 'done':
                  if (isCustomChainOpen) {
                    enqueueDeltaContent('</custom-chain>');
                    isCustomChainOpen = false;
                  }
                  transformedData = {
                    choices: [
                      {
                        finish_reason: 'stop',
                      },
                    ],
                  };
                  break;

                case 'tool_call':
                  transformedData = {
                    choices: [
                      {
                        delta: {
                          tool_calls: [
                            {
                              type: 'function',
                              function: {
                                name: data.tool || '',
                                arguments: JSON.stringify(data.args || {}),
                              },
                            },
                          ],
                        },
                      },
                    ],
                  };
                  break;

                case 'error': {
                  const errorContent = isInDeepthought
                    ? `</Think> \n 执行失败: ${content || data.message || '后端请求失败'}`
                    : `执行失败: ${content || data.message || '后端请求失败'}`;

                  if (isInDeepthought) {
                    isInDeepthought = false;
                  }

                  transformedData = {
                    choices: [
                      {
                        delta: {
                          content: replaceWarps(errorContent),
                        },
                        finish_reason: 'error',
                      },
                    ],
                    error: {
                      message: content || '后端请求失败',
                    },
                  };
                  break;
                }

                default:
                  break;
              }
            }

            const transformedLine = `data: ${JSON.stringify(transformedData)}\n\n`;
            items.push({ type: 'text', data: transformedLine });
          } catch (parseError) {
            // If parsing fails, pass through raw chunk
            items.push({ type: 'raw', data: chunk.buffer.slice(0) });
          }
        } else {
          items.push({ type: 'text', data: `${singleLine}\n` });
        }
      });
    });
  } catch (transformError) {
    items.push({ type: 'raw', data: chunk.buffer.slice(0) });
  }

  return {
    items,
    isInDeepthought,
    isCustomChainOpen,
    titleUpdates,
  };
};

const processStreamEnd = (isInDeepthought: boolean) => {
  if (isInDeepthought) {
    const endDeepthoughtData = {
      choices: [
        {
          delta: {
            content: '</Think>',
          },
        },
      ],
    };
    const endDeepthoughtLine = `data: ${JSON.stringify(endDeepthoughtData)}\n\n`;
    return endDeepthoughtLine;
  }
  return '';
};

const ctx = self as unknown as DedicatedWorkerGlobalScope;

ctx.onmessage = (event) => {
  const { type, id, data } = event.data || {};

  switch (type) {
    case 'process': {
      const { chunk, isInDeepthought, isCustomChainOpen } = data || {};
      const result = processChunk(chunk, isInDeepthought, isCustomChainOpen);
      ctx.postMessage(
        {
          type: 'result',
          id,
          data: result,
        },
        result.items
          .filter((item) => item.type === 'raw')
          .map((item) => item.data) as Transferable[],
      );
      break;
    }

    case 'end': {
      const { isInDeepthought } = data || {};
      const endResult = processStreamEnd(Boolean(isInDeepthought));
      ctx.postMessage({
        type: 'end',
        id,
        data: endResult,
      });
      break;
    }

    default:
      break;
  }
};

export {};