import {
  FileSearchOutlined,
  BarChartOutlined,
  BulbOutlined,
  EditOutlined
} from '@ant-design/icons';
import { Tabs, Tooltip } from 'antd';
import FilePreview from '../components/FilePreview';
import { PaperClipOutlined, CloudUploadOutlined } from '@ant-design/icons';
import { Button, Flex, message, Dropdown ,MenuProps , GetRef, Divider} from 'antd';
import type { GetProp } from 'antd';
import { createStyles } from 'antd-style';
import React, { useState, useRef ,useCallback} from 'react';
import { Sender, Attachments, SenderProps} from '@ant-design/x';
import locale from '../utils/locale';
import { useRenderCount } from '../utils/useRenderCount';

const Switch = Sender.Switch;
type SlotConfig = NonNullable<SenderProps['slotConfig']>;
type SlotConfigItem = SlotConfig[number];
const useStyle = createStyles(({ token, css }) => ({
  sender: css`
    width: 100%;
    max-width: calc(100% - 500px);
    min-width: 600px;
    margin: 0 auto;
    .ant-sender-input {
      text-align: left !important;
      align-items: flex-start !important;
    }
    .ant-x-sender-textarea {
      text-align: left !important;
    }
  `,
  senderPrompt: css`
    width: 100%;
    max-width: calc(100% - 500px);
    min-width: 600px;
    margin: 0 auto;
    color: ${token.colorText};
  `,
  senderCompact: css`
    width: 100%;
    max-width: 100%;
    min-width: 0;
    margin: 0;
    border-radius: 0 !important;

  `,
  senderFlat: css`
    .ant-sender {
      border-radius: 0 !important;
    }
  `,
}));

const REPORT_PROMPTS = [
  {
    key: 'report',
    description: locale.generateAnalysisReport,
    icon: <FileSearchOutlined />,
  },
];

const CHART_PROMPTS = [
  {
    key: 'chart',
    description: locale.generateEchartsChart,
    icon: <BarChartOutlined />,
  },
];


const AgentInfo: {
  [key: string]: {
    icon: React.ReactNode;
    label: string;
    zh_label: string;
    skill: SenderProps['skill'];
    zh_skill: SenderProps['skill'];
    slotConfig: SenderProps['slotConfig'];
    zh_slotConfig: SenderProps['slotConfig'];
  };
} = {
  ai_writing: {
    icon: <EditOutlined />,
    label: 'Writing',
    zh_label: '生成报告',
    skill: {
      value: 'writing',
      title: 'Writing Assistant',
      closable: true,
    },
    zh_skill: {
      value: 'writing',
      title: '生成报告',
      closable: true,
    },
    slotConfig: [
      { type: 'text', value: 'Please write a report about ' },
      {
        type: 'select',
        key: 'date_type',
        props: {
          options: ['2023','2024','2025'],
          placeholder: '请选择年份',
        },
      },
      { type: 'text', value: '年' },
      {
        type: 'select',
        key: 'region_type',
        props: {
          options: ['上城区'],
          placeholder: '请选择区域',
        },
      },
    ],
    zh_slotConfig: [
      { type: 'text', value: '请帮我生成一篇关于' },
      {
        type: 'select',
        key: 'date_type',
        props: {
          options: ['2023','2024','2025'],
          placeholder: '请选择年份',
        },
      },
      { type: 'text', value: '年' },
      {
        type: 'select',
        key: 'region_type',
        props: {
          options: ['上城区'],
          placeholder: '请选择区域',
        },
      },
      { type: 'text', value: '的年度报告' },
    ],
  },
};



// TODO ------------------------------------ -type---------------------------------
export interface ChatSenderProps {
  inputValue?: string;
  setInputValue?: (value: string) => void;
  isRequesting: boolean;
  onSubmit: (value: string, isDeepThinking: boolean, isChatBI?: boolean) => void;
  abort?: () => void;
  isDeepThinking: boolean;
  setIsDeepThinking: (value: boolean) => void;
  isChatBI?: boolean;
  onToggleChatBI?: () => void;
  onExitChatBI?: () => void;
  timeOptions?: string[];
  placeOptions?: string[];
  isNewConversation?: boolean;
  placeholder?: string;
  showSkills?: boolean;
  showChatBISwitch?: boolean;
  flatCorners?: boolean;
  onRegisterInputSetter?: (setter: (value: string) => void) => void;
}



const ChatSender: React.FC<ChatSenderProps> = ({
  inputValue,
  setInputValue,
  isRequesting,
  onSubmit,
  abort,
  isDeepThinking,
  setIsDeepThinking,
  isChatBI = false,
  onToggleChatBI,
  onExitChatBI,
  timeOptions = [],
  placeOptions = [],
  isNewConversation,
  placeholder,
  showSkills = true,
  showChatBISwitch = true,
  flatCorners = false,
  onRegisterInputSetter,
}) => {
  useRenderCount('CHAT_SENDER');
  const [innerValue, setInnerValue] = useState('');
  const resolvedInputValue = inputValue ?? innerValue;
  const setValue = useCallback((value: string) => {
    if (setInputValue) {
      setInputValue(value);
      return;
    }
    setInnerValue(value);
  }, [setInputValue]);

  React.useEffect(() => {
    if (onRegisterInputSetter) {
      onRegisterInputSetter(setValue);
    }
  }, [onRegisterInputSetter, setValue]);
  const safeAbort = useCallback(() => {
    try {
      if (typeof abort === 'function') {
        abort();
      } else {
        console.warn('abort function is undefined, cannot cancel request');
      }
    } catch (error) {
      console.error('Error occurred while trying to abort request:', error);
    }
  }, [abort]);
  const { styles } = useStyle();

  //TODO -------------------------------------state---------------------------------
  const [attachmentsOpen, setAttachmentsOpen] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<GetProp<typeof Attachments, 'items'>>([]);
  const [messageApi] = message.useMessage();
  const [showFilePreview, setShowFilePreview] = useState(false);
  const [filesToPreview, setFilesToPreview] = useState<GetProp<typeof Attachments, 'items'>>([]);
  const [activeAgentKey, setActiveAgentKey] = useState('ai_writing');
  const resolvedTimeOptions = timeOptions.length > 0 ? timeOptions : ['2023', '2024', '2025'];
  const resolvedPlaceOptions = placeOptions.length > 0 ? placeOptions : ['上城区'];
  const buildWritingSlotConfig = (prefix: string, suffix?: string): SlotConfig => ([
    { type: 'text', value: prefix } as SlotConfigItem,
    {
      type: 'select',
      key: 'date_type',
      props: {
        options: resolvedTimeOptions,
        placeholder: '请选择年份',
        placement: 'topLeft',
      },
    } as SlotConfigItem,
    { type: 'text', value: '年' } as SlotConfigItem,
    {
      type: 'select',
      key: 'region_type',
      props: {
        options: resolvedPlaceOptions,
        placeholder: '请选择区域',
        placement: 'topLeft',
      },
    } as SlotConfigItem,
    ...(suffix ? [{ type: 'text', value: suffix } as SlotConfigItem] : []),
  ]);
  const slotConfig = React.useMemo(() => {
    if (activeAgentKey !== 'ai_writing') {
      return AgentInfo[activeAgentKey];
    }
    return {
      ...AgentInfo.ai_writing,
      slotConfig: buildWritingSlotConfig('Please write a report about '),
      zh_slotConfig: buildWritingSlotConfig('请帮我生成一篇关于', '的年度报告'),
    };
  }, [activeAgentKey, resolvedTimeOptions, resolvedPlaceOptions]);
  const [isWritingAssistantEnabled, setIsWritingAssistantEnabled] = useState(false);

  const senderZhRef = useRef<GetRef<typeof Sender>>(null);

  React.useEffect(() => {
    if (!isNewConversation) {
      return;
    }
    if (!showSkills) {
      return;
    }
    setValue('');
    setIsWritingAssistantEnabled(false);
    senderZhRef.current?.clear?.();
  }, [isNewConversation, setValue, showSkills]);
  const handleWritingSkillClose = useCallback(() => {
    if (!showSkills) {
      return;
    }
    setIsWritingAssistantEnabled(false);
    setValue('');
    senderZhRef.current?.clear?.();
  }, [setValue, showSkills]);
  const writingSkill = React.useMemo<SenderProps['skill']>(() => {
    if (!showSkills || !isWritingAssistantEnabled || !slotConfig?.zh_skill?.value) {
      return undefined;
    }
    return {
      ...slotConfig.zh_skill,
      value: slotConfig.zh_skill.value,
      closable: {
        onClose: handleWritingSkillClose,
      },
    };
  }, [showSkills, isWritingAssistantEnabled, slotConfig, handleWritingSkillClose]);

  //TODO -------------------------------------function---------------------------------
  const handleSend = useCallback(() => {
    if (resolvedInputValue.trim() || attachedFiles.length > 0) {
      onSubmit(resolvedInputValue, isDeepThinking, isChatBI);
      setValue('');
    }
  }, [resolvedInputValue, attachedFiles.length, onSubmit, isDeepThinking, isChatBI, setValue]);
  const handleBeforeUpload = (file: File) => {
    console.log('上传文件前校验', file);
    return false
  };

  const handleClosePreview = () => {
    setShowFilePreview(false);
    setAttachedFiles([]);
    setFilesToPreview([]);
  };

  const fileChange = (info: any) => {
    setAttachedFiles(info.fileList);
    console.log('上传文件后', info);
  };
  
  const IconStyle = {
    fontSize: 16,
  };

  const SwitchTextStyle = {
    display: 'inline-flex',
    width: 28,
    justifyContent: 'center',
    alignItems: 'center',
  };

  const SwitchStyle = {
    fontSize: '12px',
    height: '28px',
    lineHeight: '28px',
    padding: '0 8px',
    width: '100%',
  };

  const handleChatBISwitch = useCallback(() => {
    if (isChatBI) {
      onExitChatBI?.();
      return;
    }
    onToggleChatBI?.();
  }, [isChatBI, onExitChatBI, onToggleChatBI]);



  const agentItemClick: MenuProps['onClick'] = (item) => {
    setActiveAgentKey(item.key);
    console.log('????:', item);
  };

  const zhAgentItems: MenuProps['items'] = Object.keys(AgentInfo).map((agent) => {
    const { icon, zh_label } = AgentInfo[agent];
    return {
      key: agent,
      icon,
      label: zh_label,
    };
  });

  const handleWritingAssistantToggle = (checked: boolean) => {
    if (!showSkills) {
      return;
    }
    setIsWritingAssistantEnabled(checked);
    if (checked) {
      senderZhRef.current?.insert?.([
        { type: 'text', value: '请帮我写一篇关于' },
        {
          type: 'select',
          key: 'date_type',
          props: {
            options: ['2023','2024','2025'],
            placeholder: '请选择年份',
          },
        },
        { type: 'text', value: '年 '},
        {
          type: 'select',
          key: 'region_type',
          props: {
            options: ['上城区'],
            placeholder: '请选择区域',
          },
        },
        { type: 'text', value: '的年度报告' },
      ]);
    } else {
      senderZhRef.current?.clear?.();
    }
  };
 
  //TODO -------------------------------------Component---------------------------------
  const senderHeader = (
    <Sender.Header
      title={locale.uploadFile}
      open={attachmentsOpen}
      onOpenChange={setAttachmentsOpen}
      styles={{ content: { padding: 0 } }}
    >
      <Attachments
        beforeUpload={handleBeforeUpload}
        items={attachedFiles}
        onChange={(info) => fileChange(info)}
        placeholder={(type) =>
          type === 'drop'
            ? { title: locale.dropFileHere }
            : {
              icon: <CloudUploadOutlined />,
              title: locale.uploadFiles,
              description: locale.clickOrDragFilesToUpload,
            }
        }
      />
    </Sender.Header>
  );

  return (
    <Flex
      vertical
      gap={12}
      align="center"
      style={{
        width: '100%',
      }}
    >
      {/* 提示词区域*/}
      {
        // !attachmentsOpen && (
        //   <Tabs defaultActiveKey="qa">
        //     </Tabs.TabPane>
        //     </Tabs.TabPane>
        //     </Tabs.TabPane>
        //   </Tabs>
        // )
      }
      {/* 提示词区域保持不可见*/}
      {showSkills && !isDeepThinking && (  // 鍙互鏍规嵁闇€瑕佽皟鏁存樉绀洪€昏緫
        <Tabs defaultActiveKey="qa">
          {/* 鏍囩椤靛唴瀹逛繚鎸佷笉鍙?*/}
        </Tabs>
      )}

      {/* {showFilePreview && (
        <div style={{
          position: 'fixed',
          top: 0,
          right: 0,
          width: '30%',
          height: '100vh',
          zIndex: 1000,
          background: '#fff',
          boxShadow: '-2px 0 10px rgba(0,0,0,0.1)',
          overflow: 'auto'
        }}>
          <FilePreview
            files={filesToPreview}
            onClose={handleClosePreview}
          />
        </div>
      )} */}

      {/* 输入框组件*/}
      <Sender
        ref={senderZhRef}
        skill={showSkills ? writingSkill : undefined}
        value={resolvedInputValue}
        header={senderHeader}
        onSubmit={handleSend}
        onChange={setValue}
        onCancel={safeAbort}
        footer={(actionNode)=>{
          return (
            <Flex justify="space-between" align="center">
              <Flex gap="small" align="center">
                {showSkills && (
                  <>
                    <Switch
                      value={isWritingAssistantEnabled}
                      checkedChildren={
                        <>
                          生成报告
                        </>
                      }
                      unCheckedChildren={
                        <>
                          生成报告
                        </>
                      }
                      onChange={handleWritingAssistantToggle}
                      icon={<EditOutlined />}
                      style={SwitchStyle}
                    />
                    <Switch
                      value={isChatBI}
                      checkedChildren={
                        <>
                          ChatBI
                        </>
                      }
                      unCheckedChildren={
                        <>
                          ChatBI
                        </>
                      }
                      onChange={handleChatBISwitch}
                      icon={<BarChartOutlined />}
                      style={SwitchStyle}
                    />
                  </>
                )}
                {!showSkills && showChatBISwitch && (
                  <Switch
                    value={isChatBI}
                    checkedChildren={
                      <>
                        ChatBI
                      </>
                    }
                    unCheckedChildren={
                      <>
                        ChatBI
                      </>
                    }
                    onChange={handleChatBISwitch}
                    icon={<BarChartOutlined />}
                    style={SwitchStyle}
                  />
                )}
              </Flex>
              {actionNode}
            </Flex>
          )
        }}
        slotConfig={showSkills && isWritingAssistantEnabled ? slotConfig.zh_slotConfig : undefined}
        loading={isRequesting}
        className={`${isChatBI ? styles.senderCompact : styles.sender} ${flatCorners ? styles.senderFlat : ''}`}
        allowSpeech
        suffix={false}
        placeholder={placeholder || locale.askOrInputUseSkills}
      />
    </Flex>
  );
};

export default React.memo(ChatSender, (prevProps, nextProps) => {
  if (
    prevProps.isRequesting !== nextProps.isRequesting &&
    prevProps.abort === nextProps.abort &&
    prevProps.inputValue === nextProps.inputValue &&
    prevProps.setInputValue === nextProps.setInputValue &&
    prevProps.onSubmit === nextProps.onSubmit &&
    prevProps.isDeepThinking === nextProps.isDeepThinking &&
    prevProps.setIsDeepThinking === nextProps.setIsDeepThinking &&
    prevProps.isChatBI === nextProps.isChatBI &&
    prevProps.onToggleChatBI === nextProps.onToggleChatBI &&
    prevProps.onExitChatBI === nextProps.onExitChatBI &&
    prevProps.onRegisterInputSetter === nextProps.onRegisterInputSetter &&
    prevProps.isNewConversation === nextProps.isNewConversation &&
    prevProps.placeholder === nextProps.placeholder &&
    prevProps.showSkills === nextProps.showSkills &&
    prevProps.showChatBISwitch === nextProps.showChatBISwitch &&
    prevProps.flatCorners === nextProps.flatCorners
  ) {
    return true;
  }
  return false;
});




