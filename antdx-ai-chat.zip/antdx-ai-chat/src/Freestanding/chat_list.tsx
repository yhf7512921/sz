﻿/*
 * @Author       : Chang xd
 * @Date         : 2025-12-02 15:00:00
 * @Description  : 独立的聊天消息列表组件
 */
import React, { useMemo } from 'react';
import { Button, Flex, Space, Divider } from 'antd';
import { createStyles } from 'antd-style';
import {
  EllipsisOutlined,
  ShareAltOutlined,
  UserOutlined,
  BarChartOutlined,
  TrophyOutlined,
  EnvironmentOutlined,
  AreaChartOutlined,
  AlertOutlined,
} from '@ant-design/icons';
import {
  Bubble,
  Prompts,
  Welcome,
} from '@ant-design/x';
import {
  User,
  Construction,
} from 'lucide-react'
import locale from '../utils/locale';
import { useRenderCount } from '../utils/useRenderCount';

const useStyle = createStyles(({ token, css }: any) => {
  return {
    chatList: css`
      display: flex;
      height: calc(100% - 120px);
      flex-direction: column;
      align-items: center;
      width: 100%;
      padding-inline: 0;
      box-sizing: border-box;
      
      overflow: hidden;
    `,
    placeholder: css`
      padding-top: 32px;
      width: 100%;
      padding-inline: 0;
      box-sizing: border-box;
    `,
    chatPrompt: css`
      .ant-prompts-label {
        color: #000000e0 !important;
      }
      .ant-prompts-desc {
        color: #000000a6 !important;
        width: 100%;
      }
      .ant-prompts-icon {
        color: #000000a6 !important;
      }
    `,
    // 热门问题卡片样式
    hotQuestionCard: css`
      flex: 1;
      min-width: 250px;
      max-width: 300px;
      min-height: 200px;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-self: stretch;
      borderRadius: 12px;
      overflow: hidden;
      boxShadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 16px;
      text-align: center;
      
      &:hover {
        boxShadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        transform: translateY(-4px) scale(1.02);
      }
    `,
    hotQuestionBody: css`
      padding: 0 12px;
      background-color: #f3f1f1ff;
      flex: 1;
      display: flex;
      flex-direction: column;
      
      justify-content: center;
      text-align: center;
      gap: 4px;
    `,
    hotQuestionTitle: css`
      margin: 0;
      font-size: 16px;
      font-weight: 600;
      color: #000000e0;
      line-height: 22px;
      min-height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
    `,
    hotQuestionHint: css`
      margin: 0;
      font-size: 14px;
      color: #000000a6;
      line-height: 20px;
    `,
  };
});

// 聊天列表组件属性 - 新增 activeConversationKey
export interface ChatListProps {
  messages: any[];
  onSubmit: (value: string) => void;
  className: string;
  getRole: (className: string) => any;
  activeConversationKey: string;
  // 新增历史消息属性
  historyMessages?: any[];
}



// 聊天消息列表组件
const CHAT_LIST: React.FC<ChatListProps> = ({
  messages,
  onSubmit,
  className,
  getRole,
  activeConversationKey,
  historyMessages = [],
}) => {
  useRenderCount('CHAT_LIST');
  const { styles } = useStyle();

  // 合并历史消息和当前消息，按 id 去重，避免重复渲染
  const displayMessages = React.useMemo(() => {
    const merged = [...(historyMessages || []), ...(messages || [])];
    const seen = new Set<string>();
    const result: any[] = [];
    merged.forEach((item) => {
      const key = item?.id ? String(item.id) : `${item?.message?.role ?? ''}:${item?.message?.content ?? ''}`;
      if (seen.has(key)) {
        return;
      }
      seen.add(key);
      result.push(item);
    });
    return result;
  }, [historyMessages, messages]);
  const getAgentIcon = (agentKey: string) => {
    if (agentKey === 'road-agent') {
      return <Construction className="w-5 h-5 mt-5 text-white" />
    }
    return <User className="w-5 h-5 text-white" />;
  };

  // 根据当前会话获取欢迎信息
  const getWelcomeInfo = () => {
    return {
      title: '你好，我是您的道路地下病害服务助手',
      description: '我可以帮您分析道路病害情况并生成相关报告。',
      image: '' // 临时图片地址
    };
};
  // 根据当前会话生成对应的热门问题
  const getHotQuestions = () => {
    // 道路病害服务助手的热门问题
    const roadQuestions = [
      { key: 'road-1-1', description: '我想了解各类道路病害类型有哪些？', hint: '例如：介绍常见道路地下病害类型及其特征', icon: <EnvironmentOutlined style={{ fontSize: '24px', color: '#1890ff' }} /> },
      { key: 'road-1-2', description: '查看各片区的病害情况', hint: '例如：查看 2025 上城区的道路病害分布情况', icon: <AreaChartOutlined style={{ fontSize: '24px', color: '#52c41a' }} /> },
      { key: 'road-1-3', description: '病害最多的道路排名 TOP5', hint: '例如：2025 年上城区病害最多的道路排名', icon: <AlertOutlined style={{ fontSize: '24px', color: '#faad14' }} /> },
    ];
  
    return  roadQuestions ;
  };

  const listItems = useMemo(() => {
    const historyIds = new Set(
      (historyMessages || [])
        .map((i: any) => i?.id)
        .filter((id: any) => id !== undefined && id !== null)
        .map((id: any) => String(id)),
    );
    return displayMessages?.map((i: any, index: number) => ({
      ...i.message,
      key: i.id || `message-${index}`,
      status: i.status,
      loading: i.status === 'loading',
      extraInfo: {
        ...i.extraInfo,
        isHistory: historyIds.has(String(i?.id ?? '')),
      },
    }));
  }, [displayMessages, historyMessages]);


  // 如果有历史消息或当前消息，则显示消息列表；否则显示欢迎页
  const shouldShowWelcome = displayMessages?.length === 0;

  if (!shouldShowWelcome) {
    return (
      <div className={styles.chatList}>
        <Bubble.List
          items={listItems}
          styles={{
            bubble: {
              maxWidth: 'calc(100% - 500px)',
              minWidth: 290,
              textAlign: 'left',
              fontSize: '16px',
            },
            content: {
              textAlign: 'left',
              fontSize: '16px',
            },
          }}
          role={getRole(className)}
        />
      </div>
    );
  }

  return (
    <div className={styles.chatList}>
      <Flex
        vertical
        style={{
          maxWidth: 'calc(100% - 500px)',
          minWidth: 290,
        }}
        gap={16}
        align="flex-start"
        className={styles.placeholder}
      >
        <Welcome
          style={{
            width: '100%',
            textAlign: 'left',
          }}
          variant="borderless"
          // icon={getAgentIcon(activeConversationKey)}
          icon="https://mdn.alipayobjects.com/huamei_iwk9zp/afts/img/A*s5sNRo5LjfQAAAAAAAAAAAAADgCCAQ/fmt.webp"
          title={
            <div 
              style={{
                fontSize: '28px',
                fontWeight: '600',
                background: 'linear-gradient(123deg, #1890ff 0%, #722ed1 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                color: 'transparent',
                marginBottom: '8px',
              }}
            >
              {getWelcomeInfo().title}
            </div>
          }
          description={
            <div 
              style={{
                fontSize: '16px',
                color: '#0000008c',
              }}
            >
              {getWelcomeInfo().description}
            </div>
          }
        />
        <Flex
          gap={16}
          justify="center"
          style={{
            width: '100%',
          }}
        >
          {/* 自定义热门问题卡片布局 */}
          <div style={{ width: '100%' }}>
            <Divider 
              style={{ 
                marginBottom: '16px', 
                fontSize: '16px', 
                fontWeight: '600', 
                color: '#000000a6' 
              }}
            >
              猜你想问
            </Divider>
            <Flex
              gap={16}
              justify="center"
              wrap
              align="stretch"
            >
              {getHotQuestions().map((question) => (
                <div
                  key={question.key}
                  className={styles.hotQuestionCard}
                  // 去掉前三个字符
                  onClick={() => onSubmit((question.hint).slice(3))}
                >
                  {/* 上半部分：渐变背景 + 图标 */}
                  <div
                    style={{
                      padding: '24px',
                      backgroundImage: 'linear-gradient(123deg, #e5f4ff 0%, #efe7ff 100%)',
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: '8px 8px 0 0',

                    }}
                  >
                    {question.icon}
                  </div>
                  {/* 下半部分：标题 + 提示语 */}
                  <div className={styles.hotQuestionBody}>
                    <h4 className={styles.hotQuestionTitle}>{question.description}</h4>
                    <p className={styles.hotQuestionHint}>{question.hint}</p>
                  </div>
                </div>
              ))}
            </Flex>
          </div>
        </Flex>
      </Flex>
    </div>
  );
};

export default React.memo(CHAT_LIST);




