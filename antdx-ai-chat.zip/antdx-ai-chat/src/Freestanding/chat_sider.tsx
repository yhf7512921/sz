/*
 * @Author       : Chang xd
 * @Date         : 2025-12-02 14:05:22
 * @Description  : 独立的侧边栏组件
 */
import { CheckCircleOutlined, CloseCircleOutlined, QuestionCircleOutlined, SyncOutlined, CheckOutlined, PlusOutlined, MessageTwoTone, MessageOutlined, UserOutlined } from '@ant-design/icons';
import { Avatar, Button, Select, Typography, Tooltip, Collapse, message, Divider, Dropdown, Modal } from 'antd';
import { createStyles } from 'antd-style';
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Conversations } from '@ant-design/x';
import locale from '../utils/locale';
import { useAuthStore, useConversationStore } from '../stores';
import { logoutApi } from '../utils/api';
import { useRenderCount } from '../utils/useRenderCount';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../routes/paths';

const { Option } = Select;
const { Text } = Typography;

const useStyle = createStyles(({ token, css }: any) => {
  return {
    layout: css`
      width: 100%;
      height: 100vh;
      display: flex;
      background: #fafafa;
      font-family: AlibabaPuHuiTi, ${token.fontFamily}, sans-serif;
    `,
    side: css`
      background: #fafafa;
      width: 300px;
      height: 100%;
      display: flex;
      flex-direction: column;
      padding: 0 8px;
      box-sizing: border-box;
      overflow: hidden;
    `,
    logo: css`
      display: flex;
      align-items: center;
      justify-content: start;
      padding: 0 24px;
      box-sizing: border-box;
      gap: 8px;
      margin: 24px 0;

      span {
        font-weight: bold;
        color: ${token.colorText};
        font-size: 16px;
      }
    `,
    conversations: css`
      margin-top: 2px;
      padding: 8px 0;
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      min-height: 0;
      text-align: left;

      .ant-conversations-list {
        padding-inline-start: 0;
      }
      .ant-conversations-item {
        padding: 4px 12px !important;
        min-height: 32px !important;
        height: 32px !important;
        display: flex !important;
        align-items: center !important;
        border-radius: 6px !important;
        margin-bottom: 2px !important;
        transition: all 0.3s ease !important;
        border: 1px solid transparent !important;
        font-size: 14px !important;
        font-weight: 400 !important;
        color: #000000d9 !important;
        background: transparent !important;
        cursor: pointer !important;
        line-height: 24px !important;
      }
      .ant-conversations-item:hover {
        background: rgba(24, 144, 255, 0.08) !important;
        border-color: rgba(24, 144, 255, 0.2) !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 2px 8px rgba(24, 144, 255, 0.1) !important;
      }
      .ant-conversations-item-active {
        line-height: 24px !important;
        height: 24px !important;
        background: linear-gradient(
          135deg,
          rgba(24, 144, 255, 0.12) 0%,
          rgba(24, 144, 255, 0.06) 100%
        ) !important;
        border-color: #1890ff !important;
        color: #1890ff !important;
        font-weight: 500 !important;
        box-shadow: 0 2px 8px rgba(24, 144, 255, 0.15) !important;
      }
      .ant-conversations-item-title {
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        flex: 1 !important;
      }
    `,
    // 底部样式
    sideFooter: css`
      margin-top: auto;
      padding: 12px 8px 16px 8px;
      display: flex;
      align-items: center;
      justify-content: flex-start;
    `,
    newChatButton: css`
      background-color: rgb(35, 129, 255);
      border-color: rgb(35, 129, 255);

      &:hover,
      &:focus {
        background-color: rgb(64, 150, 255) !important;
        border-color: rgb(64, 150, 255) !important;
      }
    `,
    avatarTrigger: css`
      cursor: pointer;
    `,
    footerLabel: css`
      font-size: 12px;
      color: ${token.colorTextSecondary};
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    `,

    agentStatus: css`
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      font-weight: 500;
    `,
    // 添加分隔样式
    separator: css`
      height: 1px;
      background: ${token.colorBorderSecondary};
      margin: 1px 0 8px 0;
    `,
    separatorLabel: css`
      font-size: 12px;
      color: ${token.colorTextSecondary};
      margin-bottom: 15px;
      margin-left:5%;
    `,
    // 历史对话分隔样式
    historySeparator: css`
      height: 1px;
      background: ${token.colorBorderSecondary};
      margin: 28px 0 8px 0;
    `,
    // 历史消息容器样式
    historyMessages: css`
      overflow-y: auto;
      max-height: 200px;
    `,
    // 固定对话项样式
    fixedConversationItem: css`
      padding: 8px 16px;
      cursor: pointer;
      border-radius: 6px;
      margin-bottom: 4px;
      backgroundColor: transparent;
      color: inherit;
      font-size: 14px;
      transition: all 0.3s ease;
      border: 1px solid transparent;
      white-space: nowrap; // 防止换行
      overflow: hidden; // 隐藏超出部分
      text-overflow: ellipsis; // 显示省略号
      
      &:hover {
        backgroundColor: white !important;
        border-color: #e0e0e0;
        transform: translateY(-2px) scale(1.02);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
      }
      
      &.active {
        backgroundColor: linear-gradient(135deg, #e6f7ff 0%, #bae7ff 100%);
        color: #1890ff;
        font-weight: 500;
        font-size: 14px;
        border-color: #91d5ff;
        box-shadow: 0 4px 16px rgba(24, 144, 255, 0.15);
        transform: translateY(-2px) scale(1.02);
      }
    `,
    // 自定义 Collapse label 样式
    collapseLabel: css`
      display: flex;
      align-items: center;
      width: 100%;
      font-size: 12px;
      font-weight: 500;
      color: ${token.colorTextSecondary};
      &::before,
      &::after {
        content: '';
        flex: 1;
        height: 1px;
        background: ${token.colorBorderSecondary};
      }
      &::before {
        margin-right: 8px;
      }
      &::after {
        margin-left: 8px;
      }
    `,
    // Collapse 组件样式
    collapse: css`
      .ant-collapse-header {
        padding: 8px 12px !important;
        font-size: 12px !important;
      }
      .ant-collapse-content-box {
        padding: 4px 0 !important;
      }
      .ant-collapse-content {
        overflow-y: auto;
        overflow-x: hidden;
      }
    `,
    // 历史对话标题样式
    conversationsHeader: css`
      padding: 8px 12px;
      font-size: 12px;
      color: ${token.colorTextSecondary};
      display: flex;
      align-items: center;
      margin-bottom: 8px;
    `,
  };
});

// 会话管理组件属性 - 新增智能体相关属性
export interface ChatSiderProps {
  messages?: any[];
  conversations: any[];
  activeConversationKey: string;
  setActiveConversationKey: (key: string) => void;
  setConversations: any;
  onConversationChange?: (key: string) => void;
  activeAgent: string;
  setActiveAgent: (agent: string) => void;
  // 新增历史消息属性
  fixedConversations: any[];
  // 新增热门问题属性
  hotQuestions: Array<{key: string, label: string}>;
  onHotQuestionClick: (question: string) => void;
  setCurrentHistoryMessages: (messages: any[]) => void;
}

// 智能体状态类型
type AgentStatus = 'running' | 'stopped' | 'error';

// 会话管理组件
const CHAT_SIDER: React.FC<ChatSiderProps> = ({
  messages = [],
  conversations,
  activeConversationKey,
  setActiveConversationKey,
  setConversations,
  onConversationChange,
  activeAgent,
  setActiveAgent,
  fixedConversations,
  hotQuestions,
  onHotQuestionClick,
  setCurrentHistoryMessages,
}) => {
  useRenderCount('CHAT_SIDER');
  const { styles } = useStyle();
  const navigate = useNavigate();
  const { role, username, logout } = useAuthStore();
  const { setCurrentConversationId, isNewConversation, setIsNewConversation, nextNewConversationId, setNextNewConversationId, newLabelId, newLabel, setNewLabelId, setNewLabel } = useConversationStore();

  const handleUserMenuClick = ({ key }: { key: string }) => {
    if (key === 'account') {
      navigate(ROUTES.accountManagement);
      return;
    }
    if (key === 'logout') {
      Modal.confirm({
        title: '确认退出登录？',
        content: '退出后需要重新登录才能继续使用。',
        okText: '退出登录',
        cancelText: '取消',
        onOk: async () => {
          try {
            await logoutApi();
          } catch (error: any) {
            message.error(error?.message || '退出登录失败，请稍后再试');
          } finally {
            logout();
            navigate(ROUTES.login);
          }
        },
      });
    }
  };

  const userMenuItems = [
    {
      key: 'user',
      label: '\u5f53\u524d\u767b\u5f55\uff1a' + (username || '\u672a\u77e5\u7528\u6237'),
      disabled: true,
    },
    {
      type: 'divider' as const,
    },
    ...(role === 'admin'
      ? [
          {
            key: 'account',
            label: '\u540e\u53f0\u7ba1\u7406',
          },
        ]
      : []),
    {
      key: 'logout',
      label: '\u9000\u51fa\u767b\u5f55',
      danger: true,
    },
  ];
  
  // 使用 ref 存储 conversations 的最新值，避免无限循环
  const conversationsRef = useRef(conversations);
  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);
  
  // 监听newLabel变化，更新对话label
  useEffect(() => {
    if (newLabel && newLabelId) {
      const updatedConversations = conversations.map(conv => 
        conv.key === newLabelId 
          ? { ...conv, label: newLabel }
          : conv
      );
      
      if (JSON.stringify(updatedConversations) !== JSON.stringify(conversations)) {
        setConversations(updatedConversations);
      }
      
      setNewLabelId('');
      setNewLabel('');
    }
  }, [newLabel, newLabelId, conversations, setConversations, setNewLabelId, setNewLabel]);
  
  // 智能体列表和状态管理
  const ALL_AGENTS = ["恒脑智能体", "Dify智能体", "FastGPT", "Coze智能体"];
  const [agentStatus, setAgentStatus] = useState<Record<string, AgentStatus>>({
    "恒脑智能体": "running",
    "Dify智能体": "running",
    "FastGPT": "running",
    "Coze智能体": "running"
  });
  
  // 根据当前会话获取可用智能体 - 使用useCallback优化
  const getAvailableAgents = useCallback((conversationKey: string) => {
    // 道路病害服务助手只能使用恒脑智能体
    if (conversationKey === 'road-agent') {
      return ["恒脑智能体"];
    }
    return ALL_AGENTS;
  }, []);
  
  // 会话切换时自动调整智能体
  useEffect(() => {
    const available = getAvailableAgents(activeConversationKey);
    if (!available.includes(activeAgent)) {
      setActiveAgent(available[0]);
    }
  }, [activeConversationKey, getAvailableAgents]);
  
  // 获取状态显示组件
  const getStatusComponent = (status: AgentStatus) => {
    switch(status) {
      case 'running':
        return <CheckCircleOutlined style={{ color: '#52c41a', fontSize: 14 }} />;
      case 'stopped':
        return <CloseCircleOutlined style={{ color: '#faad14', fontSize: 14 }} />;
      case 'error':
        return <CloseCircleOutlined style={{ color: '#f5222d', fontSize: 14 }} />;
      default:
        return <SyncOutlined spin style={{ color: '#1890ff', fontSize: 14 }} />;
    }
  };



  return (
    <div className={styles.side}>
      {/* 🌟 Logo */}
      <div className={styles.logo}>
        <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'}}>
          <img
            src="/assets/icon/icon.png"
            draggable={false}
            alt="logo"
            width={64}
            height={64}
            style={{ borderRadius: '8px', objectFit: 'cover' }}
          />
        </div> 
        <span style={{ fontSize: '16px', fontWeight: '600' }}>道路地下病害服务助手 v1.1</span>
      </div>
      
      {/* 🌟 新对话按钮 */}
      <div style={{ padding: '8px 16px', marginBottom: '8px' }}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => {
            if (isNewConversation) {
              message.warning('当前已经处于新对话了');
              return;
            }
            
            // 生成新的对话ID并更新 nextNewConversationId
            setNextNewConversationId(`conv_${Date.now()}`);
            
            // 更新全局状态：准备开始新对话
            setIsNewConversation(true);
            setCurrentConversationId('');
            setActiveConversationKey('');
          }}
          className={styles.newChatButton}
          style={{
            width: '100%',
            height: '40px',
            borderRadius: '8px',
            fontWeight: '500',
            fontSize: '14px',
          }}
        >
          新对话
        </Button>
        {role === 'admin' && (
          <Button
            style={{
              marginTop: '8px',
              width: '100%',
              height: '40px',
              borderRadius: '8px',
              fontWeight: '500',
              fontSize: '14px',
            }}
            onClick={() => navigate(ROUTES.accountManagement)}
          >
            {'\u540e\u53f0\u7ba1\u7406'}
          </Button>
        )}
      </div>
      
      {/* 🌟 会话列表 */}
      <div className={styles.conversations}>
        {/* 🌟 热门问题 - 直接展开显示 */}
        <div className={styles.separator}></div>
        <div className={styles.separatorLabel}>热门问题</div>
        {hotQuestions.map((question) => (
          <div
            key={question.key}
            className={styles.conversations}
            style={{
              padding: '4px 12px',
              cursor: 'pointer',
              borderRadius: '6px',
              marginBottom: '2px',
              transition: 'all 0.3s ease',
              border: '1px solid transparent',
              fontSize: '14px',
              fontWeight: '400',
              color: '#000000d9',
              background: 'transparent',
              lineHeight: '24px',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
            onClick={() => onHotQuestionClick(question.label)}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(24, 144, 255, 0.08)';
              e.currentTarget.style.borderColor = 'rgba(24, 144, 255, 0.2)';
              e.currentTarget.style.transform = 'translateY(-1px)';
              e.currentTarget.style.boxShadow = '0 2px 8px rgba(24, 144, 255, 0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.borderColor = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            {question.label}
          </div>
        ))}

        {/* 🌟 历史对话 - 直接展开显示 */}
        <div className={styles.historySeparator}></div>
        <div className={styles.separatorLabel}>历史对话</div>
        <Conversations
            items={conversations.map(({ key, label }) => ({
              key,
              label: (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  {key === activeConversationKey ? (
                    <MessageTwoTone twoToneColor="#1890ff" />
                  ) : (
                    <MessageOutlined />
                  )}
                  <span style={{
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}>{label}</span>
                </div>
              ),
            }))}
            className={styles.conversations}
            activeKey={activeConversationKey}
            onActiveChange={(key) => {
              setIsNewConversation(false);
              setCurrentConversationId(key);
              setActiveConversationKey(key);
              onConversationChange?.(key);
            }}
            groupable
          />
      </div>

      <div className={styles.sideFooter}>
        <Dropdown menu={{ items: userMenuItems, onClick: handleUserMenuClick }} placement="topRight">
          <Avatar className={styles.avatarTrigger} icon={<UserOutlined />} />
        </Dropdown>
      </div>
    </div>
  );
}

export default React.memo(CHAT_SIDER);
