﻿/*
 * @Author       : Chang xd
 * @Date         : 2025-12-01 15:31:56
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-02-11 15:23:21
 * @Description  : 主组件 - 负责状态管理和组件组合
 */
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { message } from 'antd';
import { createStyles } from 'antd-style';
import { XProvider } from '@ant-design/x';
import type { ThoughtChainItemProps } from '@ant-design/x';
import {
  DeepSeekChatProvider,
  SSEFields,
  useXChat,
  useXConversations,
  XModelMessage,
  XModelParams,
  XModelResponse,
  XRequest,
} from '@ant-design/x-sdk';
import { useMarkdownTheme } from '../markdown/demo/_utils';
import locale from '../utils/locale';
import { API_CONFIG, forceLogout } from '../utils/api';
import { getConversations, getConversationMessages, getTimeOptions, getPlaceOptions } from '../utils/api';
import { useAuthStore, useConversationStore } from '../stores';
import type { ComponentProps } from '@ant-design/x-markdown';
import XMarkdown from '@ant-design/x-markdown';
import '@ant-design/x-markdown/themes/light.css';
import '@ant-design/x-markdown/themes/dark.css';
import { GlobalOutlined, SyncOutlined } from '@ant-design/icons';
import { Actions, Think, ThoughtChain } from '@ant-design/x';


// ==================== Component ====================
import CHAT_SIDER from './chat_sider';
import CHAT_SENDER from './chat_sender';
import CHAT_LIST from './chat_list';
import { ROUTES } from '../routes/paths';
import DataChart from '../components/DataChart';
import CustomTable from '../components/Table';
import CardDashBoard from '../components/CardDashBoard';
import PictureView from '../components/PictureView';
import CollectionIndex from '../components/CollectionIndex';
import MarkdownToPdfDialog from '../components/MarkdownToPdfDialog';
import CustomThoughtChain from '../components/CustomThoughtChain';
import CustomFileCard from '../components/FileCard';
import { useRenderCount } from '../utils/useRenderCount';
// ==================== Middleware ====================
import createMiddlewares from './middleware';
// ==================== Style ====================
const useStyle = createStyles(({ token, css }: any) => {
  return {
    layout: css`
      width: 100%;
      height: 100vh;
      display: flex;
      background: #FAFAFA;
      font-family: AlibabaPuHuiTi, ${token.fontFamily}, sans-serif;
    `,
    chat: css`
      height: 100%;
      width: calc(100% - 300px);
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      padding-block: ${token.paddingLG}px;
      padding-inline: 0;
      background: #ffffff;
      justify-content: space-between;
      .ant-bubble-content-updating {
        background-image: linear-gradient(90deg, #ff6b23 0%, #af3cb8 31%, #53b6ff 89%);
        background-size: 100% 2px;
        background-repeat: no-repeat;
        background-position: bottom;
      }
      border-top-left-radius: 25px;
      border-bottom-left-radius: 25px;
      transition: all 0.3s ease-in-out;

      /* 用户气泡样式 */
      .ant-bubble-content-string {
        background-color: rgba(216, 231, 251, 1) !important;
      }
      /* 系统返回气泡样式 */
      .ant-bubble-placement-start  {
        background-color: #C8C8C8 !important;
      }
    `,
    siderWrapper: css`
      transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
    `,

  };
});

const replaceWarps = (content: string) => {
  return content.replace(/\n/g, ' ').replace(/\r/g, ' ');
}
const string1 = '你好\n1,你好,\nfoo'
console.log(replaceWarps(string1))

// ==================== Static Config ====================
const HISTORY_MESSAGES: Record<string, any[]> = {
  'default-1': [
    {
      message: { role: 'user', content: locale.howToQuicklyInstallAndImportComponents },
      status: 'success',
    },
    {
      message: {
        role: 'assistant',
        content: locale.aiMessage_2,
      },
      status: 'success',
    },
  ],
  'default-2': [
    { message: { role: 'user', content: locale.newAgiHybridInterface }, status: 'success' },
    {
      message: {
        role: 'assistant',
        content: locale.aiMessage_1,
      },
      status: 'success',
    },
  ],
};

const THOUGHT_CHAIN_CONFIG = {
  loading: {
    title: locale.modelIsRunning,
    status: 'loading',
  },
  updating: {
    title: locale.modelIsRunning,
    status: 'loading',
  },
  success: {
    title: locale.modelExecutionCompleted,
    status: 'success',
  },
  error: {
    title: locale.executionFailed,
    status: 'error',
  },
  abort: {
    title: locale.aborted,
    status: 'abort',
  },
};

const CHATBI_CONVERSATION_PREFIXES = ['chatbi_', 'chatbi_id'];

// 同时修改默认会话为空数组
const DEFAULT_CONVERSATIONS_ITEMS: Array<{ key: string; label: string }> = [];

// 热门问题数据
const HOT_QUESTIONS = [
  { key: 'hot-1', label: '请问2025年检测的之江路发现了多少处病害，给出所有病害的相关信息' },
  { key: 'hot-2', label: '之江路在2025年道路检测时具体是哪一段？检测里程多少？' },
  { key: 'hot-3', label: '请问2025年上城区共发现几处病害？哪个标段的病害数量最多？' },
  { key: 'hot-4', label: '上城2025年检测出的脱空病害有哪些? '},
  { key: 'hot-5', label: '我想知道2025年上城区标项一项目的检测人员及设备配置? '},
  // { key: 'hot-6', label: '道路的“机动车道”、“非机动车道”、“人行道”在2025年上城区标项一项目检测中是否都覆盖？' },
  // { key: 'hot-7', label: '请问2025年上城区每个标项的探测范围是什么，共检测了多少条路、总里程是多少�? },
  // { key: 'hot-8', label: '请解释道路病害中的“脱空”是什么？' },
  // { key: 'hot-9', label: '为什么需要进行钻探验证？验证的基本程序是什么？' },
  // { key: 'hot-10', label: '24年浜河路发现的病害问题有没有完成整改和复测？' },
];


// ==================== Type ====================
interface ChatMessage extends XModelMessage {
  extraInfo?: {
    isHistory?: boolean;
  };
}

// ==================== Context ====================
const ChatContext = React.createContext<{
  onReload?: ReturnType<typeof useXChat>['onReload'];
  setMessage?: ReturnType<typeof useXChat<ChatMessage>>['setMessage'];
}>({});

// ==================== Chat Provider ====================

const historyMessageFactory = (conversationKey: string) => {
  return HISTORY_MESSAGES[conversationKey] || [];
};

// ==================== ChatList Think Component ====================
// 将ThinkComponent定义在组件外部，确保引用稳定
const ThinkComponent = React.memo((props: ComponentProps) => {
  const [title, setTitle] = React.useState(`${locale.deepThinking}...`);
  const [loading, setLoading] = React.useState(true);
  const [blink, setBlink] = React.useState(true);
  const [expanded, setExpanded] = React.useState(true);

  React.useEffect(() => {
    if (props.streamStatus === 'done') {
      setTitle(locale.completeThinking);
      setLoading(false);
      setBlink(false);
      setExpanded(false); // 深度思考流结束后折叠Think组件
    }
  }, [props.streamStatus]);

  // 处理展开/折叠交互
  const handleExpand = (newExpanded: boolean) => {
    setExpanded(newExpanded);
  };

  return (
    <div style={{ marginBottom: '16px', fontSize: '14px' }}>
      <Think 
        title={title} 
        loading={loading} 
        blink={blink} 
        style={{ fontSize: '14px' }} 
        expanded={expanded} // 使用受控模式控制折叠状态
        onExpand={handleExpand} // 添加展开/折叠回调，处理用户点击交互
      >
        {props.children}
      </Think>
    </div>
  );
});

// ==================== Footer Component ====================
// 将Footer组件定义在组件外部，确保引用稳定
const Footer: React.FC<{
  id?: string | number;
  content: string;
  status?: string;
  extraInfo?: ChatMessage['extraInfo'];
}> = ({ id, content, status, extraInfo }) => {
  const context = React.useContext(ChatContext);
  const isHistory = Boolean(extraInfo?.isHistory);
  const Items: any[] = [];
  if (!isHistory) {
    Items.push({
      key: 'retry',
      label: locale.retry,
      icon: <SyncOutlined />,
      onItemClick: () => {
        if (id) {
          context?.onReload?.(id, {
            userAction: 'retry',
          });
        }
      },
    });
  }
  Items.push({
    key: 'copy',
    actionRender: <Actions.Copy text={content} />,
  });
  return status !== 'updating' && status !== 'loading' ? (
    <div style={{ display: 'flex' }}>{id && <Actions items={Items} />}</div>
  ) : null;
};

const Independent: React.FC = () => {
  useRenderCount('Freestanding');
  // ==================== Chat Provider ====================
  const providerCaches = useRef(new Map<string, DeepSeekChatProvider>()).current;
  const navigate = useNavigate();

   
  // ==================== Runtime ====================
  // 恢复原有逻辑：使DeepSeekChatProvider 连接到官方API
  const providerFactory = useCallback((conversationKey: string) => {
    if (!providerCaches.get(conversationKey)) {
      providerCaches.set(
        conversationKey,
        new DeepSeekChatProvider({
          request: XRequest<XModelParams, Partial<Record<SSEFields, XModelResponse>>>(
            'https://api.x.ant.design/api/llm_siliconflow_deepSeek-r1-distill-1wen-7b',
            {
              manual: true,
              params: {
                stream: true,
                thinking: {
                  type: 'enabled',
                },
                model: 'deepSeek-r1-distill-1wen-7b',
              },
            },
          ),
        }),
      );
    }
    return providerCaches.get(conversationKey);
  }, [providerCaches]);

  const { styles } = useStyle();
  const { isNewConversation, setIsNewConversation, currentConversationId, setCurrentConversationId, nextNewConversationId, setNextNewConversationId } = useConversationStore();
  
  // ==================== State ====================
  const {
    conversations,
    activeConversationKey,
    setActiveConversationKey,
    setConversations,
  } = useXConversations({
    defaultConversations: DEFAULT_CONVERSATIONS_ITEMS,
  });

  // 获取主题className - 直接使用返回值，避免数组引用变化
  const [themeClassName] = useMarkdownTheme();
  // 使用稳定的字符串作为依赖项
  const className = themeClassName;

  const [messageApi, contextHolder] = message.useMessage();
  const chatSenderSetValueRef = useRef<(value: string) => void>(() => {});
  const registerChatSenderSetter = useCallback((setter: (value: string) => void) => {
    chatSenderSetValueRef.current = setter;
  }, []);
  const [activeAgent, setActiveAgent] = useState("恒脑智能");
  const [isDeepThinking, setIsDeepThinking] = useState(true);
  const [timeOptions, setTimeOptions] = useState<string[]>([]);
  const [placeOptions, setPlaceOptions] = useState<string[]>([]);
  const [historyMessagesMap, setHistoryMessagesMap] = useState<Record<string, any[]>>({});
  const [currentHistoryMessages, setCurrentHistoryMessages] = useState<any[]>([]);
  const MAX_HISTORY_CACHE = Number(process.env.REACT_APP_MAX_HISTORY_CACHE) || 20;
  const historyCacheOrderRef = useRef<string[]>([]);
  
  // 存储从后端获取的历史消息
  const [isInitialized, setIsInitialized] = useState(false);
  

  // 初始化：刷新时设为新对话 + 获取对话列表
  useEffect(() => {
    // 一次性设置初始对话状态，减少多次 setState
    useConversationStore.setState({
      isNewConversation: true,
      nextNewConversationId: `conv_${Date.now()}`,
    });

    const initConversations = async () => {
      if (isInitialized) return;
      try {
        const result = await getConversations();
        if (result.code === 200) {
          const filteredConversations = result.data.conversations.filter((conversation) => {
            const key = String(conversation.key).toLowerCase();
            return !CHATBI_CONVERSATION_PREFIXES.some((prefix) => key.startsWith(prefix));
          });
          setConversations(filteredConversations);
          setIsInitialized(true);
          // 确保初始进入页面时不选中任何对话
          if (activeConversationKey !== '') {
            setActiveConversationKey('');
          }
          if (currentConversationId !== '') {
            setCurrentConversationId('');
          }
        }
      } catch (error) {
        console.error('获取对话列表失败:', error);
        messageApi.error('获取对话列表失败');
      }
    };

    initConversations();
  }, []); // 只在组件挂载时执行一次

  useEffect(() => {
    let isMounted = true;
    const loadOptions = async () => {
      try {
        const [timeRes, placeRes] = await Promise.all([
          getTimeOptions(),
          getPlaceOptions(),
        ]);
        if (!isMounted) return;
        const timeData = timeRes.type === 'time'
          ? timeRes.data?.time
          : timeRes.data?.time;
        const placeData = placeRes.type === 'place'
          ? (placeRes.data?.place || placeRes.data?.palce)
          : (placeRes.data?.place || placeRes.data?.palce);
        if (Array.isArray(timeData)) {
          setTimeOptions(timeData);
        }
        if (Array.isArray(placeData)) {
          setPlaceOptions(placeData);
        }
      } catch (error) {
        console.error('获取时间/区域选项失败:', error);
        messageApi.error('获取时间/区域选项失败');
      }
    };
    loadOptions();
    return () => {
      isMounted = false;
    };
  }, [messageApi]);

  // 获取特定对话的消息
  const fetchMessages = useCallback(async (conversationKey: string) => {
    try {
      const result = await getConversationMessages(conversationKey);
      if (result.code === 200) {
        setHistoryMessagesMap((prev) => {
          const next = {
            ...prev,
            [conversationKey]: result.data.messages,
          };
          const order = historyCacheOrderRef.current.filter((key) => key !== conversationKey);
          order.push(conversationKey);

          let safety = order.length;
          while (order.length > MAX_HISTORY_CACHE && safety > 0) {
            const oldest = order[0];
            if (!oldest) {
              order.shift();
              break;
            }
            if (oldest === activeConversationKey) {
              order.shift();
              order.push(oldest);
            } else {
              order.shift();
              delete next[oldest];
            }
            safety -= 1;
          }

          historyCacheOrderRef.current = order;
          return next;
        });
        setCurrentHistoryMessages(result.data.messages);
        console.log('获取历史消息成功:', result.data.messages);
      }
    } catch (error) {
      console.error('获取历史消息失败:', error);
      messageApi.error('获取历史消息失败');
    }
  }, [activeConversationKey, messageApi, setHistoryMessagesMap, setCurrentHistoryMessages]);

  // 监听 activeConversationKey 变化，获取对应的消息
  useEffect(() => {
    if (activeConversationKey) {
      const conversation = conversations.find(c => c.key === activeConversationKey);
      if (conversation?.isNew || isNewConversation) {
        setCurrentHistoryMessages([]);
        return;
      }
      const cachedMessages = historyMessagesMap[activeConversationKey];
      if (cachedMessages !== undefined) {
        setCurrentHistoryMessages(cachedMessages);
        return;
      }
      fetchMessages(activeConversationKey);
    } else {
      // 当 activeConversationKey 为空时，清空历史消息
      setCurrentHistoryMessages([]);
    }
  }, [activeConversationKey, fetchMessages, conversations, isNewConversation, historyMessagesMap, setCurrentHistoryMessages]);

  // 确保 currentConversationId 和 activeConversationKey 始终同步
  useEffect(() => {
    setCurrentConversationId(activeConversationKey);
  }, [activeConversationKey, setCurrentConversationId]);

  // ==================== Runtime ====================
  // 创建中间件实例
  const middlewares = createMiddlewares();
  
  const { onRequest, messages, isRequesting, abort, onReload: originalOnReload, setMessage, setMessages } = useXChat<ChatMessage>({
    // 原有逻辑：使providerFactory
    // provider: providerFactory(activeConversationKey),
    // 本地后端服务配置 - 已注释，保留以便后续使用

    provider: new DeepSeekChatProvider({
      request: XRequest<XModelParams, Partial<Record<SSEFields, XModelResponse>>>(
        API_CONFIG.endpoints.chatStream,
        {
          manual: true,
          method: 'POST', // 指定请求方法为POST
          // 添加SSE转换中间件
          middlewares: middlewares,
        },
      ),
    }),

    conversationKey: isNewConversation ? nextNewConversationId : activeConversationKey,
    defaultMessages: isNewConversation ? [] : historyMessageFactory(activeConversationKey),
    requestPlaceholder: () => {
      return {
        content: locale.noData,
        role: 'assistant',
      };
    },
    requestFallback: (_: any, { messageInfo }: any) => {
      return {
        ...messageInfo?.message,
        content: messageInfo?.message?.content || locale.requestFailedPleaseTryAgain,
      };
    },
  });

  // 自定义onReload方法，确保重试请求使用正确的payload格式
  const onReload = useCallback((messageId: string | number, options?: any) => {
    return originalOnReload(messageId, options);
  }, [originalOnReload]);

  // ==================== Event Handlers ====================
  const onSubmit = useCallback((val: string, deepThinking: boolean = false, _isChatBIMode?: boolean) => {
    if (!val) return;

    if (isNewConversation) {
      // 如果是新对话，使用 nextNewConversationId 添加到对话列表首位
      const newConversation = {
        key: nextNewConversationId,
        label: '新对话',
        group: 'today',
        isNew: false,
      };
      setConversations([newConversation, ...conversations]);
      
      // 切换状态
      setActiveConversationKey(nextNewConversationId);
      setCurrentConversationId(nextNewConversationId);
      
      // 发送请求使用 nextNewConversationId
      onRequest({
        model: 'glm-4.5-flash',
        stream: true,
        messages: [{ role: 'user', content: val }],
        thinking: deepThinking ? { type: 'enabled' } : { type: 'disabled' },
      });
    } else {
      // 对于已有对话，直接发送，使用 currentConversationId
      onRequest({
        model: 'glm-4.5-flash',
        stream: true,
        messages: [{ role: 'user', content: val }],
        thinking: deepThinking ? { type: 'enabled' } : { type: 'disabled' },
      });
      const selected = conversations.find((conv) => conv.key === activeConversationKey);
      if (selected) {
        setConversations([
          selected,
          ...conversations.filter((conv) => conv.key !== activeConversationKey),
        ]);
      }
    }
  }, [onRequest, isNewConversation, conversations, activeConversationKey, setConversations, setActiveConversationKey, setCurrentConversationId, nextNewConversationId])

  // 缓存XMarkdown组件配置，避免每次渲染都创建新对象
  // 将xmarkdownComponents移出组件，确保引用稳定
  const xmarkdownComponents = {
    think: ThinkComponent,
    'custom-chain': CustomThoughtChain,
    'custom-chart': DataChart,
    'card-dashboard': CardDashBoard,
    'custom-table': CustomTable,
    'custom-picture': PictureView,
    'custom-index': CollectionIndex,
    'custom-pdfdialog': MarkdownToPdfDialog,
    'custom-filecard': CustomFileCard,
  };

  const splitCustomChainBlocks = (rawContent: string) => {
    const content = String(rawContent ?? '');
    const blocks: Array<{ type: 'markdown' | 'custom-chain'; content: string }> = [];
    const openTag = '<custom-chain>';
    const closeTag = '</custom-chain>';
    let cursor = 0;

    while (true) {
      const start = content.indexOf(openTag, cursor);
      if (start === -1) {
        if (cursor < content.length) {
          blocks.push({ type: 'markdown', content: content.slice(cursor) });
        }
        break;
      }
      if (start > cursor) {
        blocks.push({ type: 'markdown', content: content.slice(cursor, start) });
      }
      const afterStart = start + openTag.length;
      const end = content.indexOf(closeTag, afterStart);
      if (end === -1) {
        blocks.push({ type: 'custom-chain', content: content.slice(afterStart) });
        break;
      }
      blocks.push({ type: 'custom-chain', content: content.slice(afterStart, end) });
      cursor = end + closeTag.length;
    }

    return blocks;
  };

  const getRole = useCallback((_className: string) => ({
    assistant: {
      placement: 'start',
      header: (_: any, { status }: any) => {
        const config = THOUGHT_CHAIN_CONFIG[status as keyof typeof THOUGHT_CHAIN_CONFIG];
        return config ? (
          <ThoughtChain.Item
            style={{ marginBottom: 16 }}
            status={config.status as ThoughtChainItemProps['status']}
            variant="solid"
            icon={<GlobalOutlined />}
            title={config.title}
          />
        ) : null;
      },
      footer: (content: any, { status, key, extraInfo }: any) => (
        <Footer
          content={content}
          status={status}
          id={key as string}
          extraInfo={extraInfo as ChatMessage['extraInfo']}
        />
      ),
      contentRender: (content: any, { status, key: messageKey }: any) => {
        const blocks = splitCustomChainBlocks(content);
        const lastChainIndex = (() => {
          for (let i = blocks.length - 1; i >= 0; i -= 1) {
            if (blocks[i].type === 'custom-chain') {
              return i;
            }
          }
          return -1;
        })();
        const hasTokenTextAfterChain = blocks.some((block, index) => (
          index > lastChainIndex &&
          block.type === 'markdown' &&
          block.content.trim().length > 0
        ));
        return (
          <>
            {blocks.map((block, index) => {
              if (block.type === 'custom-chain') {
                const chainCacheKey = `${activeConversationKey || 'unknown'}:${String(messageKey ?? 'unknown')}:${index}`;
                return (
                  <CustomThoughtChain
                    key={`custom-chain-${chainCacheKey}`}
                    cacheKey={chainCacheKey}
                    streamStatus={status}
                    disableBlink={hasTokenTextAfterChain}
                  >
                    {block.content}
                  </CustomThoughtChain>
                );
              }
              return (
                <XMarkdown
                  key={`markdown-${index}`}
                  paragraphTag="div"
                  components={xmarkdownComponents}
                  className={className}
                  streaming={{
                    hasNextChunk: status === 'updating',
                    enableAnimation: true,
                  }}
                  style={{ 
                    textAlign: 'left',
                    fontSize: '15px',
                  }}
                >
                  {block.content}
                </XMarkdown>
              );
            })}
          </>
        );
      },
    },
    user: { placement: 'end' },
  }), [className, activeConversationKey])

  // ==================== Lifecycle ====================


  // 页面刷新或关闭时调用重置历史接口
  React.useEffect(() => {
    // 重置历史记录的处理函数
    const handleBeforeUnload = () => {
      try {
        // 直接使用fetch API调用重置历史接口
        const { token } = useAuthStore.getState();
        fetch(API_CONFIG.endpoints.resetHistory, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token
              ? {
                  Authorization: `Bearer ${token}`,
                }
              : {}),
          },
          body: JSON.stringify({

          }),
          // 确保请求能在页面关闭前发送完成
          keepalive: true,
        })
          .then((response) => {
            if (response.status === 401) {
              forceLogout();
            }
          })
          .catch(error => {
            console.error('调用重置接口失败:', error);
          });
      } catch (error) {
        console.error('准备重置请求失败:', error);
      }
    };

    // 添加事件监听器
    window.addEventListener('beforeunload', handleBeforeUnload);

    // 组件卸载时移除事件监听器
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [activeConversationKey]);

  const handleOpenChatBI = useCallback(() => {
    setMessages([]);
    setIsNewConversation(false);
    setNextNewConversationId(`conv_${Date.now()}`);
    navigate(ROUTES.chatBI);
  }, [navigate, setIsNewConversation, setNextNewConversationId, setMessages]);

  // ==================== Render ====================
  return (
    <XProvider locale={locale}>
      <ChatContext.Provider value={{ onReload, setMessage }}>
        {contextHolder}
        <div className={styles.layout}>
          <div className={styles.siderWrapper}>
            <CHAT_SIDER
              messages={messages}
              conversations={conversations}
              activeConversationKey={activeConversationKey}
              setActiveConversationKey={setActiveConversationKey}
              setConversations={setConversations}
              onConversationChange={(key) => {
                // 已经在chat_sider 中处理了 setActiveConversationKey?setIsNewConversation
                // 这里不需要重复处理?
              }}
              activeAgent={activeAgent}
              setActiveAgent={setActiveAgent}
              fixedConversations={DEFAULT_CONVERSATIONS_ITEMS}
              hotQuestions={HOT_QUESTIONS}
              onHotQuestionClick={(question) => {
                chatSenderSetValueRef.current?.(question);
              }}
              setCurrentHistoryMessages={setCurrentHistoryMessages}
            />
          </div>
          <div className={styles.chat}>
            <>
              <CHAT_LIST
                messages={messages}
                onSubmit={onSubmit}
                className={className}
                activeConversationKey={activeConversationKey}
                getRole={getRole}
                historyMessages={isNewConversation ? [] : currentHistoryMessages}
              />
              <CHAT_SENDER
                onRegisterInputSetter={registerChatSenderSetter}
                isRequesting={isRequesting}
                onSubmit={onSubmit}
                abort={abort}
                isDeepThinking={isDeepThinking}
                setIsDeepThinking={setIsDeepThinking}
                isChatBI={false}
                onToggleChatBI={handleOpenChatBI}
                timeOptions={timeOptions}
                placeOptions={placeOptions}
                isNewConversation={isNewConversation}
              />
            </>
          </div>
        </div>
      </ChatContext.Provider>
    </XProvider>
  );
};

export default Independent;
export { };















