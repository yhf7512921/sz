import { useEffect, useRef } from 'react';

const shouldLogRenderCount = () => {
  if (typeof process === 'undefined') return true;
  return process.env.NODE_ENV !== 'production';
};

export const useRenderCount = (label: string) => {
  const countRef = useRef(0);

  useEffect(() => {
    if (!shouldLogRenderCount()) return;
    countRef.current += 1;
    // eslint-disable-next-line no-console
    console.log(`[render] ${label}: ${countRef.current}`);
  });
};
