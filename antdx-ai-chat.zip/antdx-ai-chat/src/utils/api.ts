﻿/*
 * @Author       : Chang xd
 * @Date         : 2025-12-19 15:00:00
 * @Description  : API 工具与请求封装
 */

import { message } from 'antd';
import { useAuthStore } from '../stores';
import { ROUTES } from '../routes/paths';
// 从环境变量读取 API 配置
const USE_MOCK = process.env.REACT_APP_USE_MOCK === 'true';
const API_BASE_URL = USE_MOCK 
  ? ''  // 使用 Mock 时改用相对路径
  : process.env.REACT_APP_API_BASE_URL || '';  

// 调试日志
console.log('[API 配置] USE_MOCK:', USE_MOCK);
console.log('[API 配置] REACT_APP_USE_MOCK:', process.env.REACT_APP_USE_MOCK);
console.log('[API 配置] REACT_APP_API_BASE_URL:', process.env.REACT_APP_API_BASE_URL);
console.log('[API 配置] API_BASE_URL:', API_BASE_URL);  
const CHAT_STREAM_PATH = process.env.REACT_APP_CHAT_STREAM_PATH || '/chat_stream_tokens';
const RESET_HISTORY_PATH = process.env.REACT_APP_RESET_HISTORY_PATH || '/reset';
const CONVERSATIONS_PATH = process.env.REACT_APP_CONVERSATIONS_PATH || '/api/conversations';
const CONVERSATION_MESSAGES_PATH = process.env.REACT_APP_CONVERSATION_MESSAGES_PATH || '/api/conversations/:key/messages';
const TIME_OPTIONS_PATH = process.env.REACT_APP_TIME_OPTIONS_PATH || '/time';
const PLACE_OPTIONS_PATH = process.env.REACT_APP_PLACE_OPTIONS_PATH || '/place';
const CHATBI_INIT_PATH = process.env.REACT_APP_CHATBI_INIT_PATH || '/rechatbi';
const CHATBI_STREAM_PATH = process.env.REACT_APP_CHATBI_STREAM_PATH || '/simple_chat_stream';
const CHATBI_RESET_PATH = process.env.REACT_APP_CHATBI_RESET_PATH || '/simple_reset';
const LOGIN_PATH = process.env.REACT_APP_LOGIN_PATH || '/auth/login';
const ME_PATH = process.env.REACT_APP_ME_PATH || '/auth/me';
const LOGOUT_PATH = process.env.REACT_APP_LOGOUT_PATH || '/auth/logout';
const USERS_PATH = process.env.REACT_APP_USERS_PATH || '/api/users';
const USER_DETAIL_PATH = process.env.REACT_APP_USER_DETAIL_PATH || '/api/users/:id';
const AUTH_STORAGE_KEY = 'auth-storage';

/**
 * API 配置
 */
export const API_CONFIG = {
  baseUrl: API_BASE_URL,
  endpoints: {
    chatStream: `${API_BASE_URL}${CHAT_STREAM_PATH}`,
    resetHistory: `${API_BASE_URL}${RESET_HISTORY_PATH}`,
    conversations: `${API_BASE_URL}${CONVERSATIONS_PATH}`,
    conversationMessages: (key: string) => `${API_BASE_URL}${CONVERSATION_MESSAGES_PATH.replace(':key', key)}`,
    timeOptions: `${API_BASE_URL}${TIME_OPTIONS_PATH}`,
    placeOptions: `${API_BASE_URL}${PLACE_OPTIONS_PATH}`,
    chatbiInit: `${API_BASE_URL}${CHATBI_INIT_PATH}`,
    chatbiStream: `${API_BASE_URL}${CHATBI_STREAM_PATH}`,
    chatbiReset: `${API_BASE_URL}${CHATBI_RESET_PATH}`,
    login: `${API_BASE_URL}${LOGIN_PATH}`,
    me: `${API_BASE_URL}${ME_PATH}`,
    logout: `${API_BASE_URL}${LOGOUT_PATH}`,
    users: `${API_BASE_URL}${USERS_PATH}`,
    userDetail: (id: string) => `${API_BASE_URL}${USER_DETAIL_PATH.replace(':id', id)}`,
  },
};

/**
 * 通用请求参数
 */
export interface RequestOptions extends Omit<RequestInit, 'body' | 'headers'> {
  headers?: Record<string, string>;
  params?: Record<string, any>;
  body?: any; // 普通对象会被序列化为 JSON
  skipAuth?: boolean;
}

const getAuthToken = () => {
  try {
    const { token } = useAuthStore.getState();
    return token;
  } catch {
    return undefined;
  }
};

export const forceLogout = () => {
  try {
    useAuthStore.getState().logout();
  } catch {
    // ignore store errors
  }
  try {
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
    localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch {
    // ignore storage errors
  }
  if (typeof window !== 'undefined') {
    const target = ROUTES.login;
    if (window.location.pathname !== target) {
      window.location.replace(target);
    }
  }
};

const handleUnauthorized = (response: Response) => {
  if (response.status === 401) {
    message.error('登录已过期，请重新登录');
    forceLogout();
    throw new Error('Unauthorized');
  }
};

const buildAuthHeaders = (headers?: Record<string, string>, skipAuth?: boolean) => {
  if (skipAuth) return {};
  const token = getAuthToken();
  if (!token) return {};

  const authHeaders: Record<string, string> = {};
  const hasAuthorization = !!headers?.Authorization || !!headers?.authorization;
  const hasTokenHeader = !!headers?.token;

  if (!hasAuthorization) {
    authHeaders.Authorization = `Bearer ${token}`;
  }
  if (!hasTokenHeader) {
    authHeaders.token = token;
  }
  return authHeaders;
};

/**
 * 通用 fetch 请求封装
 * @param url 请求 URL
 * @param options 请求选项
 * @returns Promise<T>
 */
export async function request<T = any>(url: string, options: RequestOptions = {}): Promise<T> {
  const {
    headers,
    body,
    params,
    skipAuth,
    ...restOptions
  } = options;

  // 构建查询参数
  let fullUrl = url;
  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value));
      }
    });
    const paramsString = searchParams.toString();
    if (paramsString) {
      fullUrl += `?${paramsString}`;
    }
  }

  const defaultHeaders = {
    'Content-Type': 'application/json',
  };

  let requestBody: BodyInit | null | undefined = undefined;
  if (body !== undefined && body !== null) {
    if (typeof body === 'string' || body instanceof Blob || body instanceof FormData || body instanceof URLSearchParams) {
      // 已是 BodyInit，直接透传
      requestBody = body;
    } else {
      // 普通对象，序列化为 JSON
      requestBody = JSON.stringify(body);
    }
  }

  // 发送请求
  const response = await fetch(fullUrl, {
    ...restOptions,
    headers: {
      ...defaultHeaders,
      ...buildAuthHeaders(headers, skipAuth),
      ...headers,
    },
    body: requestBody,
  });

  handleUnauthorized(response);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({
      message: `HTTP Error: ${response.status} ${response.statusText}`,
    }));
    throw new Error(errorData.message || `HTTP Error: ${response.status} ${response.statusText}`);
  }

  if (response.status === 204) {
    return {} as T;
  }

  return response.json() as Promise<T>;
}

/**
 * 重置模型历史
 * @param threadId 可选的会话 ID
 * @returns Promise<{ success: boolean }>
 */
export async function resetModelHistory(threadId?: string): Promise<{ success: boolean }> {
  return request(API_CONFIG.endpoints.resetHistory, {
    method: 'POST',
    body: threadId ? { thread_id: threadId } : {},
  });
}

/**
 * 发送聊天流请求
 * @param body 请求体
 * @returns Promise<Response>
 */
export async function sendChatStreamRequest(body: any): Promise<Response> {
  const response = await fetch(API_CONFIG.endpoints.chatStream, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...buildAuthHeaders(),
    },
    body: JSON.stringify(body),
  });
  handleUnauthorized(response);
  return response;
}

/**
 * 会话条目类型
 */
export interface ConversationItem {
  key: string;
  label: string;
  group?: string;
  createdAt?: string;
  updatedAt?: string;
}

/**
 * 消息条目类型
 */
export interface MessageItem {
  id: string;
  message: {
    role: 'user' | 'assistant';
    content: string;
  };
  status: 'success' | 'updating' | 'loading' | 'error';
  timestamp?: string;
  extraInfo?: {
    feedback?: 'default' | 'like' | 'dislike';
  };
}

/**
 * 会话列表响应
 */
export interface ConversationsResponse {
  code: number;
  message: string;
  data: {
    conversations: ConversationItem[];
  };
}

/**
 * 会话消息响应
 */
export interface ConversationMessagesResponse {
  code: number;
  message: string;
  data: {
    conversationKey: string;
    messages: MessageItem[];
  };
}

export interface OptionsResponse {
  code: number;
  message: string;
  type?: 'time' | 'place';
  data: {
    time?: string[];
    place?: string[];
    palce?: string[];
  };
}

/**
 * 获取会话列表
 * @returns Promise<ConversationsResponse>
 */
export async function getConversations(): Promise<ConversationsResponse> {
  return request<ConversationsResponse>(API_CONFIG.endpoints.conversations, {
    method: 'GET',
  });
}

/**
 * 获取会话消息
 * @param conversationKey 会话 key
 * @returns Promise<ConversationMessagesResponse>
 */
export async function getConversationMessages(conversationKey: string): Promise<ConversationMessagesResponse> {
  return request<ConversationMessagesResponse>(
    API_CONFIG.endpoints.conversationMessages(conversationKey),
    {
      method: 'GET',
    }
  );
}

export async function getTimeOptions(): Promise<OptionsResponse> {
  return request<OptionsResponse>(API_CONFIG.endpoints.timeOptions, {
    method: 'GET',
  });
}

export async function getPlaceOptions(): Promise<OptionsResponse> {
  return request<OptionsResponse>(API_CONFIG.endpoints.placeOptions, {
    method: 'GET',
  });
}

// ==================== Auth & User Management (Mock-ready) ====================
export interface LoginParams {
  username: string;
  password: string;
}

export interface LoginResponse {
  code: number;
  message: string;
  data: {
    access_token: string;
    token_type: 'bearer' | 'Bearer';
    user_id: string;
    username: string;
    role: 'admin' | 'user';
  };
}

export interface UserItem {
  id: string;
  username: string;
  is_superuser: boolean;
  status: 'active' | 'disabled' | string;
  created_at?: string;
  updated_at?: string;
}

export interface UsersResponse {
  code: number;
  message: string;
  data: {
    users: UserItem[];
  };
}

export interface UserResponse {
  code: number;
  message: string;
  data: {
    user_id: string;
  };
}

export interface DeleteUserResponse {
  code: number;
  message: string;
}

let mockUsers: UserItem[] = [
  {
    id: 'sc_1',
    username: 'admin',
    is_superuser: true,
    status: 'active',
    created_at: '2026-02-10T00:00:00+00:00',
    updated_at: '2026-02-10T00:00:00+00:00',
  },
];

const mockLogin = async (params: LoginParams): Promise<LoginResponse> => {
  const role = params.username === 'admin' ? 'admin' : 'user';
  return {
    code: 200,
    message: 'ok',
    data: {
      access_token: `mock-token-${Date.now()}`,
      token_type: 'bearer',
      user_id: role === 'admin' ? 'sc_1' : 'sc_2',
      username: params.username,
      role,
    },
  };
};

export async function login(params: LoginParams): Promise<LoginResponse> {
  if (USE_MOCK) {
    return mockLogin(params);
  }
  return request<LoginResponse>(API_CONFIG.endpoints.login, {
    method: 'POST',
    body: params,
    skipAuth: true,
  });
}

export interface MeResponse {
  code: number;
  data: {
    user_id: string;
    username: string;
    is_superuser: boolean;
    role: 'admin' | 'user';
  };
}

export async function getMe(): Promise<MeResponse> {
  return request<MeResponse>(API_CONFIG.endpoints.me, {
    method: 'GET',
  });
}

export interface LogoutResponse {
  code?: number;
  message?: string;
}

export async function logoutApi(): Promise<LogoutResponse> {
  return request<LogoutResponse>(API_CONFIG.endpoints.logout, {
    method: 'POST',
  });
}

export async function getUsers(): Promise<UsersResponse> {
  if (USE_MOCK) {
    return {
      code: 200,
      message: 'ok',
      data: {
        users: mockUsers,
      },
    };
  }
  return request<UsersResponse>(API_CONFIG.endpoints.users, {
    method: 'GET',
  });
}

export interface CreateUserPayload {
  username: string;
  password: string;
  is_superuser: boolean;
}

export async function createUser(payload: CreateUserPayload): Promise<UserResponse> {
  if (USE_MOCK) {
    const user: UserItem = {
      id: `sc_${Date.now()}`,
      username: payload.username,
      is_superuser: payload.is_superuser,
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    mockUsers = [user, ...mockUsers];
    return {
      code: 200,
      message: 'ok',
      data: { user_id: user.id },
    };
  }
  return request<UserResponse>(API_CONFIG.endpoints.users, {
    method: 'POST',
    body: payload,
  });
}

export async function deleteUser(id: string): Promise<DeleteUserResponse> {
  if (USE_MOCK) {
    mockUsers = mockUsers.filter((item) => item.id !== id);
    return {
      code: 200,
      message: 'ok',
    };
  }
  return request<DeleteUserResponse>(API_CONFIG.endpoints.userDetail(id), {
    method: 'DELETE',
  });
}












