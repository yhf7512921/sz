﻿import React, { useEffect, useState } from 'react';
import { Button, Card, Form, Input, message, Typography } from 'antd';
import { createStyles } from 'antd-style';
import { useNavigate } from 'react-router-dom';
import { login } from '../utils/api';
import { ROUTES } from '../routes/paths';
import { useAuthStore } from '../stores';

const useStyle = createStyles(({ token, css }: any) => ({
  wrapper: css`
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    padding: 32px 24px;
    font-family: 'Manrope', ${token.fontFamily}, sans-serif;
  `,
  card: css`
    width: min(1100px, 100%);
    border-radius: var(--radius-lg);
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
    background: var(--bg-elev);
    overflow: hidden;
    .ant-card-body {
      padding: 0;
    }
  `,
  shell: css`
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, 0.9fr);
    min-height: 560px;
    @media (max-width: 980px) {
      grid-template-columns: 1fr;
    }
  `,
  leftPanel: css`
    padding: 44px 48px;
    background:
      radial-gradient(circle at 20% 20%, rgba(111, 92, 255, 0.16), transparent 45%),
      radial-gradient(circle at 80% 0%, rgba(79, 54, 255, 0.12), transparent 42%),
      linear-gradient(160deg, #f9f8f3 0%, #f2f0ff 100%);
    color: #141824;
    border-radius: var(--radius-lg) 0 0 var(--radius-lg);
    display: flex;
    flex-direction: column;
    gap: 24px;
    position: relative;
    overflow: hidden;
    @media (max-width: 980px) {
      border-radius: var(--radius-lg) var(--radius-lg) 0 0;
    }
  `,
  glow: css`
    position: absolute;
    inset: -30% auto auto -10%;
    width: 320px;
    height: 320px;
    background: radial-gradient(circle, rgba(111, 92, 255, 0.28), transparent 70%);
    filter: blur(20px);
    opacity: 0.7;
    pointer-events: none;
  `,
  glowAlt: css`
    position: absolute;
    inset: auto -10% -40% auto;
    width: 260px;
    height: 260px;
    background: radial-gradient(circle, rgba(79, 54, 255, 0.2), transparent 70%);
    filter: blur(20px);
    opacity: 0.6;
    pointer-events: none;
  `,
  brand: css`
    display: inline-flex;
    align-items: center;
    gap: 10px;
    font-weight: 600;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    font-size: 11px;
    color: rgba(20, 24, 36, 0.6);
  `,
  headline: css`
    font-size: clamp(28px, 2.5vw, 40px);
    font-weight: 600;
    color: #0f1218;
    margin: 0;
  `,
  subtitle: css`
    color: rgba(30, 41, 59, 0.72);
    font-size: 14px;
    line-height: 1.7;
    max-width: 360px;
  `,
  preview: css`
    background: #ffffff;
    border: 1px solid rgba(15, 18, 24, 0.08);
    border-radius: 18px;
    padding: 18px;
    display: grid;
    gap: 14px;
    box-shadow: 0 18px 36px rgba(15, 18, 24, 0.08);
  `,
  previewHeader: css`
    display: flex;
    align-items: center;
    gap: 6px;
    color: rgba(15, 18, 24, 0.6);
    font-size: 12px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  `,
  headerDot: css`
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: rgba(15, 18, 24, 0.15);
  `,
  chatRow: css`
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    align-items: start;
  `,
  avatar: css`
    width: 28px;
    height: 28px;
    border-radius: 10px;
    background: linear-gradient(135deg, #6f5cff 0%, #8ea0ff 100%);
    box-shadow: 0 8px 16px rgba(111, 92, 255, 0.22);
  `,
  bubble: css`
    padding: 10px 12px;
    border-radius: 12px;
    background: rgba(15, 18, 24, 0.04);
    color: #141824;
    font-size: 13px;
    line-height: 1.6;
  `,
  bubbleUser: css`
    background: rgba(111, 92, 255, 0.12);
  `,
  bubbleAi: css`
    background: rgba(15, 18, 24, 0.05);
    border: 1px solid rgba(15, 18, 24, 0.06);
  `,
  stream: css`
    margin-top: 8px;
    font-family: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 12px;
    color: #5f52ff;
    white-space: nowrap;
    overflow: hidden;
    border-right: 2px solid rgba(95, 82, 255, 0.7);
    width: 0;
    animation: streamText 3.4s steps(30, end) infinite, cursorBlink 0.9s steps(1) infinite;
    @keyframes streamText {
      from {
        width: 0;
      }
      to {
        width: 240px;
      }
    }
    @keyframes cursorBlink {
      0% {
        border-right-color: transparent;
      }
      50% {
        border-right-color: rgba(95, 82, 255, 0.7);
      }
      100% {
        border-right-color: transparent;
      }
    }
  `,
  features: css`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
    @media (max-width: 980px) {
      grid-template-columns: 1fr;
    }
  `,
  featureCard: css`
    border-radius: var(--radius-sm);
    padding: 12px 14px;
    background: rgba(255, 255, 255, 0.7);
    border: 1px solid rgba(15, 18, 24, 0.08);
    color: #1f2433;
    font-size: 12px;
    line-height: 1.5;
  `,
  logos: css`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  `,
  logoPill: css`
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(15, 18, 24, 0.06);
    font-size: 11px;
    color: rgba(15, 18, 24, 0.65);
    text-transform: uppercase;
    letter-spacing: 0.08em;
  `,
  cta: css`
    display: flex;
    align-items: center;
    gap: 14px;
    margin-top: 4px;
  `,
  ctaHint: css`
    font-size: 13px;
    color: rgba(30, 41, 59, 0.7);
  `,
  title: css`
    text-align: center;
    margin-bottom: 20px;
  `,
  rightPanel: css`
    padding: 44px 38px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 24px;
    background: #ffffff;
    border-left: 1px solid rgba(15, 18, 24, 0.08);
    border-radius: 0 var(--radius-lg) var(--radius-lg) 0;
    @media (max-width: 980px) {
      border-radius: 0 0 var(--radius-lg) var(--radius-lg);
      border-left: none;
      border-top: 1px solid rgba(15, 18, 24, 0.08);
    }
  `,
  formItem: css`
    margin-bottom: 16px;
  `,
  formHint: css`
    text-align: center;
    color: ${token.colorTextSecondary};
    font-size: 13px;
  `,
  split: css`
    display: flex;
    align-items: center;
    gap: 12px;
    color: ${token.colorTextSecondary};
    font-size: 12px;
    &::before,
    &::after {
      content: '';
      flex: 1;
      height: 1px;
      background: ${token.colorBorderSecondary};
    }
  `,
  helper: css`
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    color: ${token.colorTextSecondary};
  `,
  link: css`
    color: ${token.colorPrimary};
    cursor: pointer;
  `,
}));

const LoginPage: React.FC = () => {
  const { styles } = useStyle();
  const navigate = useNavigate();
  const { isAuthenticated, role } = useAuthStore();
  const setAuth = useAuthStore((state) => state.setAuth);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      navigate(role === 'admin' ? ROUTES.accountManagement : ROUTES.home, { replace: true });
    }
  }, [isAuthenticated, role, navigate]);

  const handleFinish = async (values: { username: string; password: string }) => {
    setLoading(true);
    try {
      const result = await login(values);
      if (result.code !== 200) {
        throw new Error(result.message || '登录失败');
      }
      setAuth({
        token: result.data.access_token,
        username: result.data.username,
        role: result.data.role,
      });
      message.success('登录成功');
      navigate(result.data.role === 'admin' ? ROUTES.accountManagement : ROUTES.home);
    } catch (error: any) {
      message.error(error?.message || '登录失败，请稍后再试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrapper}>
      <Card className={styles.card} bordered={false}>
        <div className={styles.shell}>
          <section className={styles.leftPanel}>
            <div className={styles.glow} />
            <div className={styles.glowAlt} />
            <div className={styles.brand}>AI CHAT PLATFORM</div>
            <div>
              <h1 className={styles.headline}>城市道路地下病害智能助手</h1>
              <p className={styles.subtitle}>
                以极简交互和清晰视图，让多模态数据、流式输出与业务洞察自然衔接。
              </p>
            </div>
            <div className={styles.preview}>
              <div className={styles.previewHeader}>
                <span className={styles.headerDot} />
                <span className={styles.headerDot} />
                <span className={styles.headerDot} />
                Live Conversation
              </div>
              <div className={styles.chatRow}>
                <div className={styles.avatar} />
                <div className={`${styles.bubble} ${styles.bubbleUser}`}>
                  请总结本月各城区的地下病害情况，并生成统计图表。
                </div>
              </div>
              <div className={styles.chatRow}>
                <div className={styles.avatar} />
                <div className={`${styles.bubble} ${styles.bubbleAi}`}>
                  已完成统计分析，正在生成本月各城区地下病害统计图表及图表解析。
                  <div className={styles.stream}>Streaming tokens...</div>
                </div>
              </div>
            </div>
            <div className={styles.features}>
              <div className={styles.featureCard}>对话式分析 · 多轮追问 · 结构化报告</div>
              <div className={styles.featureCard}>实时流式输出 · 可控思考 · 低延迟体验</div>
              <div className={styles.featureCard}>权限隔离 · 审计追踪 · 安全可控</div>
              <div className={styles.featureCard}>多模型编排 · 任务路由 · 成本可视</div>
            </div>
            <div>
              <div className={styles.subtitle}>集成生态</div>
              <div className={styles.logos}>
                <span className={styles.logoPill}>QwenAI</span>
                <span className={styles.logoPill}>Langchain</span>
                <span className={styles.logoPill}>PostgreSQL</span>
                <span className={styles.logoPill}>React</span>
                <span className={styles.logoPill}>Ant Design</span>
              </div>
            </div>
            <div className={styles.cta}>
              <Button type="primary" size="large">
                Try Now
              </Button>
              <span className={styles.ctaHint}>立即体验流式对话</span>
            </div>
          </section>
          <section className={styles.rightPanel}>
            <div className={styles.title}>
              <Typography.Title level={3} style={{ marginBottom: 4 }}>
                系统登录
              </Typography.Title>
              <Typography.Text type="secondary">请输入账号与密码</Typography.Text>
            </div>
            <Form layout="vertical" onFinish={handleFinish}>
              <Form.Item
                label="用户名"
                name="username"
                className={styles.formItem}
                rules={[{ required: true, message: '请输入用户名' }]}
              >
                <Input placeholder="请输入用户名" allowClear />
              </Form.Item>
              <Form.Item
                label="密码"
                name="password"
                className={styles.formItem}
                rules={[{ required: true, message: '请输入密码' }]}
              >
                <Input.Password placeholder="请输入密码" />
              </Form.Item>
              <div className={styles.helper}>
                <span className={styles.link}>忘记密码?</span>
              </div>
              <Button type="primary" htmlType="submit" block loading={loading} style={{ marginTop: 16 }}>
                登录
              </Button>
            </Form>
            <div className={styles.split}>Secure Access</div>
            <div className={styles.formHint}>登录后即可开始对话</div>
          </section>
        </div>
      </Card>
    </div>
  );
};

export default LoginPage;
