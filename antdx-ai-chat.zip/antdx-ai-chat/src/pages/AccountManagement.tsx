﻿import React, { useEffect, useMemo, useState } from 'react';
import {
  Button,
  Card,
  Form,
  Input,
  message,
  Modal,
  Popconfirm,
  Space,
  Switch,
  Table,
  Tag,
  Typography,
} from 'antd';
import { createStyles } from 'antd-style';
import { createUser, deleteUser, getUsers, UserItem } from '../utils/api';

const useStyle = createStyles(({ token, css }: any) => ({
  page: css`
    background: transparent;
    padding: 0;
    font-family: AlibabaPuHuiTi, ${token.fontFamily}, sans-serif;
    display: flex;
    flex-direction: column;
    flex: 1;
  `,
  header: css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
  `,
  card: css`
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
    flex: 1;
  `,
  table: css`
    .ant-table {
      background: #ffffff;
      border-radius: 14px;
      border: 1px solid rgba(15, 23, 42, 0.08);
      overflow: hidden;
    }
    .ant-table-thead > tr > th {
      background: #f7f7fb;
      color: #1f2937;
      font-weight: 600;
      border-bottom: 1px solid rgba(15, 23, 42, 0.08);
    }
    .ant-table-tbody > tr > td {
      border-bottom: 1px solid rgba(15, 23, 42, 0.06);
      color: #111827;
    }
    .ant-table-tbody > tr:hover > td {
      background: rgba(111, 92, 255, 0.08);
    }
    .ant-table-pagination {
      margin: 16px 16px 0 16px;
    }
  `,
  pillTag: css`
    border-radius: 8px;
    padding: 2px 10px;
    font-size: 12px;
    border: 1px solid transparent;
  `,
  adminTag: css`
    color: #4f36ff;
    background: rgba(79, 54, 255, 0.12);
    border-color: rgba(79, 54, 255, 0.3);
  `,
  statusActive: css`
    color: #0f766e;
    background: rgba(20, 184, 166, 0.12);
    border-color: rgba(20, 184, 166, 0.35);
  `,
  statusDefault: css`
    color: #6b7280;
    background: rgba(148, 163, 184, 0.16);
    border-color: rgba(148, 163, 184, 0.35);
  `,
}));

const AccountManagement: React.FC = () => {
  const { styles } = useStyle();
  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [form] = Form.useForm();

  const loadUsers = async () => {
    setLoading(true);
    try {
      const result = await getUsers();
      if (result.code === 200) {
        setUsers(result.data.users);
      } else {
        message.warning(result.message || '获取用户列表失败');
      }
    } catch (error: any) {
      message.error(error?.message || '获取用户列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const formatTime = (value?: string) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString();
  };

  const openCreate = () => {
    form.resetFields();
    form.setFieldsValue({ is_superuser: false });
    setModalOpen(true);
  };

  const handleDelete = async (record: UserItem) => {
    try {
      const result = await deleteUser(record.id);
      if (result.code === 200) {
        setUsers((prev) => prev.filter((item) => item.id !== record.id));
        message.success('删除成功');
      } else {
        message.warning(result.message || '删除失败');
      }
    } catch (error: any) {
      message.error(error?.message || '删除失败');
    }
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      const result = await createUser(values);
      if (result.code === 200) {
        message.success('创建成功');
        await loadUsers();
      } else {
        message.warning(result.message || '创建失败');
      }
      setModalOpen(false);
    } catch (error: any) {
      if (error?.errorFields) {
        return;
      }
      message.error(error?.message || '操作失败');
    }
  };

  const columns = useMemo(
    () => [
      {
        title: '用户名',
        dataIndex: 'username',
        key: 'username',
      },
      {
        title: '管理员',
        dataIndex: 'is_superuser',
        key: 'is_superuser',
        render: (value: boolean) => (
          <Tag className={`${styles.pillTag} ${value ? styles.adminTag : styles.statusDefault}`}>
            {value ? '是' : '否'}
          </Tag>
        ),
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (value: string) => (
          <Tag className={`${styles.pillTag} ${value === 'active' ? styles.statusActive : styles.statusDefault}`}>
            {value || '-'}
          </Tag>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'created_at',
        key: 'created_at',
        render: (value: string | undefined) => formatTime(value),
      },
      {
        title: '更新时间',
        dataIndex: 'updated_at',
        key: 'updated_at',
        render: (value: string | undefined) => formatTime(value),
      },
      {
        title: '操作',
        key: 'actions',
        render: (_: any, record: UserItem) => (
          <Space>
            <Popconfirm title="确认删除该用户？" onConfirm={() => handleDelete(record)}>
              <Button danger>
                删除
              </Button>
            </Popconfirm>
          </Space>
        ),
      },
    ],
    [formatTime, handleDelete]
  );

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <Typography.Title level={3} style={{ marginBottom: 4 }}>
            账号管理
          </Typography.Title>
        </div>
        <Space>
          <Button type="primary" onClick={openCreate}>
            新增用户
          </Button>
          <Button onClick={loadUsers}>刷新</Button>
        </Space>
      </div>
      <Card className={styles.card} bordered={false}>
        <Table
          rowKey="id"
          dataSource={users}
          columns={columns}
          loading={loading}
          pagination={{ pageSize: 8 }}
          className={styles.table}
        />
      </Card>

      <Modal
        title="新增用户"
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        onOk={handleSubmit}
        okText="保存"
        cancelText="取消"
        destroyOnClose
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label="用户名"
            name="username"
            rules={[{ required: true, message: '请输入用户名' }]}
          >
            <Input placeholder="请输入用户名" />
          </Form.Item>
          <Form.Item
            label="密码"
            name="password"
            rules={[{ required: true, message: '请输入密码' }]}
          >
            <Input.Password placeholder="请输入密码" />
          </Form.Item>
          <Form.Item label="管理员" name="is_superuser" valuePropName="checked">
            <Switch checkedChildren="是" unCheckedChildren="否" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default AccountManagement;
