import React from 'react';
import { Breadcrumb, Layout } from 'antd';
import { createStyles } from 'antd-style';
import AccountManagement from './AccountManagement';

const { Sider, Header, Content, Footer } = Layout;

const useStyle = createStyles(({ css }: any) => ({
  wrapper: css`
    min-height: 100vh;
  `,
  sider: css`
    background: #1677ff;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 16px;
  `,
  header: css`
    background: #0d5fe0;
    padding: 0 24px;
    display: flex;
    align-items: center;
  `,
  breadcrumb: css`
    color: #fff;
    .ant-breadcrumb-link,
    .ant-breadcrumb-separator {
      color: rgba(255, 255, 255, 0.8);
    }
    .ant-breadcrumb-link a {
      color: #fff;
    }
  `,
  content: css`
    background: #0b50c7;
    padding: 24px;
    color: #fff;
  `,
  contentInner: css`
    background: #ffffff;
    border-radius: 12px;
    padding: 16px;
    color: #1f2937;
    min-height: 420px;
  `,
  footer: css`
    background: #3a86ff;
    color: #fff;
    text-align: center;
  `,
}));

const MainPage: React.FC = () => {
  const { styles } = useStyle();

  return (
    <Layout className={styles.wrapper}>
      <Sider width={220} className={styles.sider}>
        Sider
      </Sider>
      <Layout>
        <Header className={styles.header}>
          <Breadcrumb
            className={styles.breadcrumb}
            items={[{ title: '首页' }, { title: '账号管理' }]}
          />
        </Header>
        <Content className={styles.content}>
          <div className={styles.contentInner}>
            <AccountManagement />
          </div>
        </Content>
        <Footer className={styles.footer}>Footer</Footer>
      </Layout>
    </Layout>
  );
};

export default MainPage;
