﻿import React from 'react';
import { Avatar, Breadcrumb, Button, Dropdown, Layout, Menu, Modal, message } from 'antd';
import { createStyles } from 'antd-style';
import { useLocation, useNavigate } from 'react-router-dom';
import { PlusOutlined, UserOutlined } from '@ant-design/icons';
import { ROUTES } from '../routes/paths';
import { useAuthStore } from '../stores';
import { logoutApi } from '../utils/api';

const { Sider, Header, Content } = Layout;

const useStyle = createStyles(({ token, css }: any) => ({
  wrapper: css`
    min-height: 100vh;
    background: #f5f7fb;
  `,
  sider: css`
    background: #fafafa;
    color: #000;
    padding: 0 8px;
  `,
  brand: css`
    display: flex;
    align-items: center;
    justify-content: flex-start;
    padding: 0 24px;
    box-sizing: border-box;
    gap: 8px;
    margin: 24px 0;

    span {
      font-weight: 600;
      color: ${token.colorText};
      font-size: 16px;
    }
  `,
  menu: css`
    background: transparent;
    color: ${token.colorText};
    .ant-menu-item-selected {
      background: rgba(24, 144, 255, 0.12) !important;
      color: #1890ff !important;
    }
  `,
  header: css`
    background: #ffffff;
    padding: 0 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid ${token.colorBorderSecondary};
  `,
  avatarTrigger: css`
    cursor: pointer;
  `,
  content: css`
    padding: 24px;
    display: flex;
  `,
  contentInner: css`
    background: #fff;
    border-radius: 12px;
    padding: 16px;
    min-height: 0;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
    flex: 1;
    display: flex;
  `,
}));

type AdminLayoutProps = {
  children: React.ReactNode;
};

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const { styles } = useStyle();
  const navigate = useNavigate();
  const location = useLocation();
  const { username, logout } = useAuthStore();

  const menuItems = [
    {
      key: ROUTES.accountManagement,
      label: '账号管理',
    },
  ];

  const handleUserMenuClick = ({ key }: { key: string }) => {
    if (key === 'home') {
      navigate(ROUTES.home);
      return;
    }
    if (key === 'logout') {
      Modal.confirm({
        title: '确认退出登录？',
        content: '退出后需要重新登录才能继续使用。',
        okText: '退出登录',
        cancelText: '取消',
        onOk: async () => {
          try {
            await logoutApi();
          } catch (error: any) {
            message.error(error?.message || '退出登录失败，请稍后再试');
          } finally {
            logout();
            navigate(ROUTES.login);
          }
        },
      });
    }
  };

  const userMenuItems = [
    {
      key: 'user',
      label: `当前登录：${username || '未知用户'}`,
      disabled: true,
    },
    {
      type: 'divider' as const,
    },
    {
      key: 'home',
      label: '返回对话',
    },
    {
      key: 'logout',
      label: '退出登录',
      danger: true,
    },
  ];

  return (
    <Layout className={styles.wrapper}>
      <Sider width={300} className={styles.sider} breakpoint="lg" collapsedWidth={64}>
        <div className={styles.brand}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <img
              src="/assets/icon/icon.png"
              draggable={false}
              alt="logo"
              width={64}
              height={64}
              style={{ borderRadius: '8px', objectFit: 'cover' }}
            />
          </div>
          <span>道路地下病害助手 v1.1</span>
        </div>
        <div style={{ padding: '0 16px 12px 16px' }}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate(ROUTES.home)}
            style={{
              width: '100%',
              height: '40px',
              borderRadius: '8px',
              fontWeight: 500,
              fontSize: '14px',
            }}
          >
            回到对话
          </Button>
        </div>
        <Menu
          mode="inline"
          className={styles.menu}
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={(item) => navigate(item.key)}
        />
      </Sider>
      <Layout>
        <Header className={styles.header}>
          <Breadcrumb
            items={[
              { title: 'Home' },
              { title: 'Admin' },
              { title: '账号管理' },
            ]}
          />
          <Dropdown menu={{ items: userMenuItems, onClick: handleUserMenuClick }} placement="bottomRight">
            <Avatar className={styles.avatarTrigger} icon={<UserOutlined />} />
          </Dropdown>
        </Header>
        <Content className={styles.content}>
          <div className={styles.contentInner}>{children}</div>
        </Content>
      </Layout>
    </Layout>
  );
};

export default AdminLayout;
