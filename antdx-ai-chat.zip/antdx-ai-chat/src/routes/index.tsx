import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Freestanding from '../Freestanding';
import ChatBIPage from '../ChatBi';
import LoginPage from '../pages/Login';
import AccountManagement from '../pages/AccountManagement';
import AdminLayout from '../layouts/AdminLayout';
import { ROUTES } from './paths';
import RequireAdmin from './RequireAdmin';
import RequireAuth from './RequireAuth';

const AppRoutes: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path={ROUTES.home}
          element={
            <RequireAuth>
              <Freestanding />
            </RequireAuth>
          }
        />
        <Route
          path={ROUTES.chatBI}
          element={
            <RequireAuth>
              <ChatBIPage />
            </RequireAuth>
          }
        />
        <Route path={ROUTES.login} element={<LoginPage />} />
        <Route
          path={ROUTES.accountManagement}
          element={
            <RequireAdmin>
              <AdminLayout>
                <AccountManagement />
              </AdminLayout>
            </RequireAdmin>
          }
        />
        <Route
          path="*"
          element={
            <RequireAuth>
              <Navigate to={ROUTES.home} replace />
            </RequireAuth>
          }
        />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
