/*
 * @Author       : Chang xd
 * @Date         : 2026-01-30 10:02:52
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-02-09 17:02:06
 * @Description  : 
 */
export const ROUTES = {
  home: '/freestanding',
  chatBI: '/chat-bi',
  login: '/login',
  accountManagement: '/accountManagement',
} as const;
