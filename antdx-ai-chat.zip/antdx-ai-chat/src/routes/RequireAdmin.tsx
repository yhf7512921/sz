/*
 * @Author       : Chang xd
 * @Date         : 2026-02-09 10:20:29
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-02-09 13:57:32
 * @Description  : 
 */
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../stores';
import { ROUTES } from './paths';

interface RequireAdminProps {
  children: React.ReactElement;
}

const RequireAdmin: React.FC<RequireAdminProps> = ({ children }) => {
  const { isAuthenticated, role } = useAuthStore();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.login} state={{ from: location }} replace />;
  }

  if (role !== 'admin') {
    return <Navigate to={ROUTES.home} replace />;
  }

  return children;
};

export default RequireAdmin;
