import { Modal, Button, Spin, message } from 'antd';
import { FilePdfOutlined, DownloadOutlined } from '@ant-design/icons';
import React, { useState, useRef, useEffect } from 'react';
import XMarkdown from '@ant-design/x-markdown';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import type { ComponentProps } from '@ant-design/x-markdown';
import PictureView from './PictureView';

interface MarkdownToPdfDialogProps extends ComponentProps {
  title?: string;
  children?: React.ReactNode;
  streamStatus?: string;
}

const xmarkdownComponents = {
  'custom-picture': PictureView,
};

const MarkdownToPdfDialog = React.memo<MarkdownToPdfDialogProps>(({ children, title = '文档', streamStatus }) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [pdfDataUrl, setPdfDataUrl] = useState<string>('');
  const [modalOpen, setModalOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setModalOpen(false);
    setPdfDataUrl('');
    setLoading(false);
    setGeneratingPdf(false);
  };

  const handleModalOpenChange = (isOpen: boolean) => {
    setModalOpen(isOpen);
    if (isOpen && children && !pdfDataUrl) {
      setTimeout(() => {
        generatePdf();
      }, 100);
    }
  };

  useEffect(() => {
    if (!open) {
      setPdfDataUrl('');
      setLoading(false);
      setGeneratingPdf(false);
    }
  }, [open]);

  const generatePdf = async () => {
    if (!contentRef.current) {
      message.error('PDF生成失败：内容未加载');
      setLoading(false);
      setGeneratingPdf(false);
      return;
    }

    if (!children) {
      message.error('PDF生成失败：无内容');
      setLoading(false);
      setGeneratingPdf(false);
      return;
    }

    try {
      setLoading(true);
      setGeneratingPdf(true);

      await new Promise(resolve => setTimeout(resolve, 800));

      const container = contentRef.current as HTMLElement;

      if (!container) {
        message.error('PDF生成失败：容器未找到');
        setLoading(false);
        setGeneratingPdf(false);
        return;
      }

      const images = container.querySelectorAll('img');

      if (images.length > 0) {
        const imagePromises = Array.from(images).map(img => {
          return new Promise((resolve) => {
            if (img.complete) {
              resolve(true);
            } else {
              img.onload = () => resolve(true);
              img.onerror = () => resolve(false);
            }
          });
        });

        await Promise.all(imagePromises);
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      const canvas = await html2canvas(container, {
        scale: 1.5,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        allowTaint: false,
      });

      let imgData = '';
      try {
        imgData = canvas.toDataURL('image/jpeg', 0.95);
      } catch (jpegError) {
        imgData = canvas.toDataURL('image/png');
      }

      const pdf = new jsPDF('p', 'mm', 'a4');

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const margin = 10;

      const imgWidthPx = canvas.width;
      const imgHeightPx = canvas.height;

      const pxToMm = 0.264583;
      const imgWidth = imgWidthPx * pxToMm;
      const imgHeight = imgHeightPx * pxToMm;

      const ratio = (pdfWidth - margin * 2) / imgWidth;
      const scaledWidth = imgWidth * ratio;
      const scaledHeight = imgHeight * ratio;

      const imgX = margin;
      const imgY = margin;

      const pageContentHeight = pdfHeight - margin * 2;
      let heightLeft = scaledHeight;
      let position = imgY;

      const imageFormat = imgData.startsWith('data:image/jpeg') ? 'JPEG' : 'PNG';
      pdf.addImage(imgData, imageFormat, imgX, position, scaledWidth, scaledHeight);
      heightLeft -= pageContentHeight;

      while (heightLeft > 0) {
        position = -(heightLeft - imgY);
        pdf.addPage();
        pdf.addImage(imgData, imageFormat, imgX, position, scaledWidth, scaledHeight);
        heightLeft -= pageContentHeight;
      }

      setPdfDataUrl(pdf.output('dataurlstring'));
    } catch (error) {
      message.error('PDF生成失败');
      console.error('PDF生成错误:', error);
    } finally {
      setLoading(false);
      setGeneratingPdf(false);
    }
  };

  const handleDownload = () => {
    if (pdfDataUrl) {
      const link = document.createElement('a');
      link.href = pdfDataUrl;
      link.download = `${title}.pdf`;
      link.click();
      message.success('PDF下载成功');
    }
  };

  const getMarkdownContent = (): string => {
    if (!children) return '';
    
    if (typeof children === 'string') {
      return children;
    }
    
    if (Array.isArray(children)) {
      return children
        .map((child) => {
          if (typeof child === 'string') return child;
          if (React.isValidElement(child)) {
            const props = child.props as { children?: React.ReactNode };
            const childContent = getMarkdownContentFromNode(props.children);
            return childContent;
          }
          return '';
        })
        .join('\n');
    }
    
    if (React.isValidElement(children)) {
      const props = children.props as { children?: React.ReactNode };
      return getMarkdownContentFromNode(props.children);
    }
    
    return '';
  };

  const getMarkdownContentFromNode = (node: React.ReactNode): string => {
    if (!node) return '';
    
    if (typeof node === 'string') {
      return node;
    }
    
    if (Array.isArray(node)) {
      return node
        .map((child) => getMarkdownContentFromNode(child))
        .join('');
    }
    
    if (React.isValidElement(node)) {
      const props = node.props as { children?: React.ReactNode; className?: string };
      return getMarkdownContentFromNode(props.children);
    }
    
    return '';
  };

  const markdownContent = getMarkdownContent();

  return (
    <>
      <div style={{ display: 'none' }}>
        <div 
          ref={contentRef} 
          className="markdown-content"
          style={{ padding: 20, background: '#fff', fontSize: 14, lineHeight: 1.6, maxWidth: '700px' }}
        >
          <XMarkdown components={xmarkdownComponents}>{markdownContent}</XMarkdown>
        </div>
      </div>
      <Button
        type="primary"
        icon={<FilePdfOutlined />}
        onClick={handleOpen}
        loading={streamStatus === 'loading' || streamStatus === 'updating'}
      >
        生成PDF文档
      </Button>
      <Modal
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <FilePdfOutlined />
            <span>{title}</span>
          </div>
        }
        open={open}
        onCancel={handleClose}
        afterOpenChange={handleModalOpenChange}
        forceRender={false}
        destroyOnClose={false}
        width={800}
        footer={[
          <Button key="close" onClick={handleClose}>
            关闭
          </Button>,
          <Button
            key="download"
            type="primary"
            icon={<DownloadOutlined />}
            onClick={handleDownload}
            disabled={!pdfDataUrl || generatingPdf}
            loading={generatingPdf}
          >
            下载PDF
          </Button>
        ]}
      >
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 400 }}>
          <Spin size="large">
            <div style={{ padding: 50 }}>正在生成PDF...</div>
          </Spin>
        </div>
      ) : (
        <div style={{ height: 500, overflow: 'auto' }}>
          {pdfDataUrl ? (
            <iframe
              src={pdfDataUrl}
              style={{
                width: '100%',
                height: '100%',
                border: 'none'
              }}
              title="PDF预览"
            />
          ) : (
            <div style={{ padding: 24, background: '#fff' }}>
              <div style={{ fontSize: 14, lineHeight: 1.6 }}>
                <XMarkdown components={xmarkdownComponents}>{markdownContent}</XMarkdown>
              </div>
            </div>
          )}
        </div>
      )}
      </Modal>
    </>
  );
});

export default MarkdownToPdfDialog;
