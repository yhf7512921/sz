import type { ComponentProps } from '@ant-design/x-markdown';
import React from 'react';

const CustomThoughtChain: React.FC<ComponentProps> = ({ children, streamStatus }) => {
  const [title, setTitle] = React.useState('思维链执行中...');
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (streamStatus === 'done') {
      setTitle('思维链执行完成');
      setLoading(false);
    }
  }, [streamStatus]);

  const items = React.useMemo(() => {
    if (!children) {
      console.log('【CustomThoughtChain】children为空，返回空数组');
      return [];
    }

    try {
      const content = typeof children === 'string' ? children : String(children);
 
      
      const arrayMatch = content.match(/\[.*\]/s);
      
      if (!arrayMatch) {
        console.warn('【CustomThoughtChain】未匹配到数组格式');
        return [];
      }

      const arrayStr = arrayMatch[0];
      console.log('【CustomThoughtChain】提取的数组字符串:', arrayStr);
      
      const parsedItems: Array<{ title: string; description: string; blink?: boolean }> = [];
      
      const objectMatches = arrayStr.match(/\{[^}]*\}/g);
      console.log('【CustomThoughtChain】对象匹配结果数量:', objectMatches?.length);
      
      if (!objectMatches) {
        console.warn('【CustomThoughtChain】未匹配到任何对象');
        return [];
      }
      
      objectMatches.forEach((objStr: string, index) => {
        console.log(`【CustomThoughtChain】开始解析对象${index}:`, objStr);
        
        const titleMatch = objStr.match(/title\s*:\s*['"]([^'"]+)['"]/);
        const descMatch = objStr.match(/description\s*:\s*['"]([^'"]+)['"]/);
        
        console.log(`【CustomThoughtChain】对象${index} title匹配:`, titleMatch);
        console.log(`【CustomThoughtChain】对象${index} description匹配:`, descMatch);
        
        if (titleMatch && descMatch) {
          const item = {
            title: titleMatch[1],
            description: descMatch[1],
            blink: index === objectMatches.length - 1 && streamStatus === 'updating',
          };
          console.log(`【CustomThoughtChain】对象${index}解析成功:`, item);
          parsedItems.push(item);
        } else {
          console.warn(`【CustomThoughtChain】对象${index}解析失败，titleMatch:`, titleMatch, 'descMatch:', descMatch);
        }
      });
      
      console.log('【CustomThoughtChain】解析后的items:', parsedItems);
      console.log('【CustomThoughtChain】解析后的items数量:', parsedItems.length);
      return parsedItems;
    } catch (error) {
      console.error('【CustomThoughtChain】解析思维链数据失败:', error);
      return [];
    }
  }, [children, streamStatus]);

  console.log('【CustomThoughtChain】当前渲染状态:', { title, loading, items });

  return (
    <div style={{ marginBottom: '16px', fontSize: '14px' }}>
      <div 
        style={{ 
          display: 'flex', 
          alignItems: 'center',
          marginBottom: '8px',
          padding: '8px 12px',
          background: '#f5f5f5',
          borderRadius: '4px',
          border: '1px solid #d9d9d9'
        }}
      >
        <span style={{ fontWeight: 'bold' }}>{title}</span>
        {loading && <span style={{ fontSize: '12px', color: '#999', marginLeft: '8px' }}>加载中...</span>}
      </div>
      <div style={{ paddingLeft: '16px' }}>
        {items.length === 0 && <div style={{ color: '#999', padding: '12px' }}>暂无思维链节点</div>}
        {items.map((item, index) => (
          <div 
            key={index}
            style={{ 
              marginBottom: '8px',
              padding: '12px',
              background: '#fafafa',
              borderRadius: '4px',
              border: '1px solid #e8e8e8',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '8px'
            }}
          >
            <div style={{ 
              minWidth: '20px', 
              height: '20px', 
              borderRadius: '50%', 
              background: item.blink ? '#1890ff' : '#52c41a',
              marginTop: '2px'
            }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{item.title}</div>
              <div style={{ color: '#666', fontSize: '13px' }}>{item.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomThoughtChain;