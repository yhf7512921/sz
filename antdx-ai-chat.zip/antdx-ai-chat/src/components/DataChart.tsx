﻿/*
 * @Author       : Chang xd
 * @Date         : 2025-12-10 16:07:35
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-02-04 11:25:28
 * @Description  :
 */
// DataChart.tsx
import ReactECharts from 'echarts-for-react';
import { Skeleton } from 'antd';
import React from 'react';
import type { ComponentProps } from '@ant-design/x-markdown';

interface ChartComptProps extends ComponentProps {
  axisXTitle?: string;
  axisYTitle?: string;
  type?: 'line' | 'bar' | 'pie';
  streamStatus?: string;
  children?: React.ReactNode;
}

const DataChart: React.FC<ChartComptProps> = (props) => {
  const { children, axisXTitle, axisYTitle, type, streamStatus } = props;

  const colors = ['#f5222d', '#52c41a', '#faad14', '#722ed1', '#13c2c2', '#fa8c16', '#eb2f96'];

  if (streamStatus === 'loading' || streamStatus === 'updating') {
    return (
      <div style={{ width: '100%', padding: '4px 0', minWidth: '320px' }}>
        <div style={{ width: '100%', maxWidth: '100%', minWidth: '320px' }}>
          <Skeleton.Image active style={{ width: '100%', height: 320, minWidth: '320px' }} />
        </div>
      </div>
    );
  }

  try {
    const childrenStr = typeof children === 'string' ? children : String(children);
    const data = JSON.parse(childrenStr);

    return (
      <div style={{ width: '100%', padding: '4px 0', minWidth: '320px' }}>
        <div style={{ width: '100%', maxWidth: '100%', minWidth: '320px' }}>
          <ReactECharts
            option={{
              tooltip: {
                trigger: type === 'pie' ? 'item' : 'axis',
                axisPointer: type !== 'pie' ? { type: 'shadow' } : undefined,
              },
              ...(type !== 'pie' && {
                grid: {
                  top: 36,
                  left: 48,
                  right: 20,
                  bottom: 36,
                  containLabel: true,
                },
                xAxis: {
                  type: 'category',
                  name: axisXTitle,
                  nameLocation: 'middle',
                  nameGap: 30,
                  nameTextStyle: { fontSize: 14, fontWeight: 'bold' },
                  data: data.map((item: Record<string, any>) => item.name || item.time),
                },
                yAxis: {
                  type: 'value',
                  name: axisYTitle,
                  nameLocation: 'middle',
                  nameGap: 40,
                },
              }),
              series: [
                {
                  data: type === 'pie'
                    ? data.map((item: Record<string, any>) => ({ name: item.name, value: item.value }))
                    : data.map((item: Record<string, any>) => item.value),
                  type,
                  smooth: type === 'line',
                  color: type === 'pie' ? colors : undefined,
                  itemStyle: {
                    color: type !== 'pie' ? '#1890ff' : undefined,
                  },
                  ...(type === 'pie' && {
                    label: {
                      show: true,
                      position: 'outside',
                      formatter: '{b}: {c}',
                    },
                  }),
                },
              ],
            }}
            style={{ width: '100%', height: 320, minWidth: 0 }}
            opts={{ renderer: 'svg' }}
            autoResize
          />
        </div>
      </div>
    );
  } catch (error) {
    return <div style={{ width: '100%', textAlign: 'center', padding: '20px' }}>Chart data parse error</div>;
  }
};

export default React.memo(DataChart);
