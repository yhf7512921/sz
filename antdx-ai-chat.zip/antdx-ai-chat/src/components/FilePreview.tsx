import { Button, List, Typography, Spin } from 'antd';
import { CloseOutlined, FileTextOutlined } from '@ant-design/icons';
import React, { useState } from 'react';

interface FilePreviewProps {
  files: any[];
  onClose: () => void;
}

const FilePreview: React.FC<FilePreviewProps> = ({ files, onClose }) => {
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  // 生成谷歌文档预览链接
  const getGoogleViewerUrl = (file: any) => {
    // 对于本地文件，先创建临时URL
    if (file.originFileObj) {
      const url = URL.createObjectURL(file.originFileObj);
      return `https://drive.google.com/viewer?url=${encodeURIComponent(url)}&embedded=true`;
    }
    // 对于已上传的远程文件，直接使用其URL
    if (file.url) {
      return `https://drive.google.com/viewer?url=${encodeURIComponent(file.url)}&embedded=true`;
    }
    return '';
  };

  // 处理文件预览加载状态
  const handleIframeLoad = (fileKey: string) => {
    setLoading(prev => ({ ...prev, [fileKey]: false }));
  };

  return (
    <div style={{ padding: 20, height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <Typography.Title level={4}>文件预览</Typography.Title>
        <Button icon={<CloseOutlined />} onClick={onClose} type="text" />
      </div>
      
      <List
        dataSource={files}
        renderItem={file => {
          const viewerUrl = getGoogleViewerUrl(file);
          const fileKey = `${file.uid || file.name}`;
          
          return (
            <List.Item 
              actions={[
                <Button 
                  type="link" 
                //   icon={<ExternalLinkOutlined />}
                  onClick={() => {
                    if (viewerUrl) {
                      // 在新窗口打开完整预览
                      window.open(viewerUrl.replace('&embedded=true', ''), '_blank');
                    }
                  }}
                >
                  在新窗口查看
                </Button>
              ]}
            >
              <List.Item.Meta 
                title={file.name}
                description={`大小: ${(file.size / 1024).toFixed(2)}KB · 类型: ${file.type || '未知'}`}
              />
              
              {viewerUrl && (
                <div style={{ width: '100%', height: '400px', marginTop: 16, position: 'relative' }}>
                  {loading[fileKey] !== false && (
                    <div style={{ 
                      position: 'absolute', 
                      top: 0, 
                      left: 0, 
                      right: 0, 
                      bottom: 0, 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center', 
                      background: 'rgba(255,255,255,0.8)', 
                      zIndex: 1 
                    }}>
                      <Spin size="large" tip="加载预览中..." />
                    </div>
                  )}
                  <iframe
                    src={viewerUrl}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                    onLoad={() => handleIframeLoad(fileKey)}
                    style={{ 
                      border: '1px solid #e8e8e8',
                      borderRadius: 4
                    }}
                  />
                </div>
              )}
            </List.Item>
          );
        }}
      />
    </div>
  );
};

export default FilePreview;