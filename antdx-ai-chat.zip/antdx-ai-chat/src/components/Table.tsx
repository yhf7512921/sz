import { DeleteOutlined, EyeOutlined, PlusOutlined } from '@ant-design/icons';
import { Button, Card, Flex, Form, Input, Modal, Select, Space, Table, Tag, message,Skeleton } from 'antd';
import { ComponentProps } from '@ant-design/x-markdown';
import React, { useCallback, useEffect, useState } from 'react';

const { Option } = Select;

// 订单数据类型定义
interface OrderData {
  id: string;
  customer: string;
  product: string;
  amount: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  date: string;
  region: string;
}

// 订单管理表格组件
const CustomTable = React.memo(({ children, streamStatus }: ComponentProps) => {
  const [orders, setOrders] = useState<OrderData[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingOrder, setEditingOrder] = useState<OrderData | null>(null);
  const [form] = Form.useForm();
  // 使用ref跟踪之前的orders状态，避免将orders放在useEffect依赖数组中
  const prevOrdersRef = React.useRef<OrderData[]>([]);
  const hasFetchedRef = React.useRef(false);

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const mockOrders: OrderData[] = [
        {
          id: 'ORD001',
          customer: '张三',
          product: 'iPhone 15',
          amount: 8999,
          status: 'completed',
          date: '2024-01-15',
          region: '北京',
        },
        {
          id: 'ORD002',
          customer: '李四',
          product: 'MacBook Pro',
          amount: 15999,
          status: 'processing',
          date: '2024-01-16',
          region: '上海',
        },
        {
          id: 'ORD003',
          customer: '王五',
          product: 'AirPods Pro',
          amount: 1999,
          status: 'pending',
          date: '2024-01-17',
          region: '广州',
        },
        {
          id: 'ORD004',
          customer: '赵六',
          product: 'iPad Air',
          amount: 4799,
          status: 'completed',
          date: '2024-01-18',
          region: '深圳',
        },
      ];

      setOrders(mockOrders);
    } catch (_error) {
      message.error('获取订单失败');
    } finally {
      setLoading(false);
    }
  }, []);

  // 更新prevOrdersRef的useEffect
  useEffect(() => {
    prevOrdersRef.current = orders;
  }, [orders]);

  useEffect(() => {
    if (children) {
      try {
        // 确保 children 是字符串，如果不是则转换为字符串
        const childrenStr = typeof children === 'string' ? children : String(children);
        const parsedData = JSON.parse(childrenStr);
        if (parsedData.dataSource && Array.isArray(parsedData.dataSource)) {
          // 只有当数据实际发生变化时才更新状态
          if (JSON.stringify(parsedData.dataSource) !== JSON.stringify(prevOrdersRef.current)) {
            setOrders(parsedData.dataSource);
            // 设置为已获取数据，避免再次加载默认数据
            hasFetchedRef.current = true;
          }
          return; // 不再加载默认数据
        }
      } catch (_error) {
        // 如果解析失败，继续加载默认数据
      }
    }
    // 如果没有外部数据或解析失败，且还没有获取过数据时才加载默认数据
    if (!hasFetchedRef.current) {
      fetchOrders();
      hasFetchedRef.current = true;
    }
  }, [children, fetchOrders]);

  const handleDelete = async (id: string) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      setOrders((prev) => prev.filter((order) => order.id !== id));
      message.success('订单已删除');
    } catch (_error) {
      message.error('删除失败');
    }
  };

  const handleEdit = (order: OrderData) => {
    setEditingOrder(order);
    form.setFieldsValue(order);
    setModalVisible(true);
  };

  const handleSubmit = async (values: Partial<OrderData>) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 800));

      if (editingOrder) {
        setOrders((prev) =>
          prev.map((order) => (order.id === editingOrder.id ? { ...order, ...values } : order)),
        );
        message.success('订单已更新');
      } else {
        const newOrder: OrderData = {
          id: `ORD${String(Date.now()).slice(-3)}`,
          customer: values.customer || '',
          product: values.product || '',
          amount: values.amount || 0,
          status: values.status || 'pending',
          date: new Date().toISOString().split('T')[0],
          region: values.region || '',
        };
        setOrders((prev) => [...prev, newOrder]);
        message.success('订单已创建');
      }

      setModalVisible(false);
      form.resetFields();
      setEditingOrder(null);
    } catch (_error) {
      message.error('操作失败');
    }
  };

  const columns = [
    { title: '订单号', dataIndex: 'id', key: 'id' },
    { title: '客户', dataIndex: 'customer', key: 'customer' },
    { title: '产品', dataIndex: 'product', key: 'product' },
    { title: '金额', dataIndex: 'amount', key: 'amount', render: (amount: number) => `¥${amount}` },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const colors = {
          pending: 'orange',
          processing: 'blue',
          completed: 'green',
          cancelled: 'red',
        };
        const labels = {
          pending: '待处理',
          processing: '处理中',
          completed: '已完成',
          cancelled: '已取消',
        };
        return (
          <Tag color={colors[status as keyof typeof colors]}>
            {labels[status as keyof typeof labels]}
          </Tag>
        );
      },
    },
    { title: '日期', dataIndex: 'date', key: 'date' },
    { title: '地区', dataIndex: 'region', key: 'region' },
    // {
    //   title: '操作',
    //   key: 'action',
    //   render: (_: any, record: OrderData) => (
    //     <Space>
    //       <Button type="link" icon={<EyeOutlined />} onClick={() => handleEdit(record)} />
    //       <Button
    //         type="link"
    //         danger
    //         icon={<DeleteOutlined />}
    //         onClick={() => handleDelete(record.id)}
    //       />
    //     </Space>
    //   ),
    // },
  ];

  return (
    <div style={{ padding: '20px' }}>
      <Flex vertical gap="middle">
        <Table
          columns={columns}
          dataSource={orders}
          loading={loading}
          rowKey="id"
          pagination={{ pageSize: 5 }}
        />
      </Flex>
    </div>
  );
});

export default  CustomTable ;