/*
 * @Author       : Chang xd
 * @Date         : 2025-12-25 11:03:40
 * @LastEditors  : Chang xd
 * @LastEditTime : 2025-12-25 17:22:10
 * @Description  : 
 */
import React, { useEffect, useState, useRef } from 'react';
import { ComponentProps } from '@ant-design/x-markdown';
import { Image, Typography } from 'antd';

// 自定义图片组件
const PictureView = React.memo(({ children }: ComponentProps) => {
  // 管理多个图片属性，类似于CardDashBoard组件
  const [src, setSrc] = useState<string>('');
  const [alt, setAlt] = useState<string>('');
  const [width, setWidth] = useState<number | string>(200);

  // 使用ref跟踪之前的状态，避免将状态作为依赖项导致无限循环
  // 参考CardDashBoard组件的prevStateRef设计
  const prevStateRef = useRef<{
    src: string;
    alt: string;
    width: number | string;
  }>({
    src: '',
    alt: '',
    width: 200,
  });

  useEffect(() => {
    if (children) {
      try {
        // 处理children，提取纯字符串内容
        let childrenStr = '';

        if (typeof children === 'string') {
          // 如果是纯字符串，直接使用
          childrenStr = children;
          console.log('Children is a string:', children);
        } else if (Array.isArray(children)) {
          // 如果是数组，提取所有字符串部分并拼接
          childrenStr = children
            .map(item => typeof item === 'string' ? item : '')
            .join('');
        } else {
          // 其他情况，转换为字符串
          childrenStr = String(children);
        }
        console.log('children',childrenStr)
        // 只去除首尾空格和换行符，保留JSON字符串内部的空格
        const cleanedChildren = childrenStr.trim();

        // 清理字符串：移除所有[object Object]和多余的逗号
        const sanitizedString = cleanedChildren
          .replace(/\[object Object\]/g, '') // 移除[object Object] 
          .replace(/,,+/g, ',') // 移除连续的逗号
          .replace(/,\s*}/g, '}') // 移除末尾多余的逗号
          .replace(/,\s*]/g, ']'); // 移除末尾多余的逗号

        console.log('Sanitized string:', sanitizedString);
        // 检查是否是完整的JSON字符串
        if (sanitizedString.startsWith('{') && sanitizedString.endsWith('}')) {
          // 解析JSON数据
          const parsedData = JSON.parse(sanitizedString);

          // 获取之前的状态
          const prevState = prevStateRef.current;

          // 只在属性变化时更新状态，参考CardDashBoard组件的做法
          if (parsedData.src !== prevState.src) {
            setSrc(parsedData.src || '');
            // 更新ref中的状态
            prevStateRef.current.src = parsedData.src || '';
          }

          if (parsedData.alt !== prevState.alt) {
            setAlt(parsedData.alt || '');
            // 更新ref中的状态
            prevStateRef.current.alt = parsedData.alt || '';
          }

          if (parsedData.width !== prevState.width) {
            setWidth(parsedData.width || 200);
            // 更新ref中的状态
            prevStateRef.current.width = parsedData.width || 200;
          }
        } else {
          console.log('Not a complete JSON object yet');
        }
      } catch (error: any) {
        console.error('JSON parse error:', error.message);
      }
    } else {
      console.log('No children received');
      // 没有数据时重置状态
      setSrc('');
      setAlt('');
      setWidth(200);
      // 更新ref中的状态
      prevStateRef.current = {
        src: '',
        alt: '',
        width: 200,
      };
    }
  }, [children]); // 只依赖children，不再依赖状态变量

  // 只有当src存在时才渲染图片
  if (!src) {
    return null;
  }

  return (
    <div style={{ padding: '10px 0' }}>
      {alt && (
        <Typography.Text
          ellipsis={{ tooltip: alt }}
          style={{
            display: 'block',
            width: width,
            maxWidth: '100%',
            marginBottom: 6,
            color: '#111827',
            fontSize: 12,
          }}
        >
          {alt}
        </Typography.Text>
      )}
      <Image
        src={src}
        alt={alt}
        width={width}
        preview={true}
      />
    </div>
  );
});

export default PictureView;
