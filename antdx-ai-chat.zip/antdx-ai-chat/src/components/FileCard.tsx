/*
 * @Author       : Chang xd
 * @Date         : 2026-01-22 14:49:31
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-01-23 16:31:35
 * @Description  : 
 */
import { FileCard } from "@ant-design/x";
import React from "react";
import type { ComponentProps } from '@ant-design/x-markdown';

interface FileCardData {
  name: string;
  byte: number;
  path: string;
}

const CustomFileCard: React.FC<ComponentProps> = ({ children }) => {
  const fileCardData = React.useMemo(() => {
    if (!children) {
      return null;
    }

    try {
      const content = typeof children === 'string' ? children : String(children);
      // console.log('【CustomFileCard】原始内容:', content);
      
      const objectMatch = content.match(/\{[^}]+\}/);
      // console.log('【CustomFileCard】对象匹配结果:', objectMatch);
      
      if (!objectMatch) {
        console.warn('【CustomFileCard】未匹配到对象格式');
        return null;
      }

      const objStr = objectMatch[0];
      // console.log('【CustomFileCard】提取的对象字符串:', objStr);
      
      const nameMatch = objStr.match(/name\s*[:=]\s*['"]([^'"]+)['"]/);
      const byteMatch = objStr.match(/byte\s*[:=]\s*(?:\{(\d+)\}|(\d+))/);
      const pathMatch = objStr.match(/path\s*[:=]\s*['"]([^'"]+)['"]/);
      
      // console.log('【CustomFileCard】name匹配:', nameMatch);
      // console.log('【CustomFileCard】byte匹配:', byteMatch);
      // console.log('【CustomFileCard】path匹配:', pathMatch);
      
      const data: FileCardData = {
        name: nameMatch ? nameMatch[1] : '',
        byte: byteMatch ? parseInt(byteMatch[1] || byteMatch[2] || '0', 10) : 0,
        path: pathMatch ? pathMatch[1] : '',
      };
      
      // console.log('【CustomFileCard】解析后的数据:', data);
      return data;
    } catch (error) {
      console.error('【CustomFileCard】解析文件卡片数据失败:', error);
      return null;
    }
  }, [children]);

  const handleFileClick = () => {
    if (fileCardData?.path) {
      window.open(fileCardData.path, '_blank');
    }
  };

  if (!fileCardData) {
    return null;
  }

  const getFileNameFromPath = (path: string): string => {
    if (!path) return fileCardData.name || 'unknown';
    
    const urlParts = path.split('/');
    const lastPart = urlParts[urlParts.length - 1];
    
    if (lastPart) {
      return lastPart;
    }
    
    return fileCardData.name || 'unknown';
  };

  const fileName = getFileNameFromPath(fileCardData.path);
  // console.log('【CustomFileCard】从path提取的文件名:', fileName);

  return (
    <div 
      onClick={handleFileClick}
      style={{ cursor: 'pointer', display: 'inline-block', margin: '8px 0' }}
    >
      <FileCard 
        name={fileName} 
        byte={fileCardData.byte} 
        size="default"
      />
    </div>
  );
};

export default CustomFileCard;