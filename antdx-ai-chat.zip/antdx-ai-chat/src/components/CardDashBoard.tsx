import React, { useEffect, useState, useRef } from 'react';
import { ComponentProps } from '@ant-design/x-markdown';
import { Card, Flex, Statistic, Tag, Skeleton } from 'antd'; // 新增Skeleton导入
import Icon, { DollarOutlined, ShoppingCartOutlined, UserOutlined, createFromIconfontCN } from '@ant-design/icons';

// 自定义仪表板组件
const CardDashBoard = React.memo(({ children, streamStatus }: ComponentProps) => {
  const [severLoose, setSeverLoose] = useState<number | string>('获取数据...');
  const [hollowing, setHollowing] = useState<number | string>('获取数据...');
  const [loose, setLoose] = useState<number | string>('获取数据...');
  const [region, setRegion] = useState<string>('');
  const [pointless, setPointless] = useState<number | string>('获取数据...');

  // 使用ref跟踪之前的状态，避免将状态作为依赖项导致无限循环
  const prevStateRef = React.useRef<{
    severLoose: number | string;
    hollowing: number | string;
    loose: number | string;
    region: string;
    pointless: number | string;
  }>({
    severLoose: '获取数据...',
    hollowing: '获取数据...',
    loose: '获取数据...',
    region: '',
    pointless: '获取数据...',
  });

  useEffect(() => {
    if (children) {
      try {
        // 处理children，提取纯字符串内容
        let childrenStr = '';

        if (typeof children === 'string') {
          // 如果是纯字符串，直接使用
          childrenStr = children;
          console.log('Children is a string:', children);
        } else if (Array.isArray(children)) {
          // 如果是数组，提取所有字符串部分并拼接
          childrenStr = children
            .map(item => typeof item === 'string' ? item : '')
            .join('');
        } else {
          // 其他情况，转换为字符串
          childrenStr = String(children);
        }

        // console.log('Extracted children string:', childrenStr);

        // 只去除首尾空格和换行符，保留JSON字符串内部的空格
        const cleanedChildren = childrenStr.trim();
        // console.log('Cleaned children:', cleanedChildren);

        // 清理字符串：移除所有[object Object]和多余的逗号
        const sanitizedString = cleanedChildren
          .replace(/\[object Object\]/g, '') // 移除[object Object] 
          .replace(/,,+/g, ',') // 移除连续的逗号
          .replace(/,\s*}/g, '}') // 移除末尾多余的逗号
          .replace(/,\s*]/g, ']'); // 移除末尾多余的逗号

        console.log('Sanitized string:', sanitizedString);

        // 检查是否是完整的JSON字符串
        if (sanitizedString.startsWith('{') && sanitizedString.endsWith('}')) {
          // 解析JSON数据
          const parsedData = JSON.parse(sanitizedString);

          // 获取之前的状态
          const prevState = prevStateRef.current;

          if (parsedData.severLoose !== prevState.severLoose) {
            setSeverLoose(parsedData.severLoose || 0);
            // 更新ref中的状态
            prevStateRef.current.severLoose = parsedData.severLoose || 0;
          }
          if (parsedData.hollowing !== prevState.hollowing) {
            setHollowing(parsedData.hollowing || 0);
            // 更新ref中的状态
            prevStateRef.current.hollowing = parsedData.hollowing || 0;
          }
          if (parsedData.loose !== prevState.loose) {
            setLoose(parsedData.loose || 0);
            // 更新ref中的状态  
            prevStateRef.current.loose = parsedData.loose || 0;
          }
          if (parsedData.pointless !== prevState.pointless) {
            setPointless(parsedData.pointless || 0);
            // 更新ref中的状态
            prevStateRef.current.pointless = parsedData.pointless || 0;
          }
          // 处理region字段
          if (parsedData.region !== prevState.region) {
            setRegion(parsedData.region || '');
            // 更新ref中的状态
            prevStateRef.current.region = parsedData.region || '';
          }
        } else {
          console.log('Not a complete JSON object yet');
        }
      } catch (error: any) {
        console.error('JSON parse error:', error.message);
        console.error('Error stack:', error.stack);

        // 解析错误时只设置一次默认数据
        if (prevStateRef.current.severLoose === 0 && prevStateRef.current.hollowing === 0 && prevStateRef.current.loose === 0 && prevStateRef.current.pointless === 0) {
          setSeverLoose(0);
          setHollowing(0);
          setLoose(0);
          setRegion('示例区域');
          setPointless(0);
          // 更新ref中的状态
          prevStateRef.current = {
            severLoose: '获取数据...',
            hollowing: '获取数据...',
            loose: '获取数据...',
            region: '示例区域',
            pointless: '获取数据...',
          };
        }
      }
    } else {
      console.log('No children received');
      // 没有数据时只设置一次默认数据
      setSeverLoose('获取数据...');
      setHollowing('获取数据...');
      setLoose('获取数据...');
      setRegion('示例区域');
      setPointless('获取数据...');
      // 更新ref中的状态
      prevStateRef.current = {
        severLoose: '获取数据...',
        hollowing: '获取数据...',
        loose: '获取数据...',
        region: '示例区域',
        pointless: '获取数据...',
      };
    }
  }, [children]); // 只依赖children，不再依赖状态变量

  return (
    // 原有渲染逻辑保持不变...
    <div style={{ padding: '20px' }}>
      <Flex vertical gap="large">
        <Flex justify="space-between" align="center">
          数据仪表板 (从模型数据获取)
          <Tag color="blue">实时数据</Tag>
        </Flex>
        <Flex gap="middle" wrap>
          <Card style={{ flex: 1, minWidth: 150 }}>
            <Statistic
              title="严重疏松总数"
              value={`${severLoose} `}
              // prefix={<Icon  />}
              // 移除precision属性或设置为0，让整数显示为整数形式
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
          <Card style={{ flex: 1, minWidth: 150 }}>
            <Statistic
              title="脱空总数"
              value={`${hollowing} `}
              // prefix={<ShoppingCartOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
          <Card style={{ flex: 1, minWidth: 150 }}>
            <Statistic
              title="一般疏松总数"
              value={`${loose} `}
              // prefix={<UserOutlined />}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
          <Card style={{ flex: 1, minWidth: 150 }}>
            <Statistic
              title="空洞"
              value={`${pointless}`}
              // prefix={<UserOutlined />}
              valueStyle={{ color: '#e7e418ff' }}
            />
          </Card>
        </Flex>


        <Flex gap="large" wrap>
          <Card title="数据说明" style={{ flex: 1, minWidth: 300 }}>
            <div style={{ padding: '20px' }}>
              <p>🤖 以上数据由AI模型实时生成</p>
              <p>📊 数据说明: 道路病害数据，包含严重疏松，脱空，一般疏松，空洞数据</p>
              <p>💡 数据来源:{region}</p>
            </div>
          </Card>
        </Flex>
      </Flex>
    </div>
  );
});

export default CardDashBoard;