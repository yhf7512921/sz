import type { ThoughtChainProps, ThoughtChainItemType } from '@ant-design/x';
import { ThoughtChain } from '@ant-design/x';
import type { ComponentProps } from '@ant-design/x-markdown';
import React from 'react';

type CustomThoughtChainProps = ComponentProps & {
  disableBlink?: boolean;
  cacheKey?: string;
};

type ThoughtChainCache = {
  title: string;
  loading: boolean;
  items: ThoughtChainItemType[];
  displayItems: ThoughtChainItemType[];
  typingIndex: number;
  typingPhase: 'title' | 'description';
  typingCharIndex: number;
  lastParsedLength: number;
  lastContent: string;
};

const thoughtChainCache = new Map<string, ThoughtChainCache>();

const CustomThoughtChain: React.FC<CustomThoughtChainProps> = ({ children, streamStatus, disableBlink, cacheKey }) => {
  const cached = cacheKey ? thoughtChainCache.get(cacheKey) : undefined;
  const [title, setTitle] = React.useState(() => cached?.title ?? '报告生成中...');
  const [loading, setLoading] = React.useState(() => cached?.loading ?? true);
  const [items, setItems] = React.useState<ThoughtChainItemType[]>(() => cached?.items ?? []);
  const [displayItems, setDisplayItems] = React.useState<ThoughtChainItemType[]>(() => cached?.displayItems ?? []);
  const [typingIndex, setTypingIndex] = React.useState(() => cached?.typingIndex ?? 0);
  const [typingPhase, setTypingPhase] = React.useState<'title' | 'description'>(() => cached?.typingPhase ?? 'title');
  const [typingCharIndex, setTypingCharIndex] = React.useState(() => cached?.typingCharIndex ?? 0);
  const lastParsedLengthRef = React.useRef(cached?.lastParsedLength ?? 0);
  const lastContentRef = React.useRef(cached?.lastContent ?? '');
  const stateRef = React.useRef<ThoughtChainCache | null>(null);

  React.useEffect(() => {
    if (!cacheKey) {
      return;
    }
    const nextState: ThoughtChainCache = {
      title,
      loading,
      items,
      displayItems,
      typingIndex,
      typingPhase,
      typingCharIndex,
      lastParsedLength: lastParsedLengthRef.current,
      lastContent: lastContentRef.current,
    };
    stateRef.current = nextState;
    thoughtChainCache.set(cacheKey, nextState);
  }, [
    cacheKey,
    title,
    loading,
    items,
    displayItems,
    typingIndex,
    typingPhase,
    typingCharIndex,
  ]);

  React.useEffect(() => {
    if (!cacheKey) {
      return;
    }
    return () => {
      if (stateRef.current) {
        thoughtChainCache.set(cacheKey, stateRef.current);
      }
    };
  }, [cacheKey]);


  const applyBlinkRules = React.useCallback((list: ThoughtChainItemType[]) => (
    list.map(item => ({ ...item, blink: false }))
  ), []);

  React.useEffect(() => {
    if (items.some(item => String(item.title || '').includes('PDF 生成完成'))) {
      setTitle('报告生成完毕');
      setLoading(false);
    }
  }, [items]);

  React.useEffect(() => {
    if (streamStatus === 'done') {
      setTitle('报告生成完成');
      setLoading(false);
    }
  }, [streamStatus]);

  React.useEffect(() => {
    if (streamStatus !== 'updating' && streamStatus !== 'done') {
      return;
    }
    setItems(prevItems => applyBlinkRules(prevItems));
    setDisplayItems(prevItems => applyBlinkRules(prevItems));
  }, [streamStatus, applyBlinkRules]);

  React.useEffect(() => {
    if (streamStatus !== 'updating') {
      setDisplayItems(applyBlinkRules(items));
      setTypingIndex(items.length);
      setTypingPhase('title');
      setTypingCharIndex(0);
      return;
    }
    setDisplayItems(prevItems => {
      if (prevItems.length >= items.length) {
        return prevItems;
      }
      const nextItems = [...prevItems];
      for (let i = prevItems.length; i < items.length; i++) {
        nextItems.push({
          title: '',
          description: '',
          blink: items[i].blink,
        });
      }
      return nextItems;
    });
  }, [items, streamStatus, applyBlinkRules]);

  React.useEffect(() => {
    if (!children) {
      return;
    }
    console.log('【CustomThoughtChain】children:', children)
    try {
      const content = typeof children === 'string' ? children : String(children ?? '');

      if (content.length < lastContentRef.current.length) {
        setItems([]);
        setDisplayItems([]);
        setTypingIndex(0);
        setTypingPhase('title');
        setTypingCharIndex(0);
        lastParsedLengthRef.current = 0;
      }

      if (content === lastContentRef.current) {
        return;
      }
      
      lastContentRef.current = content;

      const objectMatches = content.match(/\{[^}]*\}/g);
      
      if (objectMatches && objectMatches.length > lastParsedLengthRef.current) {
        const newItems: ThoughtChainItemType[] = [];
        
        for (let i = lastParsedLengthRef.current; i < objectMatches.length; i++) {
          const objStr = objectMatches[i];
          
          const titleMatch = objStr.match(/title\s*:\s*['"]([^'"]+)['"]/);
          const descMatch = objStr.match(/description\s*:\s*['"]([^'"]+)['"]/);
          
          const item: ThoughtChainItemType = {
            title: titleMatch ? titleMatch[1] : '',
            description: descMatch ? descMatch[1] : '',
            blink: false,
          };
          
          newItems.push(item);
        }
        
        if (newItems.length > 0) {
          setItems(prevItems => applyBlinkRules([...prevItems, ...newItems]));
          lastParsedLengthRef.current = objectMatches.length;
        }
      }
    } catch (error) {
      console.error('【CustomThoughtChain】解析思维链数据失败:', error);
    }
  }, [children, streamStatus, applyBlinkRules]);

  React.useEffect(() => {
    if (streamStatus !== 'updating') {
      return;
    }

    if (typingIndex >= items.length) {
      return;
    }

    const currentItem = items[typingIndex];
    const targetText = String(
      typingPhase === 'title' ? currentItem?.title ?? '' : currentItem?.description ?? '',
    );
    const currentText = String(
      typingPhase === 'title'
        ? displayItems[typingIndex]?.title ?? ''
        : displayItems[typingIndex]?.description ?? '',
    );

    if (currentText.length >= targetText.length) {
      if (typingPhase === 'title') {
        setTypingPhase('description');
        setTypingCharIndex(0);
      } else {
        setTypingIndex(prev => prev + 1);
        setTypingPhase('title');
        setTypingCharIndex(0);
      }
      return;
    }

    const timer = window.setTimeout(() => {
      setDisplayItems(prevItems => {
        const nextItems = [...prevItems];
        const item = nextItems[typingIndex];
        if (!item) {
          return prevItems;
        }
        const nextText = targetText.slice(0, typingCharIndex + 1);
        nextItems[typingIndex] = {
          ...item,
          blink: currentItem.blink,
          title: typingPhase === 'title' ? nextText : item.title,
          description: typingPhase === 'description' ? nextText : item.description,
        };
        return nextItems;
      });
      setTypingCharIndex(prev => prev + 1);
    }, 30);

    return () => window.clearTimeout(timer);
  }, [items, displayItems, typingIndex, typingPhase, typingCharIndex]);

  return (
    <div style={{ marginBottom: '16px', fontSize: '14px' }}>
      <div 
        style={{ 
          display: 'flex', 
          alignItems: 'center',
          marginBottom: '8px',
          padding: '8px 12px',
          background: '#f5f5f5',
          borderRadius: '4px',
          border: '1px solid #d9d9d9'
        }}
      >
        <span style={{ fontWeight: 'bold' }}>{title}</span>
        {loading && <span style={{ fontSize: '12px', color: '#999', marginLeft: '8px' }}>加载中...</span>}
      </div>
      <ThoughtChain items={displayItems} ></ThoughtChain>
    </div>
  );
};

export default CustomThoughtChain;
