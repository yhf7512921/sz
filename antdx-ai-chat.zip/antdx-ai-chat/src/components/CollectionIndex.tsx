/*
 * @Author       : Chang xd
 * @Date         : 2026-01-09 09:36:46
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-01-23 16:54:42
 * @Description  :
 */
import React, { useState } from 'react';
import { Button, Popover, List, Typography, Divider } from 'antd';
import {
  FilePdfOutlined,
  FileWordOutlined,
  FileOutlined,
  FolderOpenOutlined,
} from '@ant-design/icons';
import { createStyles } from 'antd-style';
import type { ComponentProps } from '@ant-design/x-markdown';

const { Text } = Typography;

// 定义索引项类型
interface FilePiece {
  indexPath: string;
  indexContent?: string;
  indexName: string;
}

interface IndexItem {
  fileName: string;
  filePiece: FilePiece[];
}

// 根据文件路径获取对应的图标
const getFileIcon = (indexPath: string) => {
  const path = indexPath.toLowerCase();
  if (path.includes('.pdf')) {
    return <FilePdfOutlined style={{ fontSize: '18px', color: '#ff4d4f' }} />;
  } else if (path.includes('.docx') || path.includes('.doc')) {
    return <FileWordOutlined style={{ fontSize: '18px', color: '#1890ff' }} />;
  }
  return <FileOutlined style={{ fontSize: '18px', color: '#8c8c8c' }} />;
};

// 创建样式
const useStyle = createStyles(({ token, css }) => ({
  container: css`
    position: relative;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    margin-top: 28px;
    padding-top: 16px;
    max-width: 100%;
    box-sizing: border-box;
  `,
  popover: css`
    width: 400px;
    .ant-popover-inner {
      border-radius: 8px;
      padding: 0;
    }
    .ant-popover-inner-content {
      padding: 0;
    }
  `,
  list: css`
    max-height: 500px;
    overflow-y: auto;
    padding: 8px 0;
  `,
  listItem: css`
    padding: 12px 16px;
    cursor: pointer;
    transition: background-color 0.2s ease;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    &:hover {
      background-color: #E6E6E6;
      
    }
  `,
  listItemHeader: css`
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 6px;
  `,
  indexName: css`
    font-size: 14px;
    font-weight: 500;
    color: #333;
    flex:1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  `,
  indexContent: css`
    font-size: 13px;
    color: #666;
    line-height: 1.6;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    overflow: hidden;
    text-overflow: ellipsis;
    word-break: break-word;
  `,
  fileNameItem: css`
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.2s ease;
    width: 100%;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 8px;
    border-radius: 4px;
    box-sizing: border-box;
    
    &:hover {
      background-color: #FAFAFA;
    }
  `,
}));

// 实现文件索引组件
const CollectionIndex: React.FC<ComponentProps> = (props) => {
  const { children } = props;
  const { styles } = useStyle();
  const [isOpen, setIsOpen] = useState(false);

  try {
    // 添加调试信息
    // console.log('Received children:', children);
    // console.log('Children type:', typeof children);
    // console.log('Children is array:', Array.isArray(children));
    
    // 处理所有类型的children，尝试提取JSON数据
    let fullContent = '';
    // console.log('Children:', children);
    if (Array.isArray(children)) {
      for (const child of children) {
        // console.log('Child type:', typeof child);
        if (typeof child === 'string') {
          fullContent += child;
        } else if (typeof child === 'object' && child !== null) {
          // 如果是对象，打印详细信息，便于调试
          // console.log('Child object:', child);
        }
      }
    } else if (typeof children === 'string') {
      fullContent = children;
    } else if (typeof children === 'object' && children !== null) {
      // 如果children本身是对象，打印详细信息
      // console.log('Children is object:', children);
    }
    
    // 清理字符串，移除前后空格和换行
    fullContent = fullContent.trim();
    
    // 添加调试信息
    // console.log('Full content:', fullContent);
    
    // 直接使用fullContent作为JSON字符串，不再检查标签
    // 因为xmarkdown可能已经将<custom-index>标签剥离
    let jsonString = fullContent;
    
    // 清理JSON字符串，移除不需要的字符
    jsonString = jsonString.replace(/`/g, ''); // 移除反引号
    jsonString = jsonString.replace(/\s+/g, ' '); // 替换多个空格为单个空格
    jsonString = jsonString.trim();
    
    // 添加调试信息
    // console.log('Cleaned jsonString:', jsonString);
    
    // 只有当jsonString不为空时才尝试解析
    if (!jsonString) {
      // console.log('Empty JSON string, skipping rendering');
      return null;
    }
    
    // 尝试解析JSON数据
    let indexData: IndexItem[] = [];
    
    // 先进行JSON修复，再尝试解析，避免不必要的错误信息
    let fixedJsonString = jsonString;
    
    // 1. 移除反引号
    fixedJsonString = fixedJsonString.replace(/`/g, '');
    
    // 2. 确保属性名用双引号包裹
    fixedJsonString = fixedJsonString.replace(/([{,])\s*(\w+):/g, '$1"$2":');
    
    // 3. 清理多余空格
    fixedJsonString = fixedJsonString.replace(/\s+/g, ' ');
    
    // 4. 尝试解析修复后的JSON
    try {
      indexData = JSON.parse(fixedJsonString);
      // console.log('Successfully parsed JSON:', indexData);
    } catch (fixedParseError) {
      // console.log('Fixed JSON parse error, trying manual parsing:', fixedParseError);
      // 尝试手动解析，作为最后的手段
      try {
        // console.log('Trying manual parsing...');
        // 移除数组括号
        const arrayContent = jsonString.replace(/^\[|\]$/g, '');
        // 分割为对象
        const objects = arrayContent.split('},{');
        // 处理每个对象
        indexData = objects.map((objStr, index) => {
          // 修复对象的括号
          const fixedObjStr = (index === 0 ? '{' : '') + objStr + (index === objects.length - 1 ? '}' : '}');
          // 移除反引号
          const noBackticks = fixedObjStr.replace(/`/g, '');
          // 提取属性
          const fileNameMatch = noBackticks.match(/fileName:"([^"]+)"/);
          const filePieceMatch = noBackticks.match(/filePiece:\[([^\]]+)\]/);
          
          let filePiece: FilePiece[] = [];
          if (filePieceMatch && filePieceMatch[1]) {
            // 解析 filePiece 数组
            const pieceArrayStr = filePieceMatch[1];
            const pieceObjects = pieceArrayStr.split('},{');
            filePiece = pieceObjects.map((pieceStr, pieceIndex) => {
              const fixedPieceStr = (pieceIndex === 0 ? '{' : '') + pieceStr + (pieceIndex === pieceObjects.length - 1 ? '}' : '}');
              const noBackticksPiece = fixedPieceStr.replace(/`/g, '');
              const nameMatch = noBackticksPiece.match(/indexName:"([^"]+)"/);
              const pathMatch = noBackticksPiece.match(/indexPath:"([^"]+)"/);
              const contentMatch = noBackticksPiece.match(/indexContent:"([^"]+)"/);
              return {
                indexName: nameMatch ? nameMatch[1] : '',
                indexPath: pathMatch ? pathMatch[1] : '',
                indexContent: contentMatch ? contentMatch[1] : ''
              };
            });
          }
          
          return {
            fileName: fileNameMatch ? fileNameMatch[1] : '',
            filePiece: filePiece
          };
        });
        // console.log('Successfully parsed via manual parsing:', indexData);
      } catch (manualParseError) {
        console.error('Manual parsing error:', manualParseError);
        return null;
      }
    }
    
    // 如果没有索引数据，不渲染组件
    if (!Array.isArray(indexData) || indexData.length === 0) {
      // console.log('No index data found, skipping rendering');
      return null;
    }

    // 渲染文件块的列表内容
    const renderFilePieces = (filePieces: FilePiece[]) => (
      <List
        className={styles.list}
        dataSource={filePieces}
        renderItem={(piece: FilePiece, index: number) => (
          <List.Item
            key={index}
            className={styles.listItem}
            onClick={() => window.open(piece.indexPath, '_blank')}
          >
            <div style={{ width: '100%' }}>
              <div className={styles.listItemHeader}>
                {getFileIcon(piece.indexPath)}
                <span className={styles.indexName}>{piece.indexName}</span>
              </div>
              {piece.indexContent && (
                <div className={styles.indexContent}>{piece.indexContent}</div>
              )}
            </div>
          </List.Item>
        )}
      />
    );

    const content = (
      <div style={{ width: '100%' }}>
        {indexData.map((item: IndexItem, index: number) => (
          <Popover
            key={index}
            content={renderFilePieces(item.filePiece)}
            trigger="hover"
            placement="right"
            overlayClassName={styles.popover}
          >
            <div className={styles.fileNameItem}>
              <span style={{ color: '#666', marginRight: '8px' }}></span>
              <FileOutlined style={{ fontSize: '18px', color: '#8c8c8c', marginRight: '8px' }} />
              <span className={styles.indexName}>{item.fileName}</span>
            </div>
          </Popover>
        ))}
      </div>
    );

    return (
      <div className={styles.container}>
        <Divider style={{ margin: '0 0 16px 0' }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '12px' }}>
          <div>
            <FolderOpenOutlined style={{ fontSize: '16px', marginRight: '8px' }} />
          <span style={{ fontSize: '14px', fontWeight: '500', color: '#333' }}>
            本回答依据以下文件：
          </span>
          </div>
          <div>
            {content}
          </div>
        </div>
        
      </div>
    );
  } catch (error) {
    console.error('Failed to render CollectionIndex:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    // 发生错误时，返回一个简单的提示，方便调试
    return <div style={{ color: 'red', padding: '10px' }}>CollectionIndex Error: {error instanceof Error ? error.message : 'Unknown error'}</div>;
  }
};

export default CollectionIndex;
