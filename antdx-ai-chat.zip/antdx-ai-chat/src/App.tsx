/*
 * @Author       : Chang xd
 * @Date         : 2025-12-01 15:12:02
 * @LastEditors  : Chang xd
 * @LastEditTime : 2025-12-12 14:25:12
 * @Description  : 
 */

import React from 'react';
import './App.css';
import AppRoutes from './routes';
function App() {
  return (
    <div className="App">
      <AppRoutes />
    </div>
  );
}

export default App;
