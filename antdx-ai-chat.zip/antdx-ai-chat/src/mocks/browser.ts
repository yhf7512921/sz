/*
 * @Author       : Chang xd
 * @Date         : 2026-01-15 14:30:00
 * @Description  : MSW Browser 配置 - 用于浏览器环境
 */
import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

export const worker = setupWorker(...handlers);

console.log('[MSW] Mock Service Worker 已启动');
