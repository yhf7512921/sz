/*
 * @Author       : Chang xd
 * @Date         : 2026-01-15 14:30:00
 * @Description  : Mock 数据 - 模拟后端返回的数据
 */

export const mockConversations = [
  {
    key: 'conv-20240115-001',
    label: '新对话1',
    group: 'today',
    createdAt: '2024-01-15T10:30:00Z',
    updatedAt: '2024-01-15T10:35:00Z'
  },
  {
    key: 'conv-20240115-002',
    label: '新对话2',
    group: 'today',
    createdAt: '2024-01-15T11:20:00Z',
    updatedAt: '2024-01-15T11:25:00Z'
  },
  {
    key: 'conv-20240114-001',
    label: '道路病害咨询',
    group: 'yesterday',
    createdAt: '2024-01-14T15:00:00Z',
    updatedAt: '2024-01-14T15:30:00Z'
  }
];

interface MessageContent {
  role: 'user' | 'assistant';
  content: string;
}

interface Message {
  id: string;
  message: MessageContent;
  status: 'success' | 'error' | 'pending';
  timestamp: string;
  extraInfo?: {
    feedback?: string;
  };
}

export const mockMessages: Record<string, Message[]> = {
  'conv-20240115-001': [
    {
      id: 'msg-001',
      message: {
        role: 'user',
        content: '请问2024年检测的之江路发现了多少处病害？'
      },
      status: 'success',
      timestamp: '2024-01-15T10:30:00Z'
    },
    {
      id: 'msg-002',
      message: {
        role: 'assistant',
        content: '根据2024年之江路道路检测报告，共发现15处病害，其中脱空病害8处，空洞病害5处，疏松病害2处。'
      },
      status: 'success',
      timestamp: '2024-01-15T10:30:05Z',
      extraInfo: {
        feedback: 'default'
      }
    },
    {
      id: 'msg-003',
      message: {
        role: 'user',
        content: '请给出所有病害的详细信息'
      },
      status: 'success',
      timestamp: '2024-01-15T10:32:00Z'
    },
    {
      id: 'msg-004',
      message: {
        role: 'assistant',
        content: '以下是所有病害的详细信息：\n\n1. 脱空病害（8处）：\n   - 位置：K0+200-K0+250\n   - 深度：0.5-1.2m\n   - 面积：15.6m²\n   ...\n\n2. 空洞病害（5处）：\n   ...'
      },
      status: 'success',
      timestamp: '2024-01-15T10:32:10Z'
    }
  ],
  'conv-20240115-002': [
    {
      id: 'msg-005',
      message: {
        role: 'user',
        content: '之江路在2024年道路检测时具体是哪一段？'
      },
      status: 'success',
      timestamp: '2024-01-15T11:20:00Z'
    },
    {
      id: 'msg-006',
      message: {
        role: 'assistant',
        content: '之江路2024年检测路段为K0+000至K2+500，全长2.5公里。'
      },
      status: 'success',
      timestamp: '2024-01-15T11:20:05Z'
    }
  ],
  'conv-20240114-001': [
    {
      id: 'msg-007',
      message: {
        role: 'user',
        content: '上城区24年检测出的脱空病害有哪些？'
      },
      status: 'success',
      timestamp: '2024-01-14T15:00:00Z'
    },
    {
      id: 'msg-008',
      message: {
        role: 'assistant',
        content: '上城区2024年共检测出脱空病害23处，主要分布在之江路、浜河路等路段。'
      },
      status: 'success',
      timestamp: '2024-01-14T15:00:05Z'
    }
  ]
};
