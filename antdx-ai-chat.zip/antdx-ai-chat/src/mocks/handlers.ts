/*
 * @Author       : Chang xd
 * @Date         : 2026-01-15 14:30:00
 * @Description  : Mock Handlers - 定义如何拦截和响应 API 请求
 */
import { http, HttpResponse } from 'msw';
import { mockConversations, mockMessages } from './data';

export const handlers = [
  http.get('/conversations', () => {
    console.log('[MSW] ✅ 拦截 GET /conversations 请求');
    console.log('[MSW] 返回数据:', JSON.stringify({
      code: 200,
      message: 'success',
      data: {
        conversations: mockConversations
      }
    }));
    return HttpResponse.json({
      code: 200,
      message: 'success',
      data: {
        conversations: mockConversations
      }
    });
  }),

  http.get('/conversations/:conversationKey/messages', ({ params }) => {
    const { conversationKey } = params;
    console.log(`[MSW] ✅ 拦截 GET /conversations/${conversationKey}/messages 请求`);
    
    const messages = mockMessages[conversationKey as string];
    
    if (messages) {
      console.log('[MSW] 返回数据:', JSON.stringify({
        code: 200,
        message: 'success',
        data: {
          conversationKey,
          messages
        }
      }));
      return HttpResponse.json({
        code: 200,
        message: 'success',
        data: {
          conversationKey,
          messages
        }
      });
    } else {
      console.log('[MSW] ❌ 对话不存在:', conversationKey);
      return HttpResponse.json({
        code: 404,
        message: 'Conversation not found',
        data: null
      }, { status: 404 });
    }
  }),

  http.post('/chat_stream_tokens', () => {
    console.log('[MSW] ✅ 拦截 POST /chat_stream_tokens 请求');
    return HttpResponse.json({
      message: 'Mock response for chat stream'
    });
  }),

  http.post('/reset', () => {
    console.log('[MSW] ✅ 拦截 POST /reset 请求');
    return HttpResponse.json({
      success: true
    });
  }),
];
