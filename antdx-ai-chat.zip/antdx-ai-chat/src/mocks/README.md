# Mock 使用说明

## 概述

本项目使用 **MSW (Mock Service Worker)** 来模拟后端 API 接口，在前端开发阶段无需等待后端接口开发完成。

## 文件结构

```
src/
├── mocks/
│   ├── data.ts          # Mock 数据
│   ├── handlers.ts       # Mock 请求处理器
│   └── browser.ts       # MSW 浏览器配置
└── index.tsx             # 应用入口（已集成 MSW）
```

## 已实现的 Mock 接口

### 1. 获取对话列表
- **接口路径**: `GET /api/conversations`
- **返回数据**: 对话列表
- **数据来源**: `src/mocks/data.ts` 中的 `mockConversations`

### 2. 获取对话消息
- **接口路径**: `GET /api/conversations/:conversationKey/messages`
- **返回数据**: 特定对话的消息列表
- **数据来源**: `src/mocks/data.ts` 中的 `mockMessages`

### 3. 聊天流接口
- **接口路径**: `POST /chat_stream_tokens`
- **返回数据**: 模拟响应

### 4. 重置历史接口
- **接口路径**: `POST /reset`
- **返回数据**: 成功状态

## 如何使用

### 1. 启动应用

```bash
npm start
```

应用启动后，MSW 会自动拦截所有匹配的 API 请求并返回 mock 数据。

### 2. 查看拦截日志

打开浏览器控制台，您会看到类似以下的日志：

```
[MSW] Mock Service Worker 已启动
[MSW] Mock Service Worker 启动成功
[MSW] 拦截 GET /api/conversations 请求
[MSW] 拦截 GET /api/conversations/conv-20240115-001/messages 请求
```

### 3. 修改 Mock 数据

编辑 `src/mocks/data.ts` 文件，修改 `mockConversations` 和 `mockMessages` 变量。

### 4. 添加新的 Mock 接口

在 `src/mocks/handlers.ts` 中添加新的 handler：

```typescript
http.get('/api/your-endpoint', () => {
  return HttpResponse.json({
    code: 200,
    message: 'success',
    data: {
      // 您的数据
    }
  });
}),
```

### 5. 禁用 Mock

如果需要连接真实后端，注释掉 `src/index.tsx` 中的以下代码：

```typescript
// worker.start().then(() => {
//   console.log('[MSW] Mock Service Worker 启动成功');
// }).catch((error) => {
//   console.error('[MSW] Mock Service Worker 启动失败:', error);
// });
```

## Mock 数据格式

### 对话项格式

```typescript
{
  key: string;              // 唯一标识符
  label: string;            // 对话标题
  group?: string;           // 分组信息（如 'today', 'yesterday'）
  createdAt?: string;       // 创建时间（ISO 8601格式）
  updatedAt?: string;       // 更新时间（ISO 8601格式）
}
```

### 消息项格式

```typescript
{
  id: string;               // 消息ID
  message: {
    role: 'user' | 'assistant';  // 消息角色
    content: string;       // 消息内容
  };
  status: 'success' | 'updating' | 'loading' | 'error';  // 消息状态
  timestamp?: string;       // 时间戳（ISO 8601格式）
  extraInfo?: {             // 额外信息
    feedback?: 'default' | 'like' | 'dislike';
  };
}
```

## 常见问题

### Q: 为什么请求没有返回 mock 数据？

A: 请检查：
1. API 路径是否与 `handlers.ts` 中定义的路径一致
2. 浏览器控制台是否有 MSW 启动成功的日志
3. Service Worker 是否正确注册（检查 Application 标签页）

### Q: 如何调试 Mock 数据？

A: 在 `handlers.ts` 中添加 console.log 来查看请求详情：

```typescript
http.get('/api/conversations', ({ params, request }) => {
  console.log('[MSW] 请求详情:', { params, request });
  return HttpResponse.json({ /* ... */ });
}),
```

### Q: 如何模拟网络延迟？

A: 使用 `delay` 函数：

```typescript
import { http, HttpResponse, delay } from 'msw';

http.get('/api/conversations', async () => {
  await delay(500); // 延迟 500ms
  return HttpResponse.json({ /* ... */ });
}),
```

## 参考资料

- [MSW 官方文档](https://mswjs.io/)
- [MSW 快速开始](https://mswjs.io/docs/quick-start)
- [MSW API 参考](https://mswjs.io/docs/api)
