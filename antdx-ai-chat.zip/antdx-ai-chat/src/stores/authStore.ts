/*
 * @Description  : Simple auth store (mock-ready)
 */
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type UserRole = 'admin' | 'user';

interface AuthState {
  isAuthenticated: boolean;
  token?: string;
  username?: string;
  role?: UserRole;
  setAuth: (payload: { token?: string; username?: string; role?: UserRole }) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      token: undefined,
      username: undefined,
      role: undefined,
      setAuth: ({ token, username, role }) =>
        set({
          isAuthenticated: true,
          token,
          username,
          role,
        }),
      logout: () =>
        set({
          isAuthenticated: false,
          token: undefined,
          username: undefined,
          role: undefined,
        }),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => sessionStorage),
    }
  )
);
