/*
 * @Author       : Chang xd
 * @Date         : 2026-01-16 09:29:08
 * @LastEditors  : Chang xd
 * @LastEditTime : 2026-01-23 09:59:25
 * @Description  : 对话状态管理 - 简化版
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ConversationState {
  currentConversationId: string;
  setCurrentConversationId: (id: string) => void;
  isNewConversation: boolean;
  setIsNewConversation: (isNew: boolean) => void;
  nextNewConversationId: string;
  setNextNewConversationId: (id: string) => void;
  newLabelId: string;
  setNewLabelId: (id: string) => void;
  newLabel: string;
  setNewLabel: (label: string) => void;
}

export const useConversationStore = create<ConversationState>()(
  persist(
    (set) => ({
      currentConversationId: '',
      setCurrentConversationId: (id) => set({ currentConversationId: id }),
      isNewConversation: true,
      setIsNewConversation: (isNew) => set({ isNewConversation: isNew }),
      nextNewConversationId: `conv_${Date.now()}`,
      setNextNewConversationId: (id) => set({ nextNewConversationId: id }),
      newLabelId: '',
      setNewLabelId: (id) => set({ newLabelId: id }),
      newLabel: '',
      setNewLabel: (label) => set({ newLabel: label }),
    }),
    {
      name: 'conversation-storage',
    }
  )
);
